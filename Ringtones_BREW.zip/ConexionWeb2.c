#include "ConexionWeb.h"
#include "Utilerias.h"
#include "MenuGral.h"

//=========================================================================
//=========================================================================

boolean ConexionWeb(Cringtonesapp * pMe, char * pUrl, char * pNom)
{
	char *pTemp;
	
// Se crea una instancia IWeb y guarda la direcci�n en pMe->m_pIWeb. Tambi�n se crea una instancia IHeap para verificar la memoria disponible. Si falla alguna de las dos,  regresa FALSE
	
	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
	if( pMe->m_ePantalla != P_INTRO )
	{
		IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
		IDISPLAY_Update ( pMe->a.m_pIDisplay );
	}

	if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_WEB, (void**)(&pMe->m_pIWeb)) != SUCCESS)
	{

		LiberaWeb(pMe);
		LiberaUtil(pMe);

		// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n que maneje las 
// situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().

		DespliegaMensaje2(pMe, 4 );
		return FALSE;
	}

	// Nos aseguramos que los miembros de la estructura que se van a utilizar estan correctamente inicializados

	pMe->m_pContenidoBufer = NULL;
	pMe->m_iTamanioBufer = 0;
	pMe->m_iMemAsigBuf = 0;

	// Se utiliza la funci�n definida en AEEStdLib CALLBACK_Init para establecer LeerDatosWebCB como la funci�n de llamada de regreso. La estructura AEECallback que se requiere   
              //inicializar es pMe->m_Callback, y el apuntador que va a ser pasado a LeerDatosWebCB es pMe.
	
	CALLBACK_Init(&pMe->m_Callback, LeerDatosWebCB, pMe);

	// Se especifica el destino de los datos que se descargan de la p�gina Web

	switch(pMe->m_eDestInfo)
	{
		case ARCHIVO:  // El nombre se extrae a partir del url
					
if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void**)(&pMe->m_pIFileMgr)) != SUCCESS))
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n // que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n 
//DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return FALSE;
			}

			pTemp = pUrl + STRLEN(pUrl);

			while(*pTemp != '/')
				pTemp--;

			pTemp++;
			pMe->m_pNomArchivo = (char *)MALLOC(STRLEN(pTemp) + 1);
			
			if(pMe->m_pNomArchivo)
			{
				STRCPY(pMe->m_pNomArchivo, pTemp);


				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->m_pNomArchivo, _OFM_CREATE);

				if(!pMe->m_pIFile)
				{
					LiberaUtil(pMe);
					LiberaWeb(pMe);

					// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra // funci�n que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la 
					// funci�n DespliegaError().

					DespliegaError(pMe, "Memoria insuficiente");
					return FALSE;
				}
			}
			else
			{
				LiberaUtil(pMe);
				LiberaWeb(pMe);

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaMensaje2(pMe, 4 );
				return FALSE;
			}

			break;

		case BUFER:   // Los datos se almacenan en pMe->m_pContenidoBufer

			if(ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_HEAP, (void**)(&pMe->m_pIHeap)) != SUCCESS)
			{
				LiberaUtil(pMe);
				LiberaWeb(pMe);

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaMensaje2(pMe, 4 );
				return FALSE;
			}

			break;

		case NOMBARCHIVO:   // El nombre del archivo lo especifica el programador
			
			if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR,  (void**)(&pMe->m_pIFileMgr)) != SUCCESS))
			{
				LiberaUtil(pMe);
				LiberaWeb(pMe);

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaMensaje2(pMe, 4 );
				return FALSE;
			}
		
			pMe->m_pNomArchivo = (char *)MALLOC(STRLEN(pNom) + 1);
			
			if(pMe->m_pNomArchivo)
			{
				STRCPY(pMe->m_pNomArchivo, pNom);

				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->m_pNomArchivo, _OFM_CREATE);

				if(!pMe->m_pIFile)
				{
					LiberaUtil(pMe);
					LiberaWeb(pMe);

					// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra 
// funci�n que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la //	// funci�n DespliegaError().

					DespliegaMensaje2(pMe, 4 );
					return FALSE;
				}
			}
			else
			{
				LiberaUtil(pMe);
				LiberaWeb(pMe);


// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n // que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n 
// DespliegaError().

				DespliegaMensaje2(pMe, 4 );
				return FALSE;
			}
			
			break;
	}



	if( pMe->m_ePantalla!= P_DEL && pMe->m_ePantalla != P_INTRO && pMe->sinnombretono == FALSE)
	{
		if(pMe->conexion_snombre == FALSE)
		{
			FREEIF( pMe->m_pTemporal );
			pMe->m_pTemporal = (AECHAR *)MALLOC(24);
			ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_DESCARGANDO, pMe->m_pTemporal, 24);
			FREEIF( pMe->m_pTituloTemp);
			pTemp = NULL;
			pTemp = MALLOC( 7 + STRLEN(pMe->m_pNTono) );  
			if( pTemp )
			{
				STRCPY( pTemp, "Title:" );
				STRCAT( pTemp, pMe->m_pNTono );
				pMe->m_pTituloTemp = (AECHAR *)MALLOC(2*(STRLEN(pTemp)+1));
				if( pMe->m_pTituloTemp )
					STRTOWSTR( pTemp, pMe->m_pTituloTemp, 2*(STRLEN(pTemp)+1));
			}
			FREEIF(pTemp);
			pTemp = MALLOC( 8 + STRLEN(pMe->Artista) );
			if( pTemp )
			{
				STRCPY( pTemp, "Artist:" );
				STRCAT( pTemp, pMe->Artista );
				pMe->m_pArtistaTemp = (AECHAR *)MALLOC(2*(STRLEN(pTemp)+1));
				if( pMe->m_pArtistaTemp )
					STRTOWSTR( pTemp, pMe->m_pArtistaTemp, 2*(STRLEN(pTemp)+1));
			}
			FREEIF( pTemp );
		}
	
		else
		{
			FREEIF( pMe->m_pTemporal );
			pMe->m_pTemporal = (AECHAR *)MALLOC(24);
			ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_DESCARGANDO, pMe->m_pTemporal, 24);

		}
	}
	else if(pMe->sinnombretono==TRUE)
	{
		FREEIF( pMe->m_pTemporal );
		pMe->m_pTemporal = (AECHAR *)MALLOC(24);
		ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_DESCARGANDO, pMe->m_pTemporal, 24);
	}

	// A continuaci�n se llama a la funci�n IWEB_GetResponse(), que establece la conexi�n con la p�gina Web.
	
	pMe->m_bBand = TRUE;

	if ((pMe->m_pIImgDescarga[PROG_TELEFONO] = ISHELL_LoadResImage(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDB_TELEFONO))==NULL ||
	     (pMe->m_pIImgDescarga[PROG_COMPUTADORA]  = ISHELL_LoadResImage(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDB_COMPUTADORA))==NULL ||
	    (pMe->m_pIImgDescarga[PROG_ANIM]  = ISHELL_LoadResImage(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDB_ANIM))==NULL)
	{
		IWEB_GetResponse(pMe->m_pIWeb, (pMe->m_pIWeb, &pMe->m_pIWebResp, &pMe->m_Callback, pUrl, 
					WEBOPT_END));
	}
	else
	{
		IWEB_GetResponse(pMe->m_pIWeb, (pMe->m_pIWeb, &pMe->m_pIWebResp, &pMe->m_Callback, pUrl, 
		            WEBOPT_HANDLERDATA, pMe, 
		            WEBOPT_STATUSHANDLER, NotificacionEstadoWeb,
		            WEBOPT_END));
	}
	
	return TRUE;
}

//=========================================================================
//=========================================================================
void LeerDatosWebCB(void* pCxt)
{
	int iContBytes;
	char pBuf[128];
	WebRespInfo* pWebRespInfo;	        // Nos dice el estado de nuestra conexi�n Web.
	ISource* pISource;		        // Obtenemos los datos a trav�s de esta interfaz.
	boolean BANDERA;

	
	// Regresa cuando llamamos CALLABACK_Init, A continuaci�n se hace el cast
	// para utilizar los datos miembros de la estructura de la aplicaci�n.

	Cringtonesapp * pMe = (Cringtonesapp *)pCxt;

	// Se inicializa pWebRespInfo mediante la funci�n IWEBRESP_GetInfo. Se llama a LiberaWeb()
	// y regresa  la funci�n si falla la siguiente instrucci�n.

	pWebRespInfo = IWEBRESP_GetInfo(pMe->m_pIWebResp);

	
	if (!pWebRespInfo || !WEB_ERROR_SUCCEEDED(pWebRespInfo->nCode))  // Se cumple la condici�n cuando no hay conexi�n disponible
	{	
		LiberaWeb(pMe);
		LiberaUtil(pMe);
		FREEIF( pMe->Artista );
		FREEIF( pMe->m_pTituloTemp );
		FREEIF( pMe->m_pArtistaTemp );
		// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n que maneje las 
		// situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().
														
		DespliegaError(pMe, "No hay conexi�n disponible");
		
		return;
	}

	if(pMe->m_bBand)
	{
		pMe->m_iTamanioArchivo = pWebRespInfo->lContentLength;
		pMe->m_iBytesDescargados = 0;
		
		switch(pMe->m_eDestInfo){

		case ARCHIVO:
		case NOMBARCHIVO:
			{
			if(IFILEMGR_GetFreeSpace(pMe->m_pIFileMgr, NULL) < (uint32)(pWebRespInfo->lContentLength + 10000))
				{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
				FREEIF( pMe->m_pArtistaTemp );
				FREEIF( pMe->m_pTituloTemp );
				// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().
				FREEIF( pMe->Artista);
				DespliegaError(pMe, "c");
				return;
				}
			}
			break;

		case BUFER:

			if(!IHEAP_CheckAvail(pMe->m_pIHeap, (pWebRespInfo->lContentLength) + 10000))
			{
				LiberaWeb(pMe);	
				LiberaUtil(pMe);
				FREEIF(pMe->m_pID_Tono); //Agregue el 15 de abril
				FREEIF(pMe->m_pTituloTemp);
				FREEIF(pMe->m_pArtistaTemp);
                if(pMe->m_ePantalla!=P_ARTISTAX && pMe->m_ePantalla!=P_SAVE && pMe->m_ePantalla!=P_BUY ) //26 de abril del 2004 REVISAR || pMe->m_ePantalla!==P_SAVE
				FREEIF(pMe->Artista);
				if(pMe->edo_pantalla==3 && pMe->m_ePantallaProc==P_CAT) //30 de abril del 2003
				{
				   if(pMe->Artista)
				   pMe->m_ePantallaProc=P_CATEGORIAX;
				}

				if(pMe->edo_pantalla==7 && pMe->m_ePantalla==P_CATEGORIAX)
				pMe->m_ePantalla=P_CAT;
				else
				{
					if(pMe->edo_pantalla==7 && pMe->m_ePantallaProc==P_CAT)
					pMe->m_ePantallaProc=P_CATEGORIAX;
				}
								
// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n // que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n 
// DespliegaError().
				DespliegaError(pMe, "Memoria insuficiente");
				return;
			}

			if( !pMe->m_pIFileMgr )
				if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void**)(&pMe->m_pIFileMgr)) != SUCCESS))
				{
					LiberaWeb(pMe);
					LiberaUtil(pMe);
					DespliegaError(pMe, "Memoria insuficiente");
					return;
				}
			
			if(IFILEMGR_GetFreeSpace(pMe->m_pIFileMgr, NULL) < (uint32)(pWebRespInfo->lContentLength + 1000))
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
				FREEIF( pMe->m_pArtistaTemp );
				FREEIF( pMe->m_pTituloTemp );
				// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().
				FREEIF( pMe->Artista);
				DespliegaError(pMe, "c");
				return;
			}
			IFILEMGR_Release( pMe->m_pIFileMgr );
			pMe->m_pIFileMgr = NULL;
			break;
		}
		
		pMe->m_bBand = FALSE;

	}

	// Se establece la direcci�n del apuntador a la fuente de datos de la cual vamos a leer el 
	// contenido de la p�gina Web.

	pISource = pWebRespInfo->pisMessage;
	
	// Leemos el contenido de la p�gina Web y lo almacenamos en pBuf[].

	iContBytes = ISOURCE_Read(pISource, (char*)pBuf, sizeof(pBuf));

	// ISOURCE_Read() regresa valores que caen dentro de las siguioentes cuatro categor�as:
	//
	//   1. ISOURCE_WAIT:  Significa que los datos todav�a no est�n disponibles.
	//   2. ISOURCE_ERROR: Ocurri� un error
	//   3. ISOURCE_END:   No hay m�s datos que leer
	//   4. >0 : El n�mero de bytes que fu� le�do

	switch (iContBytes)
	{
		case ISOURCE_WAIT:

			// Se llama ISOURCE_Readable() para esperar la siguiente llamada de regreso.			
			ISOURCE_Readable(pISource, &pMe->m_Callback);

			return; 

		case ISOURCE_ERROR:                      // No encuentra m�s datos

			if(pMe-> m_eDestInfo != BUFER )
				IFILEMGR_Remove(pMe->m_pIFileMgr, pMe->m_pNomArchivo);

			LiberaWeb(pMe);
			LiberaUtil(pMe);			
			FREEIF(pMe->m_pTemporal);
			FREEIF(pMe->Artista);
			FREEIF(pMe->m_pArtistaTemp);
			FREEIF(pMe->m_pTituloTemp);
			pMe->m_iTamanioArchivo = 0;
// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n que //maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().

			DespliegaError(pMe, "Se perdi� la conexi�n");

			return; 

		case ISOURCE_END:

			// No hay m�s datos, por lo que se inserta un null al final del bufer y se manda llamar la funci�n que manipula el contenido descargado de la p�gina Web.

			switch(pMe->m_eDestInfo)
			{
			case ARCHIVO:
			case NOMBARCHIVO:
			
				LiberaWeb(pMe);		
				LiberaUtil(pMe);

				break;
				
			case BUFER:
	
				if (pMe->m_iTamanioBufer < pMe->m_iMemAsigBuf)
					pMe->m_pContenidoBufer[pMe->m_iTamanioBufer] = 0;
				
				else
					pMe->m_pContenidoBufer[pMe->m_iMemAsigBuf - 1] = 0;

					CALLBACK_Cancel(&pMe->m_Callback);

					if (pMe->m_pIWebResp)
					{
						IWEBRESP_Release(pMe->m_pIWebResp);
						pMe->m_pIWebResp = NULL;
					}

					if (pMe->m_pIWeb) 
					{
						IWEB_Release(pMe->m_pIWeb);
						pMe->m_pIWeb = NULL;
					}
					LiberaUtil(pMe);	
					CreaArchivos( pMe ); //se descomprime el archivo en tonostmp.dat

				break;
			}
			pMe->m_iTamanioArchivo = 0;
			FREEIF( pMe->m_pTemporal );
			FREEIF( pMe->m_pContenidoBufer );
			FREEIF( pMe->m_pArtistaTemp );
			FREEIF( pMe->m_pTituloTemp );

			// Aqu� se inserta el c�digo para llamar la funci�n que manipula los datos descargados de la p�gina Web, o bien se puede lanzar un evento mediante 
// ISHELL_SendEvent. La funci�n que manipula el contenido de la p�gina Web debe recibir como argumento un apuntador a la estructura de la aplicaci�n, para que 
// tenga acceso a los datos miembro m_pContenidoBufer y m_iMemAsigBuf, en caso de que los datos est�n en el Bufer o apuntadores a las instancias IFile en el caso //de que los datos est�n almacenados en un archivo.

			switch( pMe->m_ePantalla )
			{
			case P_ID:

				if(pMe->sinnombretono==FALSE) //Mensaje de compra ya realizada
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					IDISPLAY_Update(pMe->a.m_pIDisplay);
					pMe->m_u16Opcion1=6;
					FREEIF(pMe->m_pIArchivoTono);
					pMe->m_pIArchivoTono=(char *)MALLOC(STRLEN(pMe->m_pID_Tono)+11);
					STRCPY(pMe->m_pIArchivoTono, "/tmp/");
					STRCAT(pMe->m_pIArchivoTono,pMe->m_pID_Tono);
					STRCAT(pMe->m_pIArchivoTono,".mp3");
					if(STRCMP( pMe->Formato_Tono, "mp3" )==0 ) pMe->m_SoundPlayerFile = AEE_SOUNDPLAYER_FILE_MP3;
					if(STRCMP( pMe->Formato_Tono, "midi" )==0 ) pMe->m_SoundPlayerFile = AEE_SOUNDPLAYER_FILE_MIDI;
											
					// se crea un nuevo ringer.
					CreaRingTone(pMe);
					DespliegaMensaje(pMe);
				}
				if(pMe->sinnombretono==TRUE)
				{
					BuscaTono_TonoInfo(pMe);	
				}

			break;


			case P_IDTONOCOMPRADO: 

				CuadroTonoComprado(pMe);

			break;

			case P_INTRO:

				pMe->m_ePantalla=P_MENUINICIO;	
				creaInicio(pMe);				
				
			break;

			
			case P_ARTISTAX:
				//AGREGUE 20 DE ABRIL
					if(pMe->m_eOpcion==O_PLAY)
					{
						
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, RGB_BLACK );
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						if(pMe->m_ePantalla==P_ARTISTAX && pMe->m_ePantallaProc==P_TOP10)
						pMe->edo_pantalla=2;

						switch( pMe->m_u16Opcion2 )
						{
						
							case 7:
							{
							
								AECHAR Buffer[50] = {0};
								CreaRingTone( pMe );
								pMe->m_ePantalla=P_PLAYER;
		
								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce

								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);					
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88); //Animaci�n de reproducci�n del ringtone
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								ReproduceTono(pMe, 1 );
		
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pID_Tono );
								FREEIF( pMe->m_pIArchivoTono );
								return; 
							}
								
							case 8:
							{

								AECHAR Buffer[50] = {0};
								pMe->m_ePantalla=P_PLAYER;
								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								if(pMe->m_pNTono!=NULL)
								{
									STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
								}
								else
								{
									return;
								}
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);					
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88); //Animaci�n de reproducci�n del ringtone
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								ReproduceTono(pMe, 2 );
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pID_Tono );
								FREEIF( pMe->m_pIArchivoTono );
								return;
							}
						}
					}
				
				
				
				///HASTA AC� AGREGUE CON EL ELSE
				else
				{
				  IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
				  IDISPLAY_Update(pMe->a.m_pIDisplay);
				  LibMem(pMe);
				  Lectura_Temp2(pMe);
				}
					
			break;

			case P_TOP10: //En caso de que se encuentre en una de estas
			case P_WISHLST:	//pantallas, el manejador de las acciones
			case P_MTONOS:	//del menu se comportar� de acuerdo al c�digo
			case P_NTONOS:	//de abajo
			case P_CATEGORIAX:
			case P_CAT:
			case P_BUY:
			case P_IDINFO:
			case P_SAVE:
			case P_DEL:  //Agregue el 12 de mayo del 2004

				if(pMe->m_eOpcion!=O_PLAY && pMe->m_ePantalla==P_IDINFO)
					CuadroTextoInfo(pMe);

				if(pMe->edo_pantalla==3 && pMe->m_ePantallaProc==P_CAT)
				{
					pMe->m_ePantallaProc=P_CATEGORIAX;
				}

				if(pMe->edo_pantalla==7 && pMe->m_ePantallaProc==P_CAT)
				{
					pMe->m_ePantallaProc=P_CATEGORIAX;
				}

				if(pMe->m_ePantalla==P_CAT)
				{
					pMe->m_ePantalla=P_CATEGORIAX;	
				}
				if(pMe->m_ePantalla==P_CATEGORIAX)
				{
					if(pMe->ipagCat!=0) //checar el valor de la etiqueta n
					{
						IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
						IDISPLAY_Update(pMe->a.m_pIDisplay);
						Lectura_Temp(pMe);
					}
					if(pMe->m_BanderaConexion==TRUE)
					{
						pMe->m_BanderaConexion=FALSE;
						return; 
					}
					if(pMe->NTONOS_TMP<=0)
					{
						IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
						IDISPLAY_Update(pMe->a.m_pIDisplay);
						creaMenuMov(pMe,"tonostmp.dat");
						pMe->m_eOpcion=0;
						pMe->m_eOpcion2=0;
						creaSK(pMe);
						//c�digo menu con datos en movimiento
						pMe->cont = 0;
						pMe->bandera = 2;
						DespliegaTexto(pMe);
					
					}
					
					if(!pMe->m_pIFileMgr)
					{
						if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
						{
							pMe->m_pIFileMgr = NULL;
							return; 
						}
					}

					IFILEMGR_Release(pMe->m_pIFileMgr);
					IFILEMGR_Remove(pMe->m_pIFileMgr,"tonostmp.dat");

					if(pMe->m_pIFileMgr)
					{
						pMe->m_pIFileMgr=NULL;
					}

				}	

				switch( pMe->m_eOpcion )
				{

					case O_PLAY:
					{
						
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, RGB_BLACK );
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );

						switch( pMe->m_u16Opcion2 )
						{
						
							case 7:
							{
							
								AECHAR Buffer[50] = {0};
								CreaRingTone( pMe );
								pMe->m_ePantalla=P_PLAYER;
		
								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce

								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);					
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88); //Animaci�n de reproducci�n del ringtone
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								ReproduceTono(pMe, 1 );
		
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pID_Tono );
								FREEIF( pMe->m_pIArchivoTono );
								return; 
							}
								
							case 8:
							{

								AECHAR Buffer[50] = {0};
								pMe->m_ePantalla=P_PLAYER;
								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								if(pMe->m_pNTono!=NULL)
								{
									STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
								}
								else
								{
									return;
								}
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);					
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88); //Animaci�n de reproducci�n del ringtone
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								ReproduceTono(pMe, 2 );
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pID_Tono );
								FREEIF( pMe->m_pIArchivoTono );
								return;
							}
						}
					}	
					
///////////////////////////////////
					///Revisar las instancias de IFile y IRigner para ver si no se sobrescriben
					case O_DEL: //Agregue el 12 de mayo del 2004
					{
						switch( pMe->m_ePantallaProc)
						{
							case P_MTONOS:				
							
								if(!pMe->m_pIRingerMgr)
								{
									if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_RINGERMGR, (void **)&(pMe->m_pIRingerMgr)) != SUCCESS )
									return; 
								}
								pMe->m_AEERingerID = IRINGERMGR_GetRingerID( pMe->m_pIRingerMgr, pMe->m_pIArchivoTono );
								if( pMe->m_AEERingerID != AEE_RINGER_ID_NONE )
									IRINGERMGR_Remove( pMe->m_pIRingerMgr, pMe->m_AEERingerID );
								
								pMe->m_ePantalla=P_MTONOS;
								pMe->m_eEntorno=E_MTONOS;
								LibMem(pMe);
								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								pMe->m_eOpcion=0;
								pMe->m_eOpcion2=0;
						
								//c�digo menu con datos en movimiento
								pMe->cont = 0;
								pMe->bandera = 2;
								BANDERA=creaMenuMov(pMe, "buy.dat");
								if(BANDERA!=FALSE)
								{
									creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
									DespliegaTexto(pMe);
								}
								else
								{
									pMe->m_u16Opcion1=7;     
									Fondo_ID(pMe);
									DespliegaMensaje(pMe);  
								}
								
							return;
						}
					}
					break;
////////////////////////////////////
			
					case O_BUY:
					{
						switch( pMe->m_u16Opcion2 )
						{
							case 1:
							case 4:
							case 3:
							case 2:
								// Se mueve el tono de temp a dir_Tonos_Sel
								CreaRingTone( pMe );
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pIArchivoTono );
								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								pMe->m_ePantalla = P_MENUINICIO;
								pMe->m_eEntorno = E_MENU;
								LibMem(pMe);
								creaInicio(pMe);
								return; 
						}
					}
					break;
					
					case O_SAVE:

						switch( pMe->m_u16Opcion2 )
						{
							case 5:
								// Se crea el archivo dir_tonos_cel
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pIArchivoTono );
								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								regresaMenuMov(pMe);
								return; 
							case 6:
								// Se mueve el tono de tmp/id_tono a
								// tonos tonosid_tono
								FREEIF( pMe->m_pNTono );
								FREEIF( pMe->m_pIArchivoTono );
								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								regresaMenuMov(pMe);
								return;
						}
				}
			
				break;
			}

			return; 

			default:


			if(pMe->m_bDispEnProgreso)
			{
				pMe->m_iBytesDescargados += iContBytes;
				EstadoConexion(pMe, 0, IDS_WEBS_CONNECTED);
				EstadoConexion(pMe, 1, IDS_WEBS_DESCARGANDO);
			}
			// Se almacena en el buffer o en el archivo los datos disponibles en ISource.
			if (iContBytes)
			{
				switch(pMe->m_eDestInfo)
				{
					case ARCHIVO:
					case NOMBARCHIVO:

						if(!IFILE_Write(pMe->m_pIFile, (void *)(pBuf), iContBytes))
						{
							IFILEMGR_Remove(pMe->m_pIFileMgr, pMe->m_pNomArchivo);
							LiberaWeb(pMe);
							LiberaUtil(pMe);
							
							// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  //mandar llamar a otra funci�n que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa //en caso de que no desee utilizar la funci�n DespliegaError().

							DespliegaError(pMe, "No hay memoria");
							return; 
						}

						break;

					case BUFER:

							if (pMe->m_iTamanioBufer + iContBytes > pMe->m_iMemAsigBuf)
							{
							    int iNuevoTamanio = pMe->m_iMemAsigBuf + 512;     
								char* pNuevoBuf = (char*)REALLOC(
                                 pMe->m_pContenidoBufer,iNuevoTamanio);
								
								if(!IHEAP_CheckAvail(pMe->m_pIHeap,512))
								{
									LiberaWeb(pMe);
									LiberaUtil(pMe);
									DespliegaError(pMe, "No se puede descargar el Ringtone");
									FREEIF( pMe->m_pNTono );
									FREEIF( pMe->m_pID_Tono );
									FREEIF( pMe->m_pIArchivoTono );
									return;

								}
								if (pNuevoBuf)
								{
									pMe->m_pContenidoBufer = pNuevoBuf;
									pMe->m_iMemAsigBuf = iNuevoTamanio;
								}
								else
								{	
									LiberaWeb(pMe);
									LiberaUtil(pMe);
									
// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) //o si prefiere  mandar llamar a otra funci�n que maneje las situaciones de error. Es responsabilidad del //programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().

									DespliegaError(pMe, "Memoria insuficiente");
									FREEIF(pMe->m_pNTono);
									FREEIF(pMe->m_pIArchivoTono);
									FREEIF(pMe->m_pID_Tono);
									return; 
								}
							}
							if (pMe->m_iTamanioBufer + iContBytes <= pMe->m_iMemAsigBuf)
							{
								MEMCPY(pMe->m_pContenidoBufer + pMe->m_iTamanioBufer, pBuf, iContBytes);
								pMe->m_iTamanioBufer += iContBytes;
							}					

						break;
				}

			}

			// Esperamos por la siguiente llamada de regreso (como en el caso de ISOURCE_WAIT).

			ISOURCE_Readable(pISource, &pMe->m_Callback);
			return; 
	}

}

//=========================================================================
//=========================================================================

void LiberaWeb(Cringtonesapp * pMe)
{
	if (pMe->m_pIWebResp)
	{
		IWEBRESP_Release(pMe->m_pIWebResp);
		pMe->m_pIWebResp = NULL;
	}

	if (pMe->m_pIWeb) 
	{
		IWEB_Release(pMe->m_pIWeb);
		pMe->m_pIWeb = NULL;
	}

	if (pMe->m_pContenidoBufer)
	{
		FREE(pMe->m_pContenidoBufer);
		pMe->m_pContenidoBufer = NULL;
	}

	CALLBACK_Cancel(&pMe->m_Callback);
	pMe->m_iTamanioBufer = 0;
	pMe->m_iMemAsigBuf = 0;

}

//=========================================================================
//=========================================================================

void LiberaUtil(Cringtonesapp * pMe)
{
			if(pMe->m_pIFile)
			{
				IFILE_Release(pMe->m_pIFile);
				pMe->m_pIFile = NULL;
			}

			if(pMe->m_pIFileMgr)
			{
				IFILEMGR_Release(pMe->m_pIFileMgr);
				pMe->m_pIFileMgr = NULL;
			}

			if(pMe->m_pIHeap)
			{
				IHEAP_Release(pMe->m_pIHeap);
				pMe->m_pIHeap = NULL;
			}

			if(pMe->m_pIImgDescarga[0])
			{
				IIMAGE_Release(pMe->m_pIImgDescarga[0]);
				pMe->m_pIImgDescarga[0] = NULL;
			}

			if(pMe->m_pIImgDescarga[1])
			{
				IIMAGE_Release(pMe->m_pIImgDescarga[1]);
				pMe->m_pIImgDescarga[1] = NULL;
			}

			if(pMe->m_pIImgDescarga[2])
			{
				IIMAGE_Release(pMe->m_pIImgDescarga[2]);
				pMe->m_pIImgDescarga[2] = NULL;
			}

			pMe->m_bDispEnProgreso = FALSE;
}

//=========================================================================
//=========================================================================

//=========================================================================
//=========================================================================

void IniciaAnimDescarga(Cringtonesapp * pMe)
{
	AEERect r;

	if(!pMe->m_bDispEnProgreso)
	{
		pMe->m_bDispEnProgreso = TRUE;

		SETAEERECT(&r, (pMe->m_cxPantalla - CX_PROG_DESPLEGAR)/2, (pMe->m_cyPantalla - CY_PROG_DESPLEGAR)/2, 
															CX_PROG_DESPLEGAR, CY_PROG_DESPLEGAR);
		IDISPLAY_EraseRect(pMe->a.m_pIDisplay, &r);
		IDISPLAY_FrameRect(pMe->a.m_pIDisplay, &r);

		IIMAGE_Draw(pMe->m_pIImgDescarga[PROG_TELEFONO], r.x + 10, r.y + 32);
		IIMAGE_Draw(pMe->m_pIImgDescarga[PROG_COMPUTADORA],  r.x + 52, r.y + 44);
		IIMAGE_SetParm(pMe->m_pIImgDescarga[PROG_ANIM], IPARM_NFRAMES, 4, 0);
		IIMAGE_Start(pMe->m_pIImgDescarga[PROG_ANIM], r.x + 28, r.y + 48);
	}
}

void NotificacionEstadoWeb(void* pDatosNotificacion, WebStatus ws)
{
	Cringtonesapp * pMe = (Cringtonesapp*)pDatosNotificacion;
	int iLineaEstado = 1;
	int16 iResID = 0;

	// Make sure the progress box is up
	if (!pMe->m_bDispEnProgreso)
		//IniciaAnimDescarga(pMe);
		pMe->m_bDispEnProgreso = TRUE;

	switch (ws)
	{
	case WEBS_CANCELLED:
		iResID = IDS_WEBS_CANCELLED;
		break;
	case WEBS_GETHOSTBYNAME:
		iResID = IDS_WEBS_GETHOSTBYNAME;
		iLineaEstado = 0;
		break;		  
	case WEBS_CONNECT:
		iResID = IDS_WEBS_CONNECT;
		iLineaEstado = 0;
		break;
	case WEBS_SENDREQUEST:
		EstadoConexion(pMe, 0, IDS_WEBS_CONNECTED);
		iResID = IDS_WEBS_SENDREQUEST;
		break;
	case WEBS_READRESPONSE:
		iResID = IDS_WEBS_READRESPONSE;
		break;
	case WEBS_GOTREDIRECT:
		iResID = IDS_WEBS_REDIRECT;
		break;
	case WEBS_CACHEHIT:
		iResID = IDS_WEBS_CACHEHIT;
		break;
	}

	if (iResID)
		EstadoConexion(pMe, iLineaEstado, iResID);
}

//=========================================================================
//=========================================================================

void EstadoConexion(Cringtonesapp * pMe, int iLinea, int16 iResID)
{

	AEERect rc;
	int iLong, iTemp1, iTemp2;
	char pTemp[5];
	AECHAR wTemp[5];

	iResID = 0;  
	iLinea = 0;
	iTemp1 = IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_BOLD, NULL, NULL );
	iTemp2 = ( pMe->m_cyPantalla - ( 3*iTemp1 + 18 ) ) / 2;
	if( pMe->m_pTituloTemp )
	{
		IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->m_pTituloTemp, -1, 0, iTemp2, NULL, NULL );
	}
	iTemp2 += ( iTemp1 + 2 );
	if( pMe->m_pArtistaTemp )
	{
		IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->m_pArtistaTemp, -1, 0, iTemp2, NULL, NULL );
	}
	iTemp2 += ( iTemp1 + 2 );
	if( pMe->m_pTemporal )	
	{
		iLong = IDISPLAY_MeasureText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->m_pTemporal );
		IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->m_pTemporal, -1, 0, iTemp2, NULL, NULL );
		if( pMe->m_iTamanioArchivo )
			iTemp1 = (pMe->m_iBytesDescargados*100)/pMe->m_iTamanioArchivo;
		SPRINTF(pTemp, "%d%%", iTemp1);
		if( STRTOWSTR(pTemp, wTemp, 8) )
		{
			IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, 5, iLong + 3, iTemp2, NULL, NULL );
		}
	}
	
	iTemp2 += IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_BOLD, NULL, NULL ) + 4;
	
	if(pMe->m_iTamanioArchivo>0)
	{
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, 7, iTemp2, pMe->m_cxPantalla - 12 );	
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, 7, iTemp2 + 9, pMe->m_cxPantalla - 12 );
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, 6, iTemp2 + 1, 1 );
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, 6, iTemp2 + 8, 1 );
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, pMe->m_cxPantalla - 5, iTemp2 + 1, 1 );
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, pMe->m_cxPantalla - 5, iTemp2 + 8, 1 );
		IDISPLAY_DrawHLine( pMe->a.m_pIDisplay, 5, iTemp2 + 2, 6 );
		IDISPLAY_DrawVLine( pMe->a.m_pIDisplay, 6, iTemp2 + 3, 4 );
		IDISPLAY_DrawVLine( pMe->a.m_pIDisplay, pMe->m_cxPantalla - 4, iTemp2 + 2, 6 );
	
		rc.x = 6;
		rc.y = (int16)(iTemp2 + 1);
		rc.dy = 8;

		if( pMe->m_iTamanioArchivo )
		{
			rc.dx = (uint16)((pMe->m_iBytesDescargados * ( pMe->m_cxPantalla - 10 ) )/ pMe->m_iTamanioArchivo);	
			IDISPLAY_DrawRect(pMe->a.m_pIDisplay, &rc, 0x000000, 0x000000, IDF_RECT_FILL | IDF_RECT_FRAME);
			IDISPLAY_Update( pMe->a.m_pIDisplay);
		}
	}
}


//=========================================================================
//=========================================================================


//=========================================================================
//=========================================================================

void DetenerAnimDescarga(Cringtonesapp * pMe)
{
	if (pMe->m_bDispEnProgreso)
	{
		pMe->m_bDispEnProgreso = FALSE;
		IIMAGE_Stop(pMe->m_pIImgDescarga[PROG_ANIM]);
	}
}

//=========================================================================
//=========================================================================

void InicializaDatosWeb(Cringtonesapp * pMe)
{
			pMe->m_pIWeb = NULL;
			pMe->m_pIWebResp = NULL;
			pMe->m_pContenidoBufer = NULL;
			pMe->m_pNomArchivo = NULL;
			pMe->m_pIFileMgr = NULL;
			pMe->m_pIFile = NULL;
			pMe->m_pIHeap = NULL;

			pMe->m_pIImgDescarga[0] = NULL;
			pMe->m_pIImgDescarga[1] = NULL;
			pMe->m_pIImgDescarga[2] = NULL;

			pMe->m_bDispEnProgreso = FALSE;
}



