#ifndef UTILERAS_H
#define UTILERAS_H

#include "notiPantalla2.h"

extern boolean TagContents(char** Html, const char* Tag, char** Start,char** End);

extern boolean buscaDatoID(Cringtonesapp * pMe, const int ID, char** DatoTMP, const char* Tag);

extern boolean buscaDatoID1(Cringtonesapp * pMe, const int ID, char** DatoTMP, const char* Tag);

//c�digo menu datos en movimiento
extern void DespliegaTexto(Cringtonesapp * pMe);

extern boolean ConcatenaSegmento(char **pInicio,  char * pSegmento, int iNoSgto);
//c�digo menu datos en movimiento

extern boolean ReproducirTono(Cringtonesapp * pMe);

extern void LibMem(Cringtonesapp* pMe);

extern void LimpiarIm(Cringtonesapp *pMe); //C�digo de la funci�n para limpiar un elemento de imagen de la memoria

extern void MostrarInicio1( Cringtonesapp *pMe );

extern void MostrarInicio2( Cringtonesapp *pMe );

extern void ConexionInicio( Cringtonesapp * pMe );

extern void EsperaAnimacionInicio(Cringtonesapp * pMe);

// Conexiones 

extern boolean LeeArchivo(Cringtonesapp * pMe, const char * pNoArch, char **pCoArch);

extern boolean LeeArchivoEx(Cringtonesapp * pMe, const char * pNoArch, char **pCoArch);

extern void FormarUrl(Cringtonesapp *pMe, int iConexion);

extern boolean ObtenNumTel( Cringtonesapp *pMe );

extern void CreaArchivos(Cringtonesapp* pMe);

extern boolean LlenaCadena( char ** pCadena, const char * pTexto );

extern boolean EVEtiqueta( Cringtonesapp * pMe, const char * pNomArch, const char * pEt, const char * pVal);

extern boolean OVEtiqueta( Cringtonesapp * pMe, const char * pNomArch, const char * pEt, char ** pVal);

extern boolean FNTono( Cringtonesapp * pMe, const char * pNArch, const char * pIDTono, uint16 u16Opcion );

extern void LiberaCadenas(Cringtonesapp * pMe);

extern boolean DespliegaMensaje(Cringtonesapp * pMe);

extern boolean DespliegaMensaje2( Cringtonesapp * pMe, uint16 opcion );

extern boolean EliminaArchivos( Cringtonesapp * pMe, const char * pNomDir );

extern boolean CreaRingTone( Cringtonesapp * pMe );

extern void DespliegaError(Cringtonesapp * pMe, char *pMsg);

extern boolean BuscaTono( Cringtonesapp * pMe );

extern boolean ReproduceTono( Cringtonesapp * pMe, uint16 band );

extern boolean OrdenaTonos(Cringtonesapp * pMe);

extern void Funcion_Common(Cringtonesapp * pMe, uint16 wParam);

extern boolean Lectura_Temp(Cringtonesapp * pMe);

extern boolean Lectura_Temp2(Cringtonesapp * pMe);

extern void Conexion_TMP(Cringtonesapp * pMe);

extern void Regresa_PantallaArtista(Cringtonesapp * pMe);

extern void HtmlViewer_Noficaciones(Cringtonesapp *pMe,HViewNotify *notificacion);

extern boolean AbrePaginaBuscaTag(Cringtonesapp *pMe,const char *Archivo,const char *Tag);

extern void HtmlViewer_Noficaciones(Cringtonesapp *pMe,HViewNotify *notificacion);

extern void CuadroTextoInfo(Cringtonesapp *pMe);

extern void InterfazID(Cringtonesapp *pMe);

extern void CuadroTonoComprado(Cringtonesapp *pMe);

extern boolean BuscaTono_TonoInfo(Cringtonesapp *pMe);

extern void Fondo_ID(Cringtonesapp *pMe);

extern boolean buscaTemp(Cringtonesapp *pMe);

extern boolean IniciarHtmlViewer(Cringtonesapp *pMe); //Agregue el 14 de abril

#endif