/*===========================================================================

FILE: ringtones.c
===========================================================================*/

/*===============================================================================
INCLUDES AND VARIABLE DEFINITIONS
=============================================================================== */
#include "notiPantalla2.h"
#include "Utilerias.h"
#include "MenuGral.h"
#include "ConexionWeb.h"
/*-------------------------------------------------------------------
Function Prototypes
-------------------------------------------------------------------*/
static boolean ringtones_HandleEvent(IApplet * pi, AEEEvent eCode, 
                                      uint16 wParam, uint32 dwParam);
/*===============================================================================
FUNCTION DEFINITIONS
=============================================================================== */
boolean ringtones_InitAppData(IApplet* po)
{
	AEEDeviceInfo * pDeviceInfo = NULL;
	Cringtonesapp *pMe=(Cringtonesapp *)po;

	pDeviceInfo = ( AEEDeviceInfo * )MALLOC( sizeof(AEEDeviceInfo) );
	if( !pDeviceInfo )
		return FALSE;

	ISHELL_GetDeviceInfo( pMe->a.m_pIShell, pDeviceInfo );
	pMe->m_cxPantalla = pDeviceInfo->cxScreen;
	pMe->m_cyPantalla = pDeviceInfo->cyScreen;
	pMe->m_cxPantalla = pDeviceInfo->cxScreen;
	pMe->m_cyPantalla = pDeviceInfo->cyScreen;
	pMe->m_ProfColor = pDeviceInfo->nColorDepth;
	FREEIF( pDeviceInfo );

	InicializaDatosWeb(pMe);
	pMe->m_eSort=FALSE;
	pMe->m_BanderaConexion=FALSE;
	pMe->m_pImagen1=NULL;
	pMe->m_pIMenuActivo=NULL;
	pMe->m_pISKMenu=NULL;
	pMe->m_pIImgBanner=NULL;
	pMe->m_ePantalla=NULL;
	pMe->m_ePantallaProc=NULL;
	pMe->m_eOpcion=NULL;
	pMe->m_eEntorno=NULL;
	pMe->pSoundPlayerInput=NULL;
	pMe->m_pISoundPlayer=NULL;
	pMe->m_eOpcion2=0;
	pMe->cont=NULL;
	pMe->bandera=NULL;
	pMe->m_pITapi = NULL;
	pMe->m_pContenidoBufer = NULL;
	pMe->m_pIRingerMgr = NULL;
	pMe->m_pIMemStream = NULL;
	pMe->m_eliminaArch = FALSE; 
	pMe->ID = FALSE;
	pMe->Artista=NULL;
	pMe->ipagArt=2;
	pMe->m_pTemporal = NULL;
	pMe->sinnombretono = FALSE;
	pMe->conexion_snombre=FALSE;
	pMe->m_regresoArtista=FALSE;
	pMe->edo_pantalla=0;
	
	pMe->m_pFileInfo = ( AEEFileInfo * )MALLOC( sizeof( AEEFileInfo ));
	if( !pMe->m_pFileInfo )
		return FALSE;

	if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
		return FALSE;
		
	if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
		return FALSE;

	if(ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MEMASTREAM, (void **)(&pMe->m_pIMemStream))!=SUCCESS)
		return FALSE;

	if ( pMe->m_ProfColor>=8)
			IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
	else
			IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);
	IGRAPHICS_ClearViewport(pMe->m_pIGraphics);

	return TRUE;
}



/*===========================================================================

FUNCTION: AEEClsCreateInstance

DESCRIPTION
	This function is invoked while the app is being loaded. All Modules must provide this 
	function. Ensure to retain the same name and parameters for this function.
	In here, the module must verify the ClassID and then invoke the AEEApplet_New() function
	that has been provided in AEEAppGen.c. 

   After invoking AEEApplet_New(), this function can do app specific initialization. In this
   example, a generic structure is provided so that app developers need not change app specific
   initialization section every time except for a call to IDisplay_InitAppData(). 
   This is done as follows: InitAppData() is called to initialize AppletData 
   instance. It is app developers responsibility to fill-in app data initialization 
   code of InitAppData(). App developer is also responsible to release memory 
   allocated for data contained in AppletData -- this can be done in 
   IDisplay_FreeAppData().

PROTOTYPE:
   int AEEClsCreateInstance(AEECLSID ClsId,IShell * pIShell,IModule * po,void ** ppObj)

PARAMETERS:
	clsID: [in]: Specifies the ClassID of the applet which is being loaded

	pIShell: [in]: Contains pointer to the IShell object. 

	pIModule: pin]: Contains pointer to the IModule object to the current module to which
	this app belongs

	ppObj: [out]: On return, *ppObj must point to a valid IApplet structure. Allocation
	of memory for this structure and initializing the base data members is done by AEEApplet_New().

DEPENDENCIES
  none

RETURN VALUE
  AEE_SUCCESS: If the app needs to be loaded and if AEEApplet_New() invocation was
     successful
  EFAILED: If the app does not need to be loaded or if errors occurred in 
     AEEApplet_New(). If this function returns FALSE, the app will not be loaded.

SIDE EFFECTS
  none
===========================================================================*/
int AEEClsCreateInstance(AEECLSID ClsId,IShell * pIShell,IModule * po,void ** ppObj)
{
   *ppObj = NULL;
		
   if(ClsId == AEECLSID_FUNCRING){
      if(AEEApplet_New(sizeof(Cringtonesapp), ClsId, pIShell,po,(IApplet**)ppObj,
         (AEEHANDLER)ringtones_HandleEvent,(PFNFREEAPPDATA)LibMem)
         == TRUE)
      {
		 if(ringtones_InitAppData((IApplet*)*ppObj))
			return (AEE_SUCCESS);
	  }
	  else{
		  IAPPLET_Release((IApplet*)*ppObj);
		  return(EFAILED);
      }
   }
	return (EFAILED);
}


/*===========================================================================

FUNCTION ringtones_HandleEvent

DESCRIPTION
	This is the EventHandler for this app. All events to this app are handled in this
	function. All APPs must supply an Event Handler.

PROTOTYPE:
	boolean ringtones_HandleEvent(IApplet * pi, AEEEvent eCode, uint16 wParam, uint32 dwParam)

PARAMETERS:
	pi: Pointer to the AEEApplet structure. This structure contains information specific
	to this applet. It was initialized during the AEEClsCreateInstance() function.

	ecode: Specifies the Event sent to this applet

   wParam, dwParam: Event specific data.

DEPENDENCIES
  none

RETURN VALUE
  TRUE: If the app has processed the event
  FALSE: If the app did not process the event

SIDE EFFECTS
  none
===========================================================================*/
static boolean ringtones_HandleEvent(IApplet * pi, AEEEvent eCode, uint16 wParam, uint32 dwParam)
{  
   Cringtonesapp * pMe = (Cringtonesapp *)pi;
   AECHAR Vacio[]={'\0'};
   AECHAR Buffer[50];
   AECHAR *pBuf1=NULL;
   AEERingerID ID_Ringer;
   char *Dato=NULL;
   char *Valor_ID=NULL;
   char *Directorio_ID=NULL;
   char *Ruta_ID=NULL;
   char *Ruta_TMP=NULL;
   boolean BANDERA;
   int Estado_TextCtl=0; 
   int cont;
   int cont2;
   

	if(pMe->m_ePantalla == P_AYUDA)
		if (pMe->m_pIHtmlViewer && IHTMLVIEWER_HandleEvent(pMe->m_pIHtmlViewer, eCode, wParam, dwParam))
			return TRUE;
   
	switch (eCode) 
	{
		  case EVT_APP_START:                        
				
				MostrarInicio1(pMe);
				ISHELL_SetTimer(pMe->a.m_pIShell,ANIMACION_INICIO,(PFNNOTIFY)MostrarInicio2,(void*)pMe);	

      	  return(TRUE);
	  
		  case EVT_APP_SUSPEND:
				
				if( pMe->m_ePantalla == P_PLAYER )
				{
					IRINGERMGR_Stop( pMe->m_pIRingerMgr );
					IIMAGE_Stop( pMe->m_pImagen1 );
					IRINGERMGR_Release( pMe->m_pIRingerMgr );
				}

				if(pMe->m_pIMenuActivo)
				{
					IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
				}
				  
				if(pMe->m_pISKMenu)
				{
					IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
				}

				if(pMe->m_pIHtmlViewer)
				{
					IHTMLVIEWER_SetActive(pMe->m_pIHtmlViewer, FALSE);
				}
				
		  return TRUE;
	  
		  case EVT_APP_RESUME:

				if( pMe->m_ePantalla != P_AYUDA && pMe->m_ePantalla != P_PLAYER )
				{
					if (pMe->m_ProfColor>=8) IDISPLAY_FillRect(pMe->a.m_pIDisplay, NULL, MAKE_RGB(194,224,156));
					else IDISPLAY_FillRect(pMe->a.m_pIDisplay, NULL, MAKE_RGB(255,255,255));
					creaEntorno( pMe );
				}
				
				if(pMe->m_pIMenuActivo)
				{
					IMENUCTL_SetActive(pMe->m_pIMenuActivo, TRUE);
				}
				  
				if(pMe->m_pISKMenu)
				{
					IMENUCTL_SetActive(pMe->m_pISKMenu, TRUE);
				}
				
				if( pMe->m_ePantalla != P_PLAYER )
					IDISPLAY_Update ( pMe->a.m_pIDisplay );	
				else
				{
					  IDISPLAY_Update ( pMe->a.m_pIDisplay );
					  regresaMenuMov(pMe);
					  IMENUCTL_SetActive( pMe->m_pISKMenu, FALSE );
					  IMENUCTL_SetActive( pMe->m_pIMenuActivo, TRUE );
				}
				
				if( pMe->m_ePantalla == P_AYUDA )
				{
					IDISPLAY_FillRect(pMe->a.m_pIDisplay, NULL, MAKE_RGB(194,224,156));
					IDISPLAY_Update ( pMe->a.m_pIDisplay );		
					RELEASEIF(pMe->m_pIImgBanner);
					pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_AYUDABAN);
					IIMAGE_Draw(pMe->m_pIImgBanner,2,0);
					RELEASEIF(pMe->m_pIImgBanner);
					if (pMe->m_ProfColor>=8) pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGO);
					else pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGO2);
					IIMAGE_Draw(pMe->m_pIImgBanner,pMe->m_cxPantalla-26,0);
					RELEASEIF(pMe->m_pIImgBanner);
					IDISPLAY_Update ( pMe->a.m_pIDisplay );	
				}

				if(pMe->m_pIHtmlViewer)
				{
					IHTMLVIEWER_SetActive(pMe->m_pIHtmlViewer, TRUE);
				}

			return TRUE;

	  case EVT_KEY:


		  if((wParam==AVK_UP || wParam== AVK_DOWN) && pMe->m_ePantalla==P_ID && pMe->m_pISKMenu)
		  {
				if(ITEXTCTL_IsActive(pMe->m_pITextCtl)==TRUE)
				{
      				//ITEXTCTL_GetText(pMe->m_pITextCtl,pMe->Digitos_ID,sizeof(pMe->Digitos_ID));
					ITEXTCTL_SetActive(pMe->m_pITextCtl, FALSE);
					IMENUCTL_SetActive(pMe->m_pISKMenu,TRUE);
					IMENUCTL_HandleEvent(pMe->m_pISKMenu, eCode, wParam, dwParam);
					return TRUE;
				}
		  }
		  
		  if((wParam==AVK_UP||wParam==AVK_DOWN) && pMe->m_ePantalla==P_ID && pMe->m_pISKMenu)
		  {
				if(ITEXTCTL_IsActive(pMe->m_pITextCtl)==FALSE)
				{
					if(WSTRLEN(pMe->Digitos_ID)>=5)
					{
						for(cont=5; cont<=WSTRLEN(pMe->Digitos_ID); cont++)
							pMe->Digitos_ID[cont]='\0';

					//	ITEXTCTL_SetActive(pMe->m_pITextCtl,FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu,FALSE);
					}
					else
					{
						ITEXTCTL_SetActive(pMe->m_pITextCtl,TRUE);
						IMENUCTL_SetActive(pMe->m_pISKMenu,FALSE);
					}
				}


		  }

		  if((wParam==AVK_UP||wParam==AVK_DOWN) && WSTRLEN(pMe->Digitos_ID)>=5)	
		  {
			  ITEXTCTL_Redraw(pMe->m_pITextCtl);
			  ITEXTCTL_SetActive(pMe->m_pITextCtl,TRUE);
		  }
		  if(WSTRLEN(pMe->Digitos_ID)>=5) //Cuatro caracteres del ID considerando el Nulo, como caracter por separado
		  {								  //AECHAR ocuba dos bytes, WSTRLEN solo regresa el numero de caracteres, se multiplican por dos por los caracteres a borrar	
			  for(cont=0xE020; cont<=0xE02b; cont++)
			  {
				  if(wParam==cont)
							ITEXTCTL_SetActive(pMe->m_pITextCtl,FALSE);

			  }
			  if(ITEXTCTL_IsActive(pMe->m_pITextCtl)==FALSE)
					IMENUCTL_SetActive( pMe->m_pISKMenu, TRUE );
		  }

		  if(pMe->m_pITextCtl!=NULL && wParam==AVK_CLR && WSTRLEN(pMe->Digitos_ID)>=5)
		  {
			 ITEXTCTL_SetActive(pMe->m_pITextCtl,TRUE);
			 ITEXTCTL_SetText(pMe->m_pITextCtl,Vacio, -1);
			 cont2=(WSTRLEN(pMe->Digitos_ID)*2)-1;
			 for(cont=0; cont<=cont2; cont++) //-1 para descontar el 0
						pMe->Digitos_ID[cont]='\0';
			 return TRUE;
			
		  }
		  if(pMe->m_pITextCtl)
		  {
			  if(wParam==AVK_CLR && ITEXTCTL_IsActive(pMe->m_pITextCtl)==TRUE && pMe->Digitos_ID!=NULL && WSTRLEN(pMe->Digitos_ID)!=0)
			  {
					
					ITEXTCTL_SetText(pMe->m_pITextCtl,Vacio, -1);
					cont2=(WSTRLEN(pMe->Digitos_ID)*2)-1;
					for(cont=0; cont<=cont2; cont++)
								pMe->Digitos_ID[cont]='\0';
					return TRUE;
			  }

		  }	
		  if( pMe->m_pISKMenu && pMe->m_ePantalla!=P_ID)
				IMENUCTL_SetActive( pMe->m_pISKMenu, TRUE );

		  if (pMe->m_pIMenuActivo && wParam != AVK_CLR)   

			  if (IMENUCTL_HandleEvent(pMe->m_pIMenuActivo, eCode, wParam, dwParam))
			  {
					Flechas(pMe);
					return TRUE;			  
		  	  }
		
		if(pMe->m_pITextCtl)
		{
			if(wParam != AVK_CLR  && pMe->m_ePantalla==P_ID )
			{
				 if(pMe->ID==FALSE)
				 {	
						ITEXTCTL_SetText(pMe->m_pITextCtl,Vacio, -1);
						for(cont=0; cont<=(WSTRLEN(pMe->Digitos_ID)*2)-1; cont++)
								pMe->Digitos_ID[cont]='\0';
				 }
				 pMe->ID=TRUE;
				 if (ITEXTCTL_HandleEvent(pMe->m_pITextCtl, eCode, wParam, dwParam))
				 {
						ITEXTCTL_GetText(pMe->m_pITextCtl,pMe->Digitos_ID,sizeof(pMe->Digitos_ID));
						if(WSTRLEN(pMe->Digitos_ID)>=5)
								ITEXTCTL_SetActive(pMe->m_pITextCtl,FALSE);
						return TRUE;
				 }
			}
		}

		if (pMe->m_pISKMenu && wParam != AVK_CLR )   
		{
			if (IMENUCTL_HandleEvent(pMe->m_pISKMenu, eCode, wParam, dwParam))
				return TRUE;			  
		}

		if(pMe->m_pITextCtl)
			Estado_TextCtl=ITEXTCTL_IsActive(pMe->m_pITextCtl);
		else if (pMe->m_pITextCtl==NULL)
			Estado_TextCtl=-1;

		  
		if ((wParam == AVK_CLR && (Estado_TextCtl==FALSE||Estado_TextCtl==-1))||(wParam==AVK_CLR && WSTRLEN(pMe->Digitos_ID)==0)){

			if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0)				ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
			if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
				ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   
			pMe->m_eSort=FALSE;

		if(pMe->m_ePantallaProc!=P_CATEGORIAX && pMe->m_ePantallaProc!=P_NTONOS)
		{
			if(pMe->ipagArt<=0 && pMe->m_ePantalla==P_ARTISTAX && pMe->edo_pantalla==0) //Agregue el 22 de abril 2004 pMe->m_ePantallaProc!=P_CATEGORIAX tambien
			{
				pMe->m_ePantallaProc=P_TOP10;
				pMe->edo_pantalla=0;
			}
		}

		if(pMe->ipagArt>=-1 && pMe->m_ePantalla==P_ARTISTAX && pMe->edo_pantalla==1)  //Agregue el 22 de abril del 2004
		{
			pMe->m_ePantallaProc=P_ARTISTAX;
			pMe->edo_pantalla=0;
		}

		
		if(pMe->ipagArt>=0 && pMe->m_ePantalla==P_PLAYER && pMe->edo_pantalla==2)
		{
			pMe->m_ePantallaProc=P_ARTISTAX;
			pMe->edo_pantalla=0;
		}

		if(pMe->ipagCat==0 && pMe->m_ePantalla==P_CATEGORIAX && pMe->edo_pantalla==3) //Agregue el 28 de abril del 2004
		{
			pMe->m_ePantalla=P_CAT;
			pMe->m_ePantallaProc=P_TOP10;
			pMe->edo_pantalla=0;
		}

		if(pMe->ipagArt>=0 && pMe->m_ePantalla==P_PLAYER && pMe->edo_pantalla==4)
		{
			pMe->m_ePantallaProc=P_ARTISTAX;
		}
		
		if(pMe->ipagArt==0 && pMe->m_ePantalla==P_ARTISTAX && pMe->edo_pantalla==4)  //Agregue el 6 de mayo del 2004
		{
			pMe->m_ePantallaProc=P_CATEGORIAX;
			pMe->edo_pantalla=0;
		}

		if(pMe->ipagArt==0 && pMe->m_ePantalla==P_PLAYER && pMe->edo_pantalla==5)   //Agregue el 6 de mayo del 2004
		{
			pMe->m_ePantallaProc=P_ARTISTAX;
		}

		if(pMe->ipagArt==0 && pMe->m_ePantalla==P_ARTISTAX && pMe->edo_pantalla==5)  //Agregue el 6 de mayo del 2004
		{
			pMe->m_ePantallaProc=P_NTONOS;
			pMe->edo_pantalla=0;
		}

		if(pMe->ipagArt==0 && pMe->m_ePantalla==P_ARTISTAX && pMe->edo_pantalla==6)  //Agregue el 6 de mayo del 2004
		{
			pMe->m_ePantallaProc=P_ARTISTAX;
		}

		if(pMe->ipagArt==-1 && pMe->m_ePantalla==P_ARTISTAX && pMe->edo_pantalla==6)  //Agregue el 6 de mayo del 2004
		{
			pMe->m_ePantallaProc=P_NTONOS;
			pMe->edo_pantalla=0;
		}

		if(pMe->ipagCat==0 && pMe->m_ePantalla==P_CATEGORIAX && pMe->edo_pantalla==7) //Agregue el 28 de abril del 2004
		{
			pMe->m_ePantalla=P_CAT;
			pMe->m_ePantallaProc=P_NTONOS;
			pMe->edo_pantalla=0;
		}
		
		if(pMe->ipagCat==0 && pMe->m_ePantalla==P_BUY && pMe->edo_pantalla==7) //Agregue el 28 de abril del 2004
		{
			pMe->m_ePantallaProc=P_CATEGORIAX;
		}

			if(pMe->m_eliminaArch==TRUE)
			{
				//No hay c�digo
			}

			switch(pMe->m_ePantalla){
			
			case P_ARTISTAX:

			pMe->m_regresoArtista=TRUE;
			if(pMe->ipagArt!=-1)
			pMe->ipagArt--;
			
			if(pMe->ipagArt<0) // cuando ipagArt es menor que cero se tiene que regresar a las pantallas principales TOP10, CATEGORIAS, etc
			{
				switch (pMe->m_ePantallaProc)
				{
					case P_TOP10:
						pMe->m_ePantalla=P_TOP10;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_TOP10;
					break;
					case P_WISHLST:
						pMe->m_ePantalla=P_WISHLST;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_WISHLST;
					break;
					case P_NTONOS:
						pMe->m_ePantalla=P_NTONOS;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_NTONOS;
					break;
					case P_MTONOS:
						pMe->m_ePantalla=P_MTONOS;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_MTONOS;
					break;
					case P_CATEGORIAX:
						pMe->m_ePantalla=P_CATEGORIAX;
						pMe->m_ePantallaProc=P_CATEGORIAS;
						pMe->m_eEntorno=E_CATEGORIAX;
					break;
				}

				regresaMenuMov(pMe);
			}
			else
			{
				if (pMe->m_pIFileMgr)
				{
					IFILEMGR_Release(pMe->m_pIFileMgr);
					pMe->m_pIFileMgr=NULL;
				}
				if(pMe->m_pIFile)
				{
					IFILE_Release(pMe->m_pIFile);
					pMe->m_pIFile=NULL;
				}
						
				SPRINTF(pMe->m_pIPagArt," "); //la cadena es pMe->m_pIPagArt
				SPRINTF(pMe->m_pIPagArt,"%u",pMe->ipagArt);
				FormarUrl(pMe,9);
				//FREEIF(pMe->m_pIA);
				pMe->m_eDestInfo = BUFER;
				
				Conexion_TMP(pMe);

			}
	
			return TRUE;
			
			case P_MENUINICIO:

				FREEIF(pMe->Artista);
				FREEIF(pMe->m_pIA);
				ISHELL_CloseApplet(pMe->a.m_pIShell,TRUE);

			return TRUE;

			case P_INTRO:

				ISHELL_CloseApplet(pMe->a.m_pIShell,TRUE);

			return TRUE;
			
			case P_TOP10:
			case P_ID:
					
				if(pMe->sinnombretono==TRUE || pMe->conexion_snombre==TRUE)
				{
					LibMem(pMe);
					pMe->ID=FALSE;
					InterfazID(pMe);
					IMENUCTL_SetActive(pMe->m_pISKMenu,FALSE);
					return TRUE; ///////////////////
				}
				if( pMe->m_pIMenuActivo || pMe->m_ePantalla == P_ID )
				{
					EliminaArchivos( pMe, "tmp/");
					LibMem(pMe);
					pMe->m_eEntorno=E_MENU;
					pMe->m_ePantalla=P_MENUINICIO;
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					IDISPLAY_Update(pMe->a.m_pIDisplay);
					pMe->ID=FALSE;
				}
				else
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					regresaMenuMov(pMe);
				}

			return TRUE;

			case P_IDINFO:

				LibMem(pMe);
				pMe->ID=FALSE;
				InterfazID(pMe);

			return TRUE;

			case P_CATEGORIAS:

				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);

			return TRUE;

			case P_CATEGORIAX:
							
				if(pMe->m_pIMenuActivo || pMe->NTONOS_TMP<=0)
				{
					EliminaArchivos( pMe, "tmp/");
					pMe->m_eEntorno=E_CATEGORIAS;
					pMe->m_ePantalla=P_CATEGORIAS;
					LibMem(pMe);
					IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
					IDISPLAY_Update ( pMe->a.m_pIDisplay );
					pMe->ipagCat=0;
					creaCategorias(pMe);
				}
				else
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					regresaMenuMov(pMe);
				}

			return TRUE;

			case P_WISHLST:

				if(pMe->m_pIMenuActivo)
				{
					EliminaArchivos( pMe, "tmp/");
					LibMem(pMe);
					pMe->m_eEntorno=E_MENU;
					pMe->m_ePantalla=P_MENUINICIO;
					creaInicio(pMe);
				}
				else
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					regresaMenuMov(pMe);

				}

			return TRUE;


			case P_NTONOS:

				if(pMe->m_pIMenuActivo)
				{
					EliminaArchivos( pMe, "tmp/");
					LibMem(pMe);
					pMe->m_eEntorno=E_MENU;
					pMe->m_ePantalla=P_MENUINICIO;
					creaInicio(pMe);
				}
				else
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					regresaMenuMov(pMe);
				}

			return TRUE;

			case P_MTONOS:

				if(pMe->m_pIMenuActivo)
				{
					EliminaArchivos( pMe, "tmp/");
					LibMem(pMe);
					pMe->m_eEntorno=E_MENU;
					pMe->m_ePantalla=P_MENUINICIO;
					creaInicio(pMe);
				}
				else
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					regresaMenuMov(pMe);

				}

			return TRUE;

			case P_PLAYER:
				
				pMe->m_regresoArtista=FALSE;
				IRINGERMGR_Stop( pMe->m_pIRingerMgr );
				IIMAGE_Stop(pMe->m_pImagen1);
				IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
				IDISPLAY_Update ( pMe->a.m_pIDisplay );
				RELEASEIF( pMe->m_pIRingerMgr );
				pMe->ID=FALSE;
				regresaMenuMov(pMe);
				if(pMe->m_ePantalla!=P_IDINFO)
                {
					EliminaArchivos( pMe, "tmp/");
				}
				if(pMe->m_pISKMenu)
				{
					IMENUCTL_SetActive( pMe->m_pISKMenu, FALSE );
				}
				if(pMe->m_pIMenuActivo)
				{
					IMENUCTL_SetActive( pMe->m_pIMenuActivo, TRUE );
				}

			return TRUE;

			case P_BUY:
			case P_SAVE:
			case P_CAT:
			case P_SORT:
			case P_DEL:

				FREEIF( pMe->m_pID_Tono );
				FREEIF( pMe->m_pIArchivoTono );
				FREEIF( pMe->m_pNTono );
				
					
				if (pMe->m_ePantallaProc==P_CATEGORIAX){
					IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 0, 5,
					0, NULL); 
				}
				
				regresaMenuMov(pMe);
			
			return TRUE;

			case P_AYUDA:

				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				pMe->bandera = 2;
				pMe->cont = 0;
				creaInicio(pMe);

			return TRUE;

			default:
			  break;
			}
		
		}
		
		return TRUE;

	  case EVT_COMMAND:
		 
			if(pMe->m_pISKMenu)
			{

				switch(pMe->m_ePantalla){

				case P_ID:

					if(pMe->m_pISKMenu)
					{
						pMe->m_ItemSeleccionado=IMENUCTL_GetSel(pMe->m_pISKMenu);
						switch (pMe->m_ItemSeleccionado)
						{
							case IDS_ACEPTAR:
								if(ITEXTCTL_IsActive(pMe->m_pITextCtl))
									return TRUE;
								LibMem(pMe);
								if(!pMe->m_pIFile)
								if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
									return TRUE;
								if(Directorio_ID==NULL)
								{
									Directorio_ID=(char *)MALLOC(8);
								}
								STRCPY(Directorio_ID, "/tonos/");
								if(Valor_ID==NULL)
								{
									Valor_ID=(char *)MALLOC((WSTRLEN(pMe->Digitos_ID)*2)+1); //WSTRLEN PORQUE ES AECHAR
								}
								if(Valor_ID)
								{
									WSTRTOSTR(pMe->Digitos_ID, Valor_ID, (WSTRLEN(pMe->Digitos_ID)*2)+1); // TAMA�O EN BYTES DE VALOR_ID
									//FREEIF(pMe->m_pID_Tono);
								}
								else
									return TRUE;
							
								
								if(STRCMP(Valor_ID, "")==0 || STRCMP(Valor_ID,"<Insertar No. ID")==0)
								{
									FREEIF(Directorio_ID);
									FREEIF(Valor_ID);
									if(!pMe->m_pISKMenu)
									{
										if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_SOFTKEYCTL, (void **)&pMe->m_pISKMenu) != SUCCESS)

											return FALSE;
									}

									
									creaSK(pMe);
									
									return TRUE;
								}
								else
								{
								FREEIF(pMe->m_pID_Tono);																
								if(!pMe->m_pID_Tono)
								{
									pMe->m_pID_Tono=(char *)MALLOC(STRLEN(Valor_ID)+1);
									STRCPY(pMe->m_pID_Tono,Valor_ID);
								}

								
								if( EVEtiqueta( pMe, "wish.dat", "i>", Valor_ID) ) //EXISTE ID_TONO EN WISHLIST
								{
									OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono ); //LEER TITULO Y ARTISTA CORRESPONDIENTES AL ID_TONO
									OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);
									OVEtiqueta( pMe, "wish.dat", "f", &pMe->Formato_Tono);
									Ruta_ID=(char *)MALLOC(STRLEN(Valor_ID)+STRLEN(Directorio_ID)+STRLEN(pMe->Formato_Tono)+3);
									STRCPY(Ruta_ID, Directorio_ID);
									STRCAT(Ruta_ID, Valor_ID);
									STRCAT(Ruta_ID, ".");
									STRCAT(Ruta_ID, pMe->Formato_Tono);
									FREEIF(Valor_ID);
									FREEIF(Directorio_ID);
									FREEIF(pMe->Formato_Tono);
						
									if(IFILEMGR_Test(pMe->m_pIFileMgr,Ruta_ID)==SUCCESS)
									{ //caso de que si este el archivo
										pMe->TONOS_IDTONO=TRUE; //se va a manejar el id_tono
										FREEIF(Ruta_ID);
										CuadroTextoInfo(pMe); //DESPLIEGA EL CUADRO DE TEXTO
									}
									else
									{
										pMe->TONOS_IDTONO=TRUE; //se va a manejar el id_tono
										FREEIF(Ruta_ID);
										pMe->m_eDestInfo = BUFER;
										FormarUrl(pMe,14); //aqui cambio el url por e=w
										//FREEIF(pMe->m_pID_Tono);
										pMe->m_ePantalla=P_IDINFO;
										pMe->m_eEntorno=E_IDINFO;
										pMe->m_eOpcion=-1;
										ConexionWeb(pMe, pMe->m_pUrlComp, NULL);
									}
								}
								else
								{ 
									
									if( EVEtiqueta( pMe, "buy.dat", "i>", Valor_ID) ) //EXISTE ID_TONO EN BUY.DAT PARA VERIFICAR SI ESTA COMPRADO
									{
										
										OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );
										OVEtiqueta( pMe, "buy.dat", "f", &pMe->Formato_Tono);
											
										if( !pMe->m_pIRingerMgr )
											ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_RINGERMGR, (void **)&pMe->m_pIRingerMgr);

							 			if(Ruta_TMP==NULL)
										{
											Ruta_TMP=(char *)MALLOC(STRLEN(pMe->m_pNTono)+4);
										}
										STRCPY(Ruta_TMP,pMe->m_pNTono);
										STRCAT(Ruta_TMP,".");
										STRCAT(Ruta_TMP,pMe->Formato_Tono); 
									    ID_Ringer=IRINGERMGR_GetRingerID(pMe->m_pIRingerMgr,Ruta_TMP);
										FREEIF(Ruta_TMP);
										FREEIF(pMe->m_pNTono);
									
										FREEIF(pMe->Formato_Tono);
										FREEIF(Valor_ID);
										FREEIF(Directorio_ID);
										//FREEIF(pMe->m_pID_Tono);
										
								

										if( ID_Ringer!=AEE_RINGER_ID_NONE) //EXISTE ID_TONO EN EL DIRECTORIO TONOS?
										{ //si existe

											pMe->m_u16Opcion1=6;
											IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
											IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
											IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
											pBuf1 = ( AECHAR * )MALLOC( 100 );
											ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_COMPRADO, pBuf1, 100 );
											IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156));
											IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pBuf1, -1, 0, 0, NULL, IDF_ALIGN_CENTER| IDF_ALIGN_MIDDLE);
											IDISPLAY_Update(pMe->a.m_pIDisplay);
											FREEIF(pBuf1);
											pMe->m_ePantalla = P_IDINFO;
										}
										else
										{ //no existe

											pMe->conexion_snombre=TRUE;
											FREEIF(pMe->m_pUrlComp);
											pMe->m_eDestInfo = BUFER;
											FormarUrl(pMe,2);
											ConexionWeb(pMe, pMe->m_pUrlComp, NULL); //despues de la conexion tiene que ejecutar la funcion Mensaje_CompraRealizada();

										}

									}
									else
									{
										Ruta_TMP=(char *)MALLOC(STRLEN(Valor_ID)+9);
										STRCPY(Ruta_TMP,"/tmp/");
										STRCAT(Ruta_TMP,Valor_ID);
										STRCAT(Ruta_TMP, ".mp3"); //C�digo sujeto a prueba, dependiendo del formato del id_tono
										FREEIF(Valor_ID);
										pMe->sinnombretono=TRUE;
										if( IFILEMGR_Test(pMe->m_pIFileMgr,Ruta_TMP)==SUCCESS ) //EXISTE ID_TONO EN EL DIRECTORIO TMP?
										{ //si existe el id_tono en el menu tmp

											pMe->TONOS_IDTONO=FALSE; //se va a manejar el tono.info
											FREEIF(pMe->m_pUrlComp);
											FREEIF(Ruta_TMP);
											FREEIF(Directorio_ID);
											pMe->m_eDestInfo = BUFER;
											FormarUrl(pMe,12);
											pMe->m_ePantalla=P_IDINFO;
											pMe->m_eEntorno=E_IDINFO;
											pMe->m_eOpcion=-1; //para que sea distinto de la opci�n O_PLAY y entre a la funcion de CuadroTextoInfo
											ConexionWeb(pMe, pMe->m_pUrlComp, NULL);

										}
										else //no exite el id_tono en el menu tmp
										{
											pMe->TONOS_IDTONO=FALSE;
											FREEIF(Ruta_TMP);
											FREEIF(Directorio_ID);
											FREEIF(pMe->m_pUrlComp);
											pMe->m_eDestInfo = BUFER;
											FormarUrl(pMe,13);
											pMe->sinnombretono=TRUE;
											ConexionWeb(pMe, pMe->m_pUrlComp, NULL);

										}
									}
								}
								}
							break;

							default:
							break;
						}
					}
					return TRUE;
					

				case P_IDTONOCOMPRADO:

					if(pMe->m_pISKMenu)
					{
						pMe->m_ItemSeleccionado=IMENUCTL_GetSel(pMe->m_pISKMenu);
						switch (pMe->m_ItemSeleccionado)
						{
							case 1: // caso de MENU

								pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
								pMe->m_ePantalla=P_MENUINICIO;
								pMe->m_eEntorno=E_MENU;
								creaInicio(pMe);

							return TRUE;


							case 0: // caso de tocar

								pMe->m_eOpcion=0;
								if(pMe->m_ePantalla==P_CAT)
								{
									pMe->m_ePantallaProc=P_CATEGORIAX;
								}
								else
								{
									pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene (procedencia). Sirve para saber a
																			 //donde regresar en caso de oprimir la tecla CLR
								}
								//C�DIGO OPCION PLAY
								IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
								if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0)
									ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
								if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
									ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);

								LibMem(pMe);

								if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
									return TRUE;

								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								// Se checa si se encuentra el identificador del tono
								if( EVEtiqueta( pMe, "wish.dat", "i>", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
									OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) ) //busca el valor que se encuentra entre etiquetas de i y si coincide con pMe->m_p�D_Tono
								{

									FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );	//para el formato del tono <f>
									OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono ); //para el titulo del tono <t>
									OVEtiqueta( pMe, "buy.dat", "a", &pMe->Artista);

									// En este caso el ringtone se encuentra en el directorio de tonos
									// del OEM o tiene que guardarse en el.

									if( BuscaTono( pMe ) )
									{
										// C�digo para reproducir el tono que se encuentra en el
										// directorio de tonos del celular
										IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
										IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );

										pMe->m_ePantalla=P_PLAYER;
										STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
										FREEIF( pMe->m_pNTono );
										IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
										IDISPLAY_Update(pMe->a.m_pIDisplay);
										IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
										0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
										pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);  //SE CARGA LA ANIMACION "REPRODUCE TONO", DESPUES DE HABER SIDO SATISFACTORIA LA BUSQUEDA
										IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);
										IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88);
										IDISPLAY_Update ( pMe->a.m_pIDisplay );
										//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
										//la ubicaci�n y el nombre del tono a reproducir
										ReproduceTono( pMe, 1 );
										FREEIF( pMe->m_pIArchivoTono );
										FREEIF( pMe->Artista );
										return TRUE;

									}
									else
									{
										//	C�digo para hacer la conexi�n web y descargar el archivo
										//	al directorio de tonos del celular
										pMe->m_u16Opcion2 = 7;
										FormarUrl( pMe, 2 );
										pMe->m_eDestInfo = BUFER;
										ConexionWeb(pMe,pMe->m_pUrlComp, NULL );
										return TRUE;
									}
								}
								else if(buscaTemp( pMe )) 
								{
									IFILEMGR_Release( pMe->m_pIFileMgr );
									pMe->m_pIFileMgr = NULL;
									pMe->m_ePantalla=P_PLAYER;

									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );

									IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
									IDISPLAY_Update(pMe->a.m_pIDisplay);
									pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
									IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);
									IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88);
									IDISPLAY_Update ( pMe->a.m_pIDisplay );
									//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
									//la ubicaci�n y el nombre del tono a reproducir
									//ReproducirTono(pMe);
									ReproduceTono( pMe, 2 );
									FREEIF( pMe->m_pIArchivoTono );
									FREEIF( pMe->Artista );
									return TRUE;
								}
					
								if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono ) == EFAILED )
								{
									pMe->m_u16Opcion2 = 8;
									FormarUrl( pMe, 2 );
									pMe->m_eDestInfo = BUFER;
									ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
								}
								else
								{
									IFILEMGR_Release( pMe->m_pIFileMgr );
									pMe->m_pIFileMgr = NULL;
									pMe->m_ePantalla=P_PLAYER;
									STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );

									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );

									IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
									IDISPLAY_Update(pMe->a.m_pIDisplay);
									FREEIF( pMe->m_pNTono );
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
									0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
									IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);
									IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88);
									IDISPLAY_Update ( pMe->a.m_pIDisplay );
									//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
									//la ubicaci�n y el nombre del tono a reproducir
									//ReproducirTono(pMe);
									ReproduceTono( pMe, 2 );
									FREEIF( pMe->m_pIArchivoTono );
									FREEIF( pMe->Artista );
								}
							return TRUE;


							default:
							break;
						}
					}

				case P_IDINFO:

					if(pMe->m_pISKMenu)
					{
						pMe->m_ItemSeleccionado=IMENUCTL_GetSel(pMe->m_pISKMenu);

						switch (pMe->m_ItemSeleccionado)
						{
							case 1: // caso de compra

							pMe->m_eOpcion=1;
							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
							pMe->m_ePantalla=P_BUY;
							//C�DIGO OPCION BUY

							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);

							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);

							LibMem(pMe);

							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;

							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );

							if( EVEtiqueta( pMe, "wish.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);
								// Se remueve wish.dat, en dado caso de que haya m�s de un tono
								// en este archivo se actualiza despu�s de la descarga
								IFILEMGR_Remove( pMe->m_pIFileMgr, "wish.dat");

								if(IFILEMGR_Test(pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS)
								{
									pMe->m_u16Opcion2= 1;
									FormarUrl( pMe, 4 );
								}
								else
								{
									pMe->m_u16Opcion2 = 2;
									FormarUrl( pMe, 3 );
								}
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "buy.dat", "a", &pMe->Artista);

								if( BuscaTono( pMe ) )
								{
									// Mensaje al usuario de que ya se compro el ringtone
									pMe->cont = 0;
									pMe->m_u16Opcion1 = 2;
									DespliegaMensaje( pMe );
									FREEIF( pMe->m_pID_Tono );
									FREEIF( pMe->m_pIArchivoTono );
									FREEIF( pMe->Artista);
									return TRUE;

								}
								else
								{
									pMe->m_u16Opcion2 = 3;
									FormarUrl( pMe, 5 );
								}
							}
							else
							{
								if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );
									OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, "topten.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );
									OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, "new.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );
									OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, pMe->ArchivoCat, "a", &pMe->Artista);
								}

								if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS )
								{
									pMe->m_u16Opcion2 = 4;
									FormarUrl( pMe, 4 );
								}
								else
								{
									char * pTemp = NULL;
									pTemp = ( char *)MALLOC( STRLEN(pMe->m_pIArchivoTono + 4) + 1 );
									STRCPY( pTemp, pMe->m_pIArchivoTono + 4 );
									if( pMe->m_pIArchivoTono )
									{
										FREE( pMe->m_pIArchivoTono );
										pMe->m_pIArchivoTono = NULL;
									}
									pMe->m_pIArchivoTono = pTemp;
									pTemp = NULL;
									pMe->m_u16Opcion2 = 2;
									FormarUrl( pMe, 3 );
								}
							}

							pMe->m_eDestInfo = BUFER;
							pMe->m_ePantalla=P_IDTONOCOMPRADO;
							pMe->m_ePantallaProc=P_BUY;
							ConexionWeb( pMe, pMe->m_pUrlComp, NULL );

						return TRUE;

						case 0: // caso de tocar

							pMe->m_eOpcion=0;
							if(pMe->m_ePantalla==P_CAT)
							{
								pMe->m_ePantallaProc=P_CATEGORIAX;
							}
							else
							{
								pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene (procedencia). Sirve para saber a
																		 //donde regresar en caso de oprimir la tecla CLR
							}
							//C�DIGO OPCION PLAY
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0)
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);

							LibMem(pMe);

							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;

							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							// Se checa si se encuentra el identificador del tono
							if( EVEtiqueta( pMe, "wish.dat", "i>", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i>", pMe->m_pID_Tono ) ) //busca el valor que se encuentra entre etiquetas de i y si coincide con pMe->m_p�D_Tono
							{

								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );	//para el formato del tono <f>
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono ); //para el titulo del tono <t>
								OVEtiqueta( pMe, "buy.dat", "a", &pMe->Artista);
								// En este caso el ringtone se encuentra en el directorio de tonos
								// del OEM o tiene que guardarse en el.

								if( BuscaTono( pMe ) )
								{
									// C�digo para reproducir el tono que se encuentra en el
									// directorio de tonos del celular
									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
									pMe->m_ePantalla=P_PLAYER;
									STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
									FREEIF( pMe->m_pNTono );
									IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
									IDISPLAY_Update(pMe->a.m_pIDisplay);
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
									0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);  //SE CARGA LA ANIMACION "REPRODUCE TONO", DESPUES DE HABER SIDO SATISFACTORIA LA BUSQUEDA
									IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);
									IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88);
									IDISPLAY_Update ( pMe->a.m_pIDisplay );
									//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
									//la ubicaci�n y el nombre del tono a reproducir
									ReproduceTono( pMe, 1 );
									FREEIF( pMe->m_pIArchivoTono );
									FREEIF( pMe->Artista );
									return TRUE;

								}
								else
								{
									//	C�digo para hacer la conexi�n web y descargar el archivo
									//	al directorio de tonos del celular
									pMe->m_u16Opcion2 = 7;
									FormarUrl( pMe, 2 );
									pMe->m_eDestInfo = BUFER;
									ConexionWeb(pMe,pMe->m_pUrlComp, NULL );
									return TRUE;
								}
							}
							else if(buscaTemp( pMe )) 
							{
								IFILEMGR_Release( pMe->m_pIFileMgr );
								pMe->m_pIFileMgr = NULL;
								pMe->m_ePantalla=P_PLAYER;

								IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
								IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );

								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88);
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
					            //la ubicaci�n y el nombre del tono a reproducir
								//ReproducirTono(pMe);
								ReproduceTono( pMe, 2 );
								FREEIF( pMe->m_pIArchivoTono );
								FREEIF( pMe->Artista );
								return TRUE;
							}
								

							if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono ) == EFAILED )
							{
								pMe->m_u16Opcion2 = 8;
								FormarUrl( pMe, 2 );
								pMe->m_eDestInfo = BUFER;
								ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
							}
							else
							{
								IFILEMGR_Release( pMe->m_pIFileMgr );
								pMe->m_pIFileMgr = NULL;
								pMe->m_ePantalla=P_PLAYER;
								STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );

								IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
								IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );

								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								FREEIF( pMe->m_pNTono );
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88);
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
					            //la ubicaci�n y el nombre del tono a reproducir
								//ReproducirTono(pMe);
								ReproduceTono( pMe, 2 );
								FREEIF( pMe->m_pIArchivoTono );
								FREEIF( pMe->Artista );
							}
							return TRUE;

							default:
							break;
						}
					}

				default:
					break;

				return TRUE;
				}
			}	
		
			if (pMe->m_pIMenuActivo) //Verifica si el menu de inicio es el que est� activo
			{

				switch(pMe->m_ePantalla){

				case P_MENUINICIO:

						switch(wParam){

						case 0: //TOP10
							pMe->m_eSort=FALSE;
							pMe->m_ePantalla=P_TOP10; //Para saber la pantalla activa
							pMe->m_eEntorno=E_TOP10;  // y su correspondiente entorno
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0; //Para saber en que lugares se quedaron los menus
							pMe->m_eOpcion2=0; //de manera que si se regresa se ponga el SetSel a estos valores
							pMe->cont = 0;
							pMe->bandera = 2; //banderas y contadores de para el c�digo del menu din�mico
							BANDERA=creaMenuMov(pMe, "topten.dat");
							if(BANDERA!=FALSE)
							{
								creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
								DespliegaTexto(pMe);
								IMENUCTL_SetActive( pMe->m_pISKMenu, FALSE );
							}
							else
							{
								//pMe->m_u16Opcion1=5;     //AGREGUE 14/04/04
								//Fondo_ID(pMe);
								//DespliegaMensaje(pMe);  //TERMINA AGREGUE
								return FALSE;
							}

						return TRUE;

						case 1: //CATEGOR�AS
						
							pMe->m_eEntorno=E_CATEGORIAS;
							pMe->m_ePantallaProc=pMe->m_ePantalla;
							pMe->m_ePantalla=P_CATEGORIAS;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->ipagCat=0;
							creaCategorias(pMe);
				
						return TRUE;

						case 2:  // INGRESAR ID
						
							InterfazID(pMe);
							IMENUCTL_SetActive( pMe->m_pISKMenu, FALSE );

						return TRUE;

						case 3: // WISH LIST

							pMe->m_ePantalla=P_WISHLST;
							pMe->m_eEntorno=E_WISHLST;
							if(pMe->m_pIFileMgr)
							{
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr=NULL;
							}
							if(pMe->m_pIMenuActivo)
							{
								IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							}
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0;
							pMe->m_eOpcion2=0;
						
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2;
							BANDERA=creaMenuMov(pMe, "wish.dat");
							if(BANDERA!=FALSE)
							{
								creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
								DespliegaTexto(pMe);
							}
							else
							{
								pMe->m_u16Opcion1=7;     
								Fondo_ID(pMe);
								DespliegaMensaje(pMe);  
								pMe->m_ePantalla=P_MENUINICIO;
								ISHELL_SetTimer(pMe->a.m_pIShell, 5000, (PFNNOTIFY)creaInicio, (void *)pMe);
								pMe->m_eEntorno=E_MENU;
								return FALSE;
							}

						return TRUE;

						case 4: // NUEVOS TONOS

							pMe->m_ePantalla=P_NTONOS;
							pMe->m_eEntorno=E_NTONOS;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0;
							pMe->m_eOpcion2=0;
							creaSK(pMe);
						
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2;
							BANDERA=creaMenuMov(pMe, "new.dat");
							if(BANDERA!=FALSE)
							{
								creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
								DespliegaTexto(pMe);
							}
							else
							{
								pMe->m_u16Opcion1=5;     //AGREGUE 14/04/04
								Fondo_ID(pMe);
								DespliegaMensaje(pMe);  //TERMINA AGREGUE
								return FALSE;
							}

						return TRUE;

						case 5: // MIS TONOS

							pMe->m_ePantalla=P_MTONOS;
							pMe->m_eEntorno=E_MTONOS;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0;
							pMe->m_eOpcion2=0;
						
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2;
							BANDERA=creaMenuMov(pMe, "buy.dat");
							if(BANDERA!=FALSE)
							{
								creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
								DespliegaTexto(pMe);
							}
							else
							{
								pMe->m_u16Opcion1=7;     
								Fondo_ID(pMe);
								DespliegaMensaje(pMe);
								//MODIFICACIONES REALIZADAS EL 13/05/04
								pMe->m_ePantalla=P_MENUINICIO;
								ISHELL_SetTimer(pMe->a.m_pIShell, 5000, (PFNNOTIFY)creaInicio, (void *)pMe);
								pMe->m_eEntorno=E_MENU;
								return FALSE;
							}

						return TRUE;

						case 6: // AYUDA

							pMe->m_ePantalla=P_AYUDA;
							pMe->m_eEntorno=E_AYUDA;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							//Lugar para el c�digo de la ayuda
							//Selec=0;
							pMe->m_ePantalla=P_AYUDA;
							IDISPLAY_FillRect(pMe->a.m_pIDisplay, NULL, MAKE_RGB(194,224,156));
							IDISPLAY_Update ( pMe->a.m_pIDisplay );		
							RELEASEIF(pMe->m_pIImgBanner);
							pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_AYUDABAN);
							IIMAGE_Draw(pMe->m_pIImgBanner,2,0);
							RELEASEIF(pMe->m_pIImgBanner);
							if (pMe->m_ProfColor>=8) pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGO);
							else pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGO2);
							IIMAGE_Draw(pMe->m_pIImgBanner,pMe->m_cxPantalla-26,0);
							RELEASEIF(pMe->m_pIImgBanner);
							IDISPLAY_Update ( pMe->a.m_pIDisplay );				
							if(IniciarHtmlViewer(pMe)==TRUE)
								AbrePaginaBuscaTag(pMe,ARCHIVO_AYUDA,"P1");
							if(pMe->m_pIHtmlViewer)
								IHTMLVIEWER_SetActive(pMe->m_pIHtmlViewer,TRUE);
								
						return TRUE;
				
						default: 
							break;
						}

				case P_TOP10: //En caso de que se encuentre en una de estas
				case P_WISHLST:	//pantallas, el manejador de las acciones
				case P_MTONOS:	//del menu se comportar� de acuerdo al c�digo
				case P_NTONOS:	//de abajo
				case P_CATEGORIAX:
				case P_ARTISTAX:
				case P_CAT:
						
						pMe->m_eOpcion = IMENUCTL_GetSel(pMe->m_pISKMenu); //Se obtiene el ID del bot�n del men� SoftKey seleccionado 
						pMe->m_eOpcion2=wParam; //Toma el valor del ID del men� donde se enlistan los ringtones (pMe->m_pIMenuActivo)

						switch(pMe->m_eOpcion){

						case O_PLAY: //C�digo para el bot�n de PLAY
																	
							if(pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_TOP10)  //Agregue el 30 de abril del 2004
							pMe->edo_pantalla=3;

							if(pMe->m_ePantalla==P_ARTISTAX && pMe->m_ePantallaProc==P_NTONOS) //Agregue el 30 de abril del 2004
							pMe->edo_pantalla=5;

							if(pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_NTONOS)
							pMe->edo_pantalla=7;
																				
							if(pMe->m_ePantalla==P_CAT)
							{
								pMe->m_ePantallaProc=P_CATEGORIAX;
							}
							else
							{
								if(pMe->m_ePantalla!=P_ARTISTAX)

									pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene (procedencia). Sirve para saber a 
																		 //donde regresar en caso de oprimir la tecla CLR
							}
							//C�DIGO OPCION PLAY
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
							
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0)
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   
									
							IMENUCTL_GetItemData( pMe->m_pIMenuActivo, wParam, (uint32 *)&Dato );
							// Se reserva memoria parta el primer segmento del itemData
							// porque se libera el menu en LibMem
							FREEIF(pMe->m_pID_Tono);
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);	
									
							LibMem(pMe);
							FREEIF(pMe->m_pNTono);
							FREEIF(pMe->Artista);
														

							if(!pMe->m_pIFileMgr)
								if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
									return TRUE;

							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
						
							// Se checa si se encuentra el identificador del tono
							if( EVEtiqueta( pMe, "wish.dat", "i>", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) ) //busca el valor que se encuentra entre etiquetas de i y si coincide con pMe->m_p�D_Tono
							{	

								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );	//para el formato del tono <f>
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono ); //para el titulo del tono <t>
								OVEtiqueta( pMe, "buy.dat", "a", &pMe->Artista);
								// En este caso el ringtone se encuentra en el directorio de tonos 
								// del OEM o tiene que guardarse en el.

								if( BuscaTono( pMe ) )
								{
									// C�digo para reproducir el tono que se encuentra en el 
									// directorio de tonos del celular

									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
									IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
									pMe->m_ePantalla=P_PLAYER;
									STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
									FREEIF( pMe->m_pNTono );
									IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
									IDISPLAY_Update(pMe->a.m_pIDisplay);
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
									0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);  //SE CARGA LA ANIMACION "REPRODUCE TONO", DESPUES DE HABER SIDO SATISFACTORIA LA BUSQUEDA
									IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);					
									IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88); 
									IDISPLAY_Update ( pMe->a.m_pIDisplay );
									//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
									//la ubicaci�n y el nombre del tono a reproducir
									ReproduceTono( pMe, 1 );
									FREEIF( pMe->m_pIArchivoTono );
									FREEIF( pMe->m_pID_Tono );
									return TRUE;
										
								}
								else
								{
									//	C�digo para hacer la conexi�n web y descargar el archivo 
									//	al directorio de tonos del celular
									pMe->m_u16Opcion2 = 7;
									FormarUrl( pMe, 2 );
									pMe->m_eDestInfo = BUFER;
									ConexionWeb(pMe,pMe->m_pUrlComp, NULL );
									return TRUE;
								}
							}
							else if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );
								OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "topten.dat", "a", &pMe->Artista);
							
							}
							else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );	
								OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "new.dat", "a", &pMe->Artista);
							}
							else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );	
								OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, pMe->ArchivoCat, "a", &pMe->Artista);
							}

							else if( EVEtiqueta( pMe, "tonostmp.dat", "i", pMe->m_pID_Tono ) ) //22 de abril
							{
								FNTono( pMe, "tonostmp.dat", pMe->m_pID_Tono, 3 );	
								OVEtiqueta( pMe, "tonostmp.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "tonostmp.dat", "a", &pMe->Artista);
							}
										
							if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono ) == EFAILED )
							{
								pMe->m_u16Opcion2 = 8;
								FormarUrl( pMe, 2 );
								pMe->m_eDestInfo = BUFER;
								ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
							}
							else
							{
								IFILEMGR_Release( pMe->m_pIFileMgr );
								pMe->m_pIFileMgr = NULL;
								pMe->m_ePantalla=P_PLAYER;
	                            STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
								
								IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
								IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
									
								IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								FREEIF( pMe->m_pNTono );
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,6,0);					
								IIMAGE_Start(pMe->m_pImagen1,(pMe->m_cxPantalla-102)/2,88); 
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
					            //la ubicaci�n y el nombre del tono a reproducir
								//ReproducirTono(pMe);
								ReproduceTono( pMe, 2 );
								FREEIF( pMe->m_pIArchivoTono );
								FREEIF( pMe->m_pID_Tono );
								if(pMe->edo_pantalla!=5)
								FREEIF( pMe->Artista );
							}
						
						return TRUE;
								
						case O_BUY:
							
							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
							pMe->m_ePantalla=P_BUY;
							//C�DIGO OPCION BUY
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);

							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   

							IMENUCTL_GetItemData(pMe->m_pIMenuActivo, wParam, (void *)&Dato );
							// Se reserva memoria parta el primer segmento del itemData
							// porque se libera el menu en LibMem
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);	
							LibMem(pMe);

							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;
									
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );

							if( EVEtiqueta( pMe, "wish.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
								if(pMe->Artista)
								{
								  FREE(pMe->Artista);
								  pMe->Artista=NULL;
								}
								OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);
								// Se remueve wish.dat, en dado caso de que haya m�s de un tono 
								// en este archivo se actualiza despu�s de la descarga
								IFILEMGR_Remove( pMe->m_pIFileMgr, "wish.dat");		
								
								if(IFILEMGR_Test(pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS)
								{
									pMe->m_u16Opcion2= 1;
									FormarUrl( pMe, 4 );
								}
								else
								{
									pMe->m_u16Opcion2 = 2;
									FormarUrl( pMe, 3 );
								}
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );	
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );
								if(pMe->Artista)
								{
								  FREE(pMe->Artista);
								  pMe->Artista=NULL;
								}
								OVEtiqueta( pMe, "buy.dat", "a", &pMe->Artista);
								if( BuscaTono( pMe ) )
								{
									// Mensaje al usuario de que ya se compro el ringtone
									pMe->cont = 0;
									pMe->m_u16Opcion1 = 2;
									DespliegaMensaje2( pMe, 2 );
									FREEIF( pMe->m_pID_Tono );
									FREEIF( pMe->m_pIArchivoTono );
									if(pMe->edo_pantalla!=4 && pMe->edo_pantalla!=5 && pMe->edo_pantalla!=7) //Agregue el 4 mayo del 2004
									FREEIF( pMe->Artista);
									
									//MODIFICACIONES REALIZADAS EL 13/05/04
									pMe->m_ePantalla=P_MENUINICIO;
									ISHELL_SetTimer(pMe->a.m_pIShell, 1000, (PFNNOTIFY)creaInicio, (void *)pMe);
									pMe->m_eEntorno=E_MENU;
									return TRUE;
										
								}
								else
								{									
									pMe->m_u16Opcion2 = 3;
									FormarUrl( pMe, 5 );
								}
							}
							else 
							{//solo para obtener info del nombre del tono y del artista
								if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
									if(pMe->Artista)
									{
										FREE(pMe->Artista);
										pMe->Artista=NULL;
									}
									OVEtiqueta( pMe, "topten.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
									if(pMe->Artista)
									{
								      FREE(pMe->Artista);
								      pMe->Artista=NULL;
									}
									OVEtiqueta( pMe, "new.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, "tonostmp.dat", "i", pMe->m_pID_Tono ) ) //Agregue el 7 de mayor del 2004
								{
									FNTono( pMe, "tonostmp.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "tonostmp.dat", "t", &pMe->m_pNTono );
									if(pMe->Artista)
									{
								      FREE(pMe->Artista);
								      pMe->Artista=NULL;
									}
									OVEtiqueta( pMe, "tonostmp.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
									if(pMe->Artista)
									{
								      FREE(pMe->Artista);
								      pMe->Artista=NULL;
									}
									OVEtiqueta( pMe, pMe->ArchivoCat, "a", &pMe->Artista);
								}
								
								if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS )
								{
									pMe->m_u16Opcion2 = 4;
									FormarUrl( pMe, 4 );
								}
								else
								{
									char * pTemp = NULL;
									pTemp = ( char *)MALLOC( STRLEN(pMe->m_pIArchivoTono + 4) + 1 );
									STRCPY( pTemp, pMe->m_pIArchivoTono + 4 );
									if( pMe->m_pIArchivoTono )
									{
										FREE( pMe->m_pIArchivoTono );
										pMe->m_pIArchivoTono = NULL;
									}
									pMe->m_pIArchivoTono = pTemp;
									pTemp = NULL;
									pMe->m_u16Opcion2 = 2;
									FormarUrl( pMe, 3 );
								}
							}
											
							FREEIF( pMe->m_pID_Tono );
							pMe->m_eDestInfo = BUFER;
							ConexionWeb( pMe, pMe->m_pUrlComp, NULL );
							return TRUE;

						case O_SAVE:

							if(pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_TOP10)  //Agregue el 30 de abril del 2004
							pMe->edo_pantalla=3;

							if(pMe->m_ePantalla==P_ARTISTAX && pMe->m_ePantallaProc==P_NTONOS) //Agregue el 30 de abril del 2004
							pMe->edo_pantalla=5;

							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
							pMe->m_ePantalla=P_SAVE;
							FREEIF(pMe->Artista);
							//C�DIGO OPCION SAVE
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);

							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   

							IMENUCTL_GetItemData(pMe->m_pIMenuActivo, wParam, (void *)&Dato );
							// Se reserva memoria parta el primer segmento del itemData
							// porque se libera el menu en LibMem
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);	
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							
							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;

							if( EVEtiqueta( pMe, "wish.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
								OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);

								if(IFILEMGR_Test(pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS)
								{
									//Mensaje al usuario de que ya existe en wishlist
									pMe->m_u16Opcion1 = 3;
									pMe->cont = 0;
									if(pMe->m_ePantallaProc==P_CAT && pMe->edo_pantalla==3)
									{
									  pMe->m_ePantallaProc=P_CATEGORIAX;
									}
									if(pMe->m_ePantallaProc==P_CAT && pMe->edo_pantalla==7)
									{
									  pMe->m_ePantallaProc=P_CATEGORIAX;
									}
									DespliegaMensaje2( pMe, 3 );
									return TRUE;
								}
								else
								{
									pMe->m_u16Opcion2 = 5;
									FormarUrl( pMe, 3 );
									pMe->m_eDestInfo = BUFER;
									ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
								}
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							{
								// Mensaje al usuario de que el tono ya ha sido comprado 
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );
								pMe->cont = 0;
								pMe->m_u16Opcion1 = 2;
								DespliegaMensaje2( pMe, 2 );
							}
							else 
							{
								if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, "topten.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, "new.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, "tonostmp.dat", "i", pMe->m_pID_Tono ) ) //22 de abril
								{
									FNTono( pMe, "tonostmp.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "tonostmp.dat", "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, "tonostmp.dat", "a", &pMe->Artista);
								}
								else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
									OVEtiqueta( pMe, pMe->ArchivoCat, "a", &pMe->Artista);
								}
								
								if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS )
								{
									pMe->m_u16Opcion2 = 6;
									FormarUrl( pMe, 11 );
								}
								else
								{
									pMe->m_u16Opcion2 = 5;
									FormarUrl( pMe, 10 );
								}
								FREEIF( pMe->m_pID_Tono );
								pMe->m_eDestInfo = BUFER;
								ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
							}
							
						return TRUE;

						case O_ART:
						{
								uint16 PantallaProc, Entorno;

								if(pMe->m_ePantalla==P_ARTISTAX)
								{
									pMe->ipagArt++;
								}
								else
								{
									pMe->ipagArt=0; 
								}

							
								if(pMe->ipagArt>=0 && pMe->m_ePantalla==P_CATEGORIAX && pMe->m_ePantallaProc==P_CATEGORIAS) //Agregue el 30 de abril del 2004
								pMe->edo_pantalla=4;
								
								PantallaProc=(uint16)(pMe->m_ePantallaProc);
								Entorno=(uint16)(pMe->m_eEntorno);

								if(pMe->edo_pantalla==7 && pMe->m_ePantalla==P_CAT) //Agregue el 7 de mayo de 2004 ver si es el estado correcto, documentaci�n
								pMe->m_ePantalla=P_CATEGORIAX;

							    if(pMe->m_ePantalla!=P_ARTISTAX)
								{
									if(pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_TOP10) //Agregue 30 de abril del 2004
									{
										pMe->m_ePantallaProc=P_CATEGORIAX;
									}
									else
									{
									  pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
									}
									pMe->m_ePantalla=P_ARTISTAX;
									pMe->m_eEntorno=E_ARTISTAX;
								}

								if(pMe->ipagArt==0 && pMe->m_ePantalla==P_ARTISTAX && pMe->m_ePantallaProc==P_NTONOS) //Agregue el 8 de mayo del 2004
								pMe->edo_pantalla=5;

								if(pMe->ipagArt>0 && pMe->m_ePantalla==P_ARTISTAX)
								{
									pMe->m_ePantallaProc=pMe->m_ePantalla;
								}
								
								if(pMe->ipagArt==0)
								{
									FREEIF(pMe->Artista);
									buscaDatoID1(pMe, wParam, &pMe->Artista, "a"); //Funci�n que de acuerdo al ringtone seleccionado, devuelve el artista del mismo en la variable Dato
									FREEIF(pMe->m_pIA);	
									buscaDatoID1(pMe,wParam,&pMe->m_pIA,"ia");
								}
								FREEIF(pMe->m_pNTono);
								buscaDatoID1(pMe, wParam, &pMe->m_pNTono, "t");
									
								if(pMe->m_pIA!=NULL && STRCMP(pMe->m_pIA,""))
								{
									pMe->cont = 0;
									pMe->bandera = 2;
									pMe->WP=wParam;
									pMe->m_BanderaConexion=FALSE;
											
									IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
									IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
									LibMem(pMe);
									IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
									IDISPLAY_Update(pMe->a.m_pIDisplay);
									SPRINTF(pMe->m_pIPagArt," "); //la cadena es pMe->m_pIPagArt
									SPRINTF(pMe->m_pIPagArt,"%u",pMe->ipagArt);
									FREEIF(pMe->m_pUrlComp);
									FormarUrl(pMe,9);
									pMe->m_eDestInfo = BUFER;
									IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
									IDISPLAY_Update(pMe->a.m_pIDisplay);
									ConexionWeb( pMe, pMe->m_pUrlComp, NULL);
								}
								else
								{
									pMe->ipagArt--;
									pMe->m_ePantalla=pMe->m_ePantallaProc;
									pMe->m_ePantallaProc=PantallaProc;
									pMe->m_eEntorno=Entorno;
									IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
									IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
									LibMem(pMe);

															
									//Se despliega pantalla de que no hay mas tonos para el artista seleccionado
									DespliegaMensaje2( pMe, 6 );
									pMe->m_regresoArtista=TRUE; //se activa bandera para que de el regreso del Menu adecuado
									ISHELL_SetTimer(pMe->a.m_pIShell, 1000, (PFNNOTIFY)regresaMenuMov, (void *)pMe);


									return TRUE;
								}
							
								
							return TRUE;
						}
			
						case O_CAT: //SOLO POSIBLE DE TOP10 Y DE NUEVOS TONOS ESTA ESTA OPCION
																				
								pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
								pMe->m_ePantalla=P_CAT;

								if(pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_NTONOS) //Agregue el 30 de abril del 2004
								pMe->edo_pantalla=7;

								//C�DIGO OPCI�N M�S CATEGOR�AS
								IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
								IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
								LibMem(pMe);
								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								IDISPLAY_Update(pMe->a.m_pIDisplay);
								//C�digo de prueba (a modificar de acuerdo a las verdaderas acciones planeadas de la opci�n (ver documentaci�n)
								Funcion_Common(pMe, wParam);

						return TRUE;

						case O_SORT:

								pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
								pMe->m_ePantalla=P_SORT;
								//C�DIGO OPCI�N SORT
								IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
								IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
								LibMem(pMe);
								//C�digo de prueba (a modificar de acuerdo a las verdaderas acciones planeadas de la opci�n (ver documentaci�n)
								menuSort(pMe);
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
				
						return TRUE;

						case O_DEL:
							
							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
							pMe->m_ePantalla=P_DEL;
							IMENUCTL_GetItemData(pMe->m_pIMenuActivo, wParam, (void *)&Dato );
							FREEIF(pMe->m_pID_Tono);
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);

							if(!pMe->m_pIFileMgr)
							{
								if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE ; 
							}

							if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 4);  
							IFILEMGR_Remove( pMe->m_pIFileMgr, "buy.dat" ); 
							////////////////////////////////////////////////////
							
							if(pMe->m_ePantallaProc== P_MTONOS)
							{
								FormarUrl(pMe,8);
							}
							else
							{
								FormarUrl(pMe,7);
							}
							pMe->m_eDestInfo = BUFER;
							ConexionWeb( pMe, pMe->m_pUrlComp, NULL);
							
							
							////////////////////////////////////////////////////		
							/*
							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;

							if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 4);  */
							/*
							|	Segmento para la eliminaci�n del ringtone
							*/ /*
							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_RINGERMGR, (void **)&(pMe->m_pIRingerMgr)) != SUCCESS )
								return TRUE;
							
							pMe->m_AEERingerID = IRINGERMGR_GetRingerID( pMe->m_pIRingerMgr, pMe->m_pIArchivoTono );
							
							if( pMe->m_AEERingerID != AEE_RINGER_ID_NONE )
									IRINGERMGR_Remove( pMe->m_pIRingerMgr, pMe->m_AEERingerID );
							*/
						return TRUE;
						//break; //Agregue

						default:
							break;
						}

				return TRUE;

				case P_CATEGORIAS: //men� de categor�as, cuando entra ya a CATEGORIA X

					 pMe->WP=wParam;
					 Funcion_Common(pMe, wParam);
											
				return TRUE;

				case P_SORT:
				
					if(pMe->m_pIMenuActivo)
					{
						pMe->m_ItemSeleccionado=IMENUCTL_GetSel(pMe->m_pIMenuActivo);

						switch (pMe->m_ItemSeleccionado)
						{
							case 0:
								pMe-> m_eEntorno=E_SORT_ARTISTA;
							break;
					
							case 1:
								pMe-> m_eEntorno=E_SORT_TITULO;
							break;
							
							default:
								break;
						}
					}

					Funcion_Common(pMe, pMe->WP);

				return TRUE;
					
				default:
					break;
				}
			}

	  return TRUE;

      case EVT_APP_STOP:
        
		if (pMe->m_pISoundPlayer)
		{
			 ISOUNDPLAYER_Stop(pMe->m_pISoundPlayer);
			 pMe->m_pISoundPlayer=NULL;
		}
		
		if(pMe->m_pUrlBase)
		{
			FREE( pMe->m_pUrlBase );
			pMe->m_pUrlBase=NULL;
		}
		if(pMe->m_pActualiza)
		{
			FREE( pMe->m_pActualiza );
			pMe->m_pActualiza=NULL;
		}
		if(pMe->m_pUrlComp)
		{
			FREEIF( pMe->m_pUrlComp );
			pMe->m_pUrlComp=NULL;
		}
		if(pMe->m_pTelefono)
		{
			FREE( pMe->m_pTelefono );
			pMe->m_pTelefono=NULL;
		}
		if(pMe->m_pNTono)
		{
			FREE( pMe->m_pNTono );
			pMe->m_pNTono=NULL;
		}
		if(pMe->m_pID_Tono)
		{
			FREE( pMe->m_pID_Tono );
			pMe->m_pID_Tono=NULL;
		}
		if(pMe->m_pIArchivoTono)
		{
			FREE( pMe->m_pIArchivoTono );
			pMe->m_pIArchivoTono=NULL;
		}
		if(pMe->m_pIRingerMgr)
		{
			IRINGERMGR_Release( pMe->m_pIRingerMgr );
			pMe->m_pIRingerMgr=NULL;
		}
		if(pMe->m_pITextCtl)
		{
			ITEXTCTL_Release(pMe->m_pITextCtl);
			pMe->m_pITextCtl=NULL;
		}

		RELEASEIF( pMe->m_pIMemStream );
		RELEASEIF( pMe->m_pIHtmlViewer );

		EliminaArchivos( pMe, "tmp" );
	
		if(pMe->m_pIA)
		{
			FREE(pMe->m_pIA);
			pMe->m_pIA=NULL;
		}
		if( pMe->m_pFileInfo )
		{
			FREE( pMe->m_pFileInfo );
			pMe->m_pFileInfo=NULL;
		}

		LibMem(pMe);
		pMe->cont = NULL;
		pMe->bandera = NULL;
		pMe->m_ePantalla=NULL;
	
		if(pMe->ArchivoCat)
		{	
			FREE(pMe->ArchivoCat);
			pMe->ArchivoCat = NULL;
		}

		FREEIF(pMe->m_pArtistaTemp );
		FREEIF(pMe->m_pTituloTemp );
		FREEIF(pMe->m_pTemporal );
		FREEIF(pMe->Artista);
		FREEIF(pMe->m_pID_Tono);

		if(pMe->m_pIGraphics!=NULL)
		{
			IGRAPHICS_Release(pMe->m_pIGraphics);
			pMe->m_pIGraphics=NULL;
		}

        return TRUE;



      default:
         break;
   }
   return FALSE;
}


