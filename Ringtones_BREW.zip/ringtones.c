/*===========================================================================

FILE: ringtones.c
===========================================================================*/


/*===============================================================================
INCLUDES AND VARIABLE DEFINITIONS
=============================================================================== */
#include "notiPantalla2.h"
#include "Utilerias.h"
#include "MenuGral.h"
#include "ConexionWeb.h"

/*-------------------------------------------------------------------
Function Prototypes
-------------------------------------------------------------------*/

static boolean ringtones_HandleEvent(IApplet * pi, AEEEvent eCode, 
                                      uint16 wParam, uint32 dwParam);

/*===============================================================================
FUNCTION DEFINITIONS
=============================================================================== */
boolean ringtones_InitAppData(IApplet* po)
{
	AEEDeviceInfo * pDeviceInfo = NULL;
	Cringtonesapp *pMe=(Cringtonesapp *)po;

	pDeviceInfo = ( AEEDeviceInfo * )MALLOC( sizeof(AEEDeviceInfo) );
	if( !pDeviceInfo )
		return FALSE;

	ISHELL_GetDeviceInfo( pMe->a.m_pIShell, pDeviceInfo );
	pMe->m_cxPantalla = pDeviceInfo->cxScreen;
	pMe->m_cyPantalla = pDeviceInfo->cyScreen;
	if(pDeviceInfo)
	{
		FREE( pDeviceInfo );
		pDeviceInfo=NULL;
	}

	InicializaDatosWeb(pMe);
	pMe->m_pImagen1=NULL;
	pMe->m_pIMenuActivo=NULL;
	pMe->m_pISKMenu=NULL;
	pMe->m_pIImgBanner=NULL;
	pMe->m_ePantalla=NULL;
	pMe->m_ePantallaProc=NULL;
	pMe->m_eOpcion=-1;
	pMe->m_eEntorno=NULL;
	pMe->pSoundPlayerInput=NULL;
	pMe->m_pISoundPlayer=NULL;
	pMe->m_eOpcion2=0;
	pMe->cont=NULL;
	pMe->bandera=NULL;
	pMe->m_pITapi = NULL;
	pMe->m_pContenidoBufer = NULL;
	pMe->m_pIRingerMgr = NULL;
	pMe->m_pIMemStream = NULL;
	pMe->INDICA_LETRERO = TRUE;
	
	pMe->m_pFileInfo = ( AEEFileInfo * )MALLOC( sizeof( AEEFileInfo ));
	if( !pMe->m_pFileInfo )
		return FALSE;

	if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
		return FALSE;
		
	if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
		return FALSE;


	return TRUE;
}



/*===========================================================================

FUNCTION: AEEClsCreateInstance

DESCRIPTION
	This function is invoked while the app is being loaded. All Modules must provide this 
	function. Ensure to retain the same name and parameters for this function.
	In here, the module must verify the ClassID and then invoke the AEEApplet_New() function
	that has been provided in AEEAppGen.c. 

   After invoking AEEApplet_New(), this function can do app specific initialization. In this
   example, a generic structure is provided so that app developers need not change app specific
   initialization section every time except for a call to IDisplay_InitAppData(). 
   This is done as follows: InitAppData() is called to initialize AppletData 
   instance. It is app developers responsibility to fill-in app data initialization 
   code of InitAppData(). App developer is also responsible to release memory 
   allocated for data contained in AppletData -- this can be done in 
   IDisplay_FreeAppData().

PROTOTYPE:
   int AEEClsCreateInstance(AEECLSID ClsId,IShell * pIShell,IModule * po,void ** ppObj)

PARAMETERS:
	clsID: [in]: Specifies the ClassID of the applet which is being loaded

	pIShell: [in]: Contains pointer to the IShell object. 

	pIModule: pin]: Contains pointer to the IModule object to the current module to which
	this app belongs

	ppObj: [out]: On return, *ppObj must point to a valid IApplet structure. Allocation
	of memory for this structure and initializing the base data members is done by AEEApplet_New().

DEPENDENCIES
  none

RETURN VALUE
  AEE_SUCCESS: If the app needs to be loaded and if AEEApplet_New() invocation was
     successful
  EFAILED: If the app does not need to be loaded or if errors occurred in 
     AEEApplet_New(). If this function returns FALSE, the app will not be loaded.

SIDE EFFECTS
  none
===========================================================================*/
int AEEClsCreateInstance(AEECLSID ClsId,IShell * pIShell,IModule * po,void ** ppObj)
{
   *ppObj = NULL;
		
   if(ClsId == AEECLSID_FUNCRING){
      if(AEEApplet_New(sizeof(Cringtonesapp), ClsId, pIShell,po,(IApplet**)ppObj,
         (AEEHANDLER)ringtones_HandleEvent,(PFNFREEAPPDATA)LibMem)
         == TRUE)
      {
		 if(ringtones_InitAppData((IApplet*)*ppObj))
			return (AEE_SUCCESS);
	  }
	  else{
		  IAPPLET_Release((IApplet*)*ppObj);
		  return(EFAILED);
      }
   }
	return (EFAILED);
}


/*===========================================================================

FUNCTION ringtones_HandleEvent

DESCRIPTION
	This is the EventHandler for this app. All events to this app are handled in this
	function. All APPs must supply an Event Handler.

PROTOTYPE:
	boolean ringtones_HandleEvent(IApplet * pi, AEEEvent eCode, uint16 wParam, uint32 dwParam)

PARAMETERS:
	pi: Pointer to the AEEApplet structure. This structure contains information specific
	to this applet. It was initialized during the AEEClsCreateInstance() function.

	ecode: Specifies the Event sent to this applet

   wParam, dwParam: Event specific data.

DEPENDENCIES
  none

RETURN VALUE
  TRUE: If the app has processed the event
  FALSE: If the app did not process the event

SIDE EFFECTS
  none
===========================================================================*/
static boolean ringtones_HandleEvent(IApplet * pi, AEEEvent eCode, uint16 wParam, uint32 dwParam)
{  
   Cringtonesapp * pMe = (Cringtonesapp *)pi; 
   AECHAR Buffer[50]; //Buffer de 25 caracteres
   AECHAR No_Archivo[50];
   const char *NO_ARCHIVO="No archivo";
   char *Dato;
   char *ID;
   char catx[9];
   int BANDERA=0;

   
      
   switch (eCode) 
   {
      case EVT_APP_START:                        
		    
			pMe->m_ePantalla=P_INTRO;
			pMe->m_eEntorno=E_MENU;
			
			MostrarAnimacionInicio(pMe);
			ISHELL_SetTimer(pMe->a.m_pIShell,ANIMACION_INICIO,(PFNNOTIFY)EsperaAnimacionInicio,(void*)pMe);	

			
			//EVEtiqueta(pMe, "pantallas/wish.dat", "i", "1");
		
						
		/*	pMe->m_ePantalla=P_MENUINICIO;	//Quitar
			creaInicio(pMe);				//Quitar*/

      		return(TRUE);

	  case EVT_KEY:

		  if (pMe->m_pIMenuActivo && wParam != AVK_CLR)   
		  {
			  if (IMENUCTL_HandleEvent(pMe->m_pIMenuActivo, eCode, wParam, dwParam))
				return TRUE;			  
		  }
		  
		  if (pMe->m_pISKMenu && wParam != AVK_CLR)   
		  {
			  if (IMENUCTL_HandleEvent(pMe->m_pISKMenu, eCode, wParam, dwParam))
				return TRUE;			  
		  }

		  if (wParam == AVK_CLR){

		  IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(255,255,255) );	

		  pMe->INDICA_LETRERO=1;
		  if(pMe->m_pIGraphics)
		  {
			IGRAPHICS_Release(pMe->m_pIGraphics);
			pMe->m_pIGraphics=NULL;
		  }

		 

			if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0)
				ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
			if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
				ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   

			  if(pMe->m_pIFileMgr)
		  {
			  IFILEMGR_Release(pMe->m_pIFileMgr);
			  pMe->m_pIFileMgr=NULL;
		  }	
		  if(pMe->m_pIFile)
		  {
			  IFILE_Release(pMe->m_pIFile);
			  pMe->m_pIFile=NULL; 	
		  }

		  	switch(pMe->m_ePantalla){
			
			case P_MENUINICIO:
				ISHELL_CloseApplet(pMe->a.m_pIShell,TRUE);
			return TRUE;

			case P_INTRO:
				ISHELL_CloseApplet(pMe->a.m_pIShell,TRUE);
			return TRUE;
			
			case P_TOP10:
			case P_ARTISTAX:
 				EliminaArchivos( pMe, "tmp/");
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);
			return TRUE;

			case P_CATEGORIAS:
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);
			return TRUE;

			case P_CATEGORIAX:
				EliminaArchivos( pMe, "tmp/");
				pMe->m_eEntorno=E_CATEGORIAS;
				pMe->m_ePantalla=P_CATEGORIAS;
				IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
				LibMem(pMe);
				IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
				IDISPLAY_Update ( pMe->a.m_pIDisplay );
				pMe->ipagCat=0;
				creaCategorias(pMe);
			return TRUE;

			case P_WISHLST:
				EliminaArchivos( pMe, "tmp/");
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);
			return TRUE;


			case P_NTONOS:
				EliminaArchivos( pMe, "tmp/");
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);
			return TRUE;

			case P_MTONOS:
				EliminaArchivos( pMe, "tmp/");
			
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);
			return TRUE;

			case P_PLAYER:
				//ISOUNDPLAYER_Stop(pMe->m_pISoundPlayer);
				IRINGERMGR_Stop( pMe->m_pIRingerMgr );
				IIMAGE_Stop(pMe->m_pImagen1);
				IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
				IDISPLAY_Update ( pMe->a.m_pIDisplay );
				// 
				//ISOUNDPLAYER_Release(pMe->m_pISoundPlayer);
				//pMe->m_pISoundPlayer = 0;
				RELEASEIF( pMe->m_pIRingerMgr );
				regresaMenuMov(pMe);
			return TRUE;

			case P_BUY:
			case P_SAVE:
			
			case P_CAT:
			case P_SORT:
			case P_DEL:
				
				if(pMe->m_pID_Tono)
				{
					FREE( pMe->m_pID_Tono );
					pMe->m_pID_Tono=NULL;
				}

				if(pMe->m_pIArchivoTono)
				{
					FREE( pMe->m_pIArchivoTono );
					pMe->m_pIArchivoTono=NULL;
				}
				if(pMe->m_pNTono)
				{

					FREE( pMe->m_pNTono );
					pMe->m_pNTono=NULL;

				}

				IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
				IDISPLAY_Update ( pMe->a.m_pIDisplay );
				if (pMe->m_ePantallaProc==P_CATEGORIAX){
					IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 0, 5,
					0, NULL); 
				}
				regresaMenuMov(pMe);
			return TRUE;

			case P_AYUDA:
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				pMe->bandera = 2;
				pMe->cont = 0;
				creaInicio(pMe);
			return TRUE;

			default:
			  break;
			}
		  }
		
		return TRUE;

	  case EVT_COMMAND:

			
			/*if( pMe->m_ePantalla == P_SAVE )
			{
				if( wParam == IDS_ACEPTAR )
				{
					if( ISHELL_GetTimerExpiration( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
						ISHELL_CancelTimer( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe );
					if( ISHELL_GetTimerExpiration( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
						ISHELL_CancelTimer( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe );
					
					FREEIF( pMe->m_pID_Tono );
					FREEIF( pMe->m_pIArchivoTono );
					FREEIF( pMe->m_pNTono );
					
					IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
					IDISPLAY_Update ( pMe->a.m_pIDisplay );
					
					if ( pMe->m_ePantallaProc==P_CATEGORIAX ){
						IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 0, 5,
						0, NULL); 
					}
					regresaMenuMov(pMe);
					return TRUE;
				}
			
			}*/
			if( pMe->m_ePantalla == P_BUY )
			{

				if( ISHELL_GetTimerExpiration( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
					ISHELL_CancelTimer( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe );
				if( ISHELL_GetTimerExpiration( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
					ISHELL_CancelTimer( pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe );

				if( wParam == IDS_ACEPTAR )
				{
					
					if( pMe->m_pID_Tono )
					{
						FREE( pMe->m_pID_Tono );
						pMe->m_pID_Tono=NULL;
					}
					pMe->m_eDestInfo = BUFER;
					ConexionWeb( pMe, pMe->m_pUrlComp, NULL );
					return TRUE;
				}
				if( wParam == IDS_CANCELAR )
				{
					
					if( pMe->m_pID_Tono )
					{
						FREE( pMe->m_pID_Tono );
						pMe->m_pID_Tono=NULL;
					}
					if( pMe->m_pIArchivoTono )
					{
						FREE( pMe->m_pIArchivoTono );
						pMe->m_pIArchivoTono=NULL;
					}
					if( pMe->m_pNTono )
					{
						FREE( pMe->m_pNTono );
						pMe->m_pNTono=NULL;
					}
					IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
					IDISPLAY_Update ( pMe->a.m_pIDisplay );
					if (pMe->m_ePantallaProc==P_CATEGORIAX){
						IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 0, 5,
						0, NULL); 
					}
					regresaMenuMov(pMe);
					return TRUE;
				}
			}
		   	
			if (pMe->m_pIMenuActivo) //Verifica si el menu de inicio es el que est� activo
			{

				switch(pMe->m_ePantalla){

				case P_MENUINICIO:
						switch(wParam){
						case 0: //TOP10
							pMe->m_ePantalla=P_TOP10; //Para saber la pantalla activa
							pMe->m_eEntorno=E_TOP10;  // y su correspondiente entorno
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0; //Para saber en que lugares se quedaron los menus
							pMe->m_eOpcion2=0; //de manera que si se regresa se ponga el SetSel a estos valores
							//creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
							if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
								return FALSE;
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2; //banderas y contadores de para el c�digo del menu din�mico
							if(!pMe->m_pIFileMgr)
							{
								if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
								{
									pMe->m_pIFileMgr = NULL;
									return FALSE;
								}
							}
	
							if(IFILEMGR_Test(pMe->m_pIFileMgr, "topten.dat")==SUCCESS)
							{
									creaSK(pMe);
									creaMenuMov(pMe, "topten.dat");
									DespliegaTexto(pMe);
									
						
							}
							else
							{
									STRTOWSTR(NO_ARCHIVO, No_Archivo, sizeof(No_Archivo));
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, No_Archivo, -1, 3, 0,0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									return FALSE;
							}
							if(pMe->m_pIFileMgr)
							{
							
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr=NULL;
							}

							//c�digo menu con datos en movimiento
						return TRUE;

						case 1: //CATEGOR�AS
							pMe->m_eEntorno=E_CATEGORIAS;
							pMe->m_ePantalla=P_CATEGORIAS;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->ipagCat=0;
							creaCategorias(pMe);
				
						return TRUE;

						case 2: // WISH LIST
							pMe->m_ePantalla=P_WISHLST;
							pMe->m_eEntorno=E_WISHLST;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0;
							pMe->m_eOpcion2=0;
							if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
								return FALSE;
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2;
							if(!pMe->m_pIFileMgr)
							{
								if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
								{
									pMe->m_pIFileMgr = NULL;
									return FALSE;
								}
							}
	
							if(IFILEMGR_Test(pMe->m_pIFileMgr, "wish.dat")==SUCCESS)
							{
									creaSK(pMe);
									creaMenuMov(pMe, "wish.dat");
									DespliegaTexto(pMe);
									
						
							}
							else
							{
									STRTOWSTR(NO_ARCHIVO, No_Archivo, sizeof(No_Archivo));
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, No_Archivo, -1, 3, 0,0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									return FALSE;
							}

							if(pMe->m_pIFileMgr)
							{
							
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr=NULL;
							}

						
							//c�digo menu con datos en movimiento
						return TRUE;

						case 3: // NUEVOS TONOS
							pMe->m_ePantalla=P_NTONOS;
							pMe->m_eEntorno=E_NTONOS;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=0;
							pMe->m_eOpcion2=0;
							if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
								return FALSE;
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2;
							if(!pMe->m_pIFileMgr)
							{
								if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
								{
									pMe->m_pIFileMgr = NULL;
									return FALSE;
								}
							}
	
							if(IFILEMGR_Test(pMe->m_pIFileMgr, "new.dat")==SUCCESS)
							{
									creaSK(pMe);
									creaMenuMov(pMe, "new.dat");
									DespliegaTexto(pMe);
									
						
							}
						
							else
							{
									STRTOWSTR(NO_ARCHIVO, No_Archivo, sizeof(No_Archivo));
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, No_Archivo, -1, 3, 0,0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									return FALSE;
							}
							if(pMe->m_pIFileMgr)
							{
							
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr=NULL;
							}


							//c�digo menu con datos en movimiento
						return TRUE;

						case 4: // MIS TONOS
							pMe->m_ePantalla=P_MTONOS;
							pMe->m_eEntorno=E_MTONOS;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							pMe->m_eOpcion=-1;
							pMe->m_eOpcion2=0;
							if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
								return FALSE;
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2;
							if(!pMe->m_pIFileMgr)
							{
								if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
								{
									pMe->m_pIFileMgr = NULL;
									return FALSE;
								}
							}
	
							if(IFILEMGR_Test(pMe->m_pIFileMgr, "buy.dat")==SUCCESS)
							{
									creaSK(pMe);
									creaMenuMov(pMe, "buy.dat");
									DespliegaTexto(pMe);
									
						
							}
							else
							{
									STRTOWSTR(NO_ARCHIVO, No_Archivo, sizeof(No_Archivo));
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, No_Archivo, -1, 3, 0,0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									return FALSE;
							}
							if(pMe->m_pIFileMgr)
							{
							
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr=NULL;
							}

							//c�digo menu con datos en movimiento
						return TRUE;

						case 5: // AYUDA
							pMe->m_ePantalla=P_AYUDA;
							pMe->m_eEntorno=E_AYUDA;
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							//Lugar para el c�digo de la ayuda
							
						return TRUE;
				
						default: 
							break;
						}

				case P_TOP10: //En caso de que se encuentre en una de estas
				case P_WISHLST:	//pantallas, el manejador de las acciones
				case P_MTONOS:	//del menu se comportar� de acuerdo al c�digo
				case P_NTONOS:	//de abajo
				case P_CATEGORIAX:
				case P_ARTISTAX:
						
						pMe->m_eOpcion = IMENUCTL_GetSel(pMe->m_pISKMenu); //Se obtiene el ID del bot�n del men� SoftKey seleccionado 
						pMe->m_eOpcion2=wParam; //Toma el valor del ID del men� donde se enlistan los ringtones (pMe->m_pIMenuActivo)
						switch(pMe->m_eOpcion){

						case O_PLAY: //C�digo para el bot�n de PLAY
																	
							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene (procedencia). Sirve para saber a 
																   //donde regresar en caso de oprimir la tecla CLR
							//C�DIGO OPCION PLAY
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0)
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   
									
							IMENUCTL_GetItemData( pMe->m_pIMenuActivo, wParam, (uint32 *)&Dato );
							// Se reserva memoria parta el primer segmento del itemData
							// porque se libera el menu en LibMem
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);	
									
							LibMem(pMe);

							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;

							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							// Se checa si se encuentra el identificador del tono
							if( EVEtiqueta( pMe, "wish.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							{	
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );	
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );

								// En este caso el ringtone se encuentra en el directorio de tonos 
								// del OEM o tiene que guardarse en el.

								if( BuscaTono( pMe ) )
								{
									// C�digo para reproducir el tono que se encuentra en el 
									// directorio de tonos del celular
									pMe->m_ePantalla=P_PLAYER;
									STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
									FREEIF( pMe->m_pNTono );
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
									0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
									pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
									IIMAGE_Start(pMe->m_pImagen1,8,45); //Animaci�n de reproducci�n del ringtone
									IDISPLAY_Update ( pMe->a.m_pIDisplay );
									//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
									//la ubicaci�n y el nombre del tono a reproducir
									//ReproducirTono(pMe);
									ReproduceTono( pMe, 1 );
									FREEIF( pMe->m_pIArchivoTono );
									FREEIF( pMe->m_pID_Tono );
									return TRUE;
										
								}
								else
								{
									//	C�digo para hacer la conexi�n web y descargar el archivo 
									//	al directorio de tonos del celular
									pMe->m_u16Opcion2 = 7;
									FormarUrl( pMe, 2 );
									pMe->m_eDestInfo = BUFER;
									ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
									return TRUE;
								}
							}
								else if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );	
								OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
							}
							else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );	
								OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
							}
							else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );	
								OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
							}
										
							if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono ) == EFAILED )
							{
								pMe->m_u16Opcion2 = 8;
								FormarUrl( pMe, 2 );
								pMe->m_eDestInfo = BUFER;
								ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
							}
							else
							{
								IFILEMGR_Release( pMe->m_pIFileMgr );
								pMe->m_pIFileMgr = NULL;
								pMe->m_ePantalla=P_PLAYER;
	                            STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
								FREEIF( pMe->m_pNTono );
								IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
								0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
								pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
								IIMAGE_Start(pMe->m_pImagen1,8,45); //Animaci�n de reproducci�n del ringtone
								IDISPLAY_Update ( pMe->a.m_pIDisplay );
								//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
					            //la ubicaci�n y el nombre del tono a reproducir
								//ReproducirTono(pMe);
								ReproduceTono( pMe, 2 );
								FREEIF( pMe->m_pIArchivoTono );
								FREEIF( pMe->m_pID_Tono );
							}
						
							return TRUE;
								
								
						case O_BUY:
							
							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
							pMe->m_ePantalla=P_BUY;
							//C�DIGO OPCION BUY
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   

							IMENUCTL_GetItemData(pMe->m_pIMenuActivo, wParam, (void *)&Dato );
							// Se reserva memoria parta el primer segmento del itemData
							// porque se libera el menu en LibMem
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);	
							LibMem(pMe);

							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;
									
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );

							if( EVEtiqueta( pMe, "wish.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );

								if(IFILEMGR_Test(pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS)
								{
									pMe->m_u16Opcion2= 1;
									FormarUrl( pMe, 4 );
								}
								else
								{
									pMe->m_u16Opcion2 = 2;
									FormarUrl( pMe, 3 );
								}
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 2 );	
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );

								if(IFILEMGR_Test(pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS)
								{
									// Mensaje al usuario de que ya se compro el ringtone
									pMe->cont = 0;
									pMe->m_u16Opcion1 = 2;
									DespliegaMensaje( pMe );
									if( pMe->m_pID_Tono )
									{
										FREE( pMe->m_pID_Tono );
										pMe->m_pID_Tono=NULL;
									}
									if(pMe->m_pIArchivoTono)
									{
										FREE( pMe->m_pIArchivoTono );
										pMe->m_pIArchivoTono=NULL;
									}
									if(pMe->m_pNTono)
									{
										FREE( pMe->m_pNTono );
										pMe->pSoundPlayerInput=NULL;
									}
									creaSK( pMe );
									return TRUE;
								}
								else
								{
									pMe->m_u16Opcion2 = 3;
									FormarUrl( pMe, 5 );
								}										
							}
							else 
							{
								if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
								}
								else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
								}
								else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
								}
								
								if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS )
								{
									pMe->m_u16Opcion2 = 4;
									FormarUrl( pMe, 4 );
								}
								else
								{
									pMe->m_u16Opcion2 = 2;
									FormarUrl( pMe, 3 );
								}
							}
							
							pMe->m_u16Opcion1 = 1;
							pMe->cont = 0;
							DespliegaMensaje( pMe );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update( pMe->a.m_pIDisplay );
							creaSK( pMe );
							return TRUE;

						case O_SAVE:

							pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
							pMe->m_ePantalla=P_SAVE;
							//C�DIGO OPCION SAVE
							IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
							IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);

							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
							if( ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0 )
								ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   

							IMENUCTL_GetItemData(pMe->m_pIMenuActivo, wParam, (void *)&Dato );
							// Se reserva memoria parta el primer segmento del itemData
							// porque se libera el menu en LibMem
							pMe->m_pID_Tono = (char *)MALLOC(STRLEN(Dato));
							STRCPY(pMe->m_pID_Tono, Dato);	
							LibMem(pMe);
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							
							if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
								return TRUE;

							if( EVEtiqueta( pMe, "wish.dat", "i", pMe->m_pID_Tono ) )
							{
								FNTono( pMe, "wish.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono );

								if(IFILEMGR_Test(pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS)
								{
									//Mensaje al usuario de que ya existe en wishlist
									pMe->m_u16Opcion1 = 3;
									pMe->cont = 0;
									DespliegaMensaje( pMe );
									IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
									IDISPLAY_Update( pMe->a.m_pIDisplay );
									creaSK( pMe );
									return TRUE;
								}
								else
								{
									pMe->m_u16Opcion2 = 5;
									FormarUrl( pMe, 3 );
									pMe->m_eDestInfo = BUFER;
									ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
								}
							}
							else if( EVEtiqueta( pMe, "buy.dat", "i", pMe->m_pID_Tono ) )
							{
								// Mensaje al usuario de que el tono ya ha sido comprado 
								FNTono( pMe, "buy.dat", pMe->m_pID_Tono, 1);
								OVEtiqueta( pMe, "buy.dat", "t", &pMe->m_pNTono );
								pMe->cont = 0;
								pMe->m_u16Opcion1 = 2;
								DespliegaMensaje( pMe );
								IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
								IDISPLAY_Update( pMe->a.m_pIDisplay );
								creaSK( pMe );
							}
							else 
							{
								if( EVEtiqueta( pMe, "topten.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "topten.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "topten.dat", "t", &pMe->m_pNTono );
								}
								else if( EVEtiqueta( pMe, "new.dat", "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, "new.dat", pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, "new.dat", "t", &pMe->m_pNTono );
								}
								else if( EVEtiqueta( pMe, pMe->ArchivoCat, "i", pMe->m_pID_Tono ) )
								{
									FNTono( pMe, pMe->ArchivoCat, pMe->m_pID_Tono, 3 );	
									OVEtiqueta( pMe, pMe->ArchivoCat, "t", &pMe->m_pNTono );
								}
								
								if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono) == SUCCESS )
								{
									pMe->m_u16Opcion2 = 6;
									FormarUrl( pMe, 11 );
								}
								else
								{
									pMe->m_u16Opcion2 = 5;
									FormarUrl( pMe, 10 );
								}
								pMe->m_eDestInfo = BUFER;
								ConexionWeb(pMe, pMe->m_pUrlComp, NULL );
							}
							
						return TRUE;

						case O_ART:
									pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
									pMe->m_ePantalla=P_ARTISTAX;
									pMe->m_eEntorno=E_ARTISTAX;
									//C�DIGO OPCI�N M�S ARTISTA
									IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
									IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
									LibMem(pMe);
									IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
									//C�digo de prueba (a modificar de acuerdo a las verdaderas acciones planeadas de la opci�n (ver documentaci�n)

									/*ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_VERMAS,Buffer,sizeof(Buffer));
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
									0, NULL);*/

									buscaDatoID(pMe, wParam, &Dato, "a");//Funci�n que de acuerdo al ringtone seleccionado, devuelve el artista del mismo en la variable Dato
									STRTOWSTR(Dato, Buffer, 2 * (STRLEN(Dato)+1) );

																
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, NULL, 35,
									0, IDF_ALIGN_CENTER); //se despliega el nombre del artista en la pantalla 
									creaSK(pMe);
									pMe->cont = 0;
									pMe->bandera = 1;
									creaMenuMov(pMe, "pantallas/tonosTMP.dat");
									DespliegaTexto(pMe);

									IDISPLAY_Update ( pMe->a.m_pIDisplay );
						return TRUE;

						case O_CAT:
									pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
									pMe->m_ePantalla=P_CAT;
									pMe->m_eEntorno = E_CATEGORIAX;

									//C�DIGO OPCI�N M�S CATEGOR�AS
									IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
									IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
									LibMem(pMe);
									IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
									//C�digo de prueba (a modificar de acuerdo a las verdaderas acciones planeadas de la opci�n (ver documentaci�n)

									buscaDatoID(pMe, wParam, &Dato, "c");//Funci�n que de acuerdo al ringtone seleccionado, devuelve la categor�a del mismo en la variable Dato
									STRTOWSTR(Dato, Buffer, 2 * (STRLEN(Dato)+1) );
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, NULL, 0,
									0, IDF_ALIGN_LEFT|IDF_ALIGN_TOP); //se despliega el nombre del artista en la pantalla 																		
									buscaDatoID(pMe, wParam, &ID, "ic");
									SPRINTF(catx,"cat%s.dat",ID);
									
												
							pMe->m_eOpcion=0; //Para saber en que lugares se quedaron los menus
							pMe->m_eOpcion2=0; //de manera que si se regresa se ponga el SetSel a estos valores
							creaSK(pMe); //crea el menu Soft Key de acuerdo al valor de pMe->m_ePantalla
					/*		if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_GRAPHICS,&pMe->m_pIGraphics)!=SUCCESS)
								return FALSE;*/
							//c�digo menu con datos en movimiento
							pMe->cont = 0;
							pMe->bandera = 2; //banderas y contadores de para el c�digo del menu din�mico
							
							
							creaMenuMov(pMe, catx);
							
							DespliegaTexto(pMe);
							//c�digo menu con datos en movimiento
							IDISPLAY_Update( pMe->a.m_pIDisplay );

						return TRUE;

						case O_SORT:
									pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
									pMe->m_ePantalla=P_SORT;
									//C�DIGO OPCI�N SORT
									IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
									IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
									LibMem(pMe);
									//C�digo de prueba (a modificar de acuerdo a las verdaderas acciones planeadas de la opci�n (ver documentaci�n)

									
									menuSort(pMe);
									IDISPLAY_Update ( pMe->a.m_pIDisplay );
						return TRUE;

						case O_DEL:
									pMe->m_ePantallaProc=pMe->m_ePantalla; //Guarda la pantalla de la que proviene
									pMe->m_ePantalla=P_DEL;
									//C�DIGO OPCI�N DELETE
									IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
									IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
									LibMem(pMe);
									IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );

									//C�digo de prueba (a modificar de acuerdo a las verdaderas acciones planeadas de la opci�n (ver documentaci�n)

									ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_ELIMINAR,Buffer,sizeof(Buffer));
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
									0, NULL);

									buscaDatoID(pMe, wParam, &Dato, "t");
									STRTOWSTR(Dato, Buffer, 2 * (STRLEN(Dato)+1) );
																		
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 20,
									0, NULL);

									IDISPLAY_Update ( pMe->a.m_pIDisplay );
						return TRUE;

						default:
							break;
						}
				return TRUE;

				case P_CATEGORIAS: //men� de categor�as
					pMe->m_ePantallaProc=pMe->m_ePantalla;
					pMe->m_ePantalla=P_CATEGORIAX;
					pMe->m_eEntorno=E_CATEGORIAX;
					IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
					IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
					IDISPLAY_Update ( pMe->a.m_pIDisplay );
					LibMem(pMe);
					pMe->m_eOpcion=0;
					pMe->m_eOpcion2=0;
					creaSK(pMe);
					//c�digo menu con datos en movimiento
					pMe->cont = 0;
					pMe->bandera = 2;

					buscaDatoID(pMe, wParam, &Dato, "c");
					STRTOWSTR(Dato, pMe->BufferCat, 2 * (STRLEN(Dato)+1) );
					IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 0, 5,
					0, NULL); //despliega el nombre de la categor�a en la esquina superior izquierda
					buscaDatoID(pMe, wParam+1, &Dato, "ic"); //(wParam+1) por detalles de la funci�n
					pMe->ArchivoCat = (char *)MALLOC(13 + STRLEN(Dato) + 5);
					if (pMe->ipagCat==0){
						
						STRCPY(pMe->ArchivoCat, "cat");
						STRCAT(pMe->ArchivoCat, Dato);
						STRCAT(pMe->ArchivoCat, ".dat");
						BANDERA=creaMenuMov(pMe, pMe->ArchivoCat); //Utiliza el archivo catX.dat, donde X es el valor de <ic>
						
					}
					else{
						/*descargar el archivo de (URL_BASE/inalambrico/categoria.php?i=ic&p=ipagCat)
						en el archivo /tonosTMP.dat
						Checar el valor de la etiqueta <n>,
						Si es mayor que cero
							cargar el men� de �ste archivo
						si no 
							mostrar mensaje de que ya no existen m�s tonos para esa categoria
							Decrementar ipagCat;
							Pasar a la pantalla 5 con el valor de <ic>*/
					}
					if(BANDERA==TRUE)
					{
						DespliegaTexto(pMe);
					}
					else
					{
						return(FALSE);
					}
					//c�digo menu con datos en movimiento
					
						
				return TRUE;

				case P_SORT:
					//C�digo para el men� sobre la pantalla (de ordenamiento)
				return TRUE;
					
				default:
					break;

				}
			}

		 return TRUE;

      case EVT_APP_STOP:

		LiberaWeb(pMe);
		LiberaUtil(pMe);
		 if (pMe->m_pISoundPlayer)
			 ISOUNDPLAYER_Stop(pMe->m_pISoundPlayer);
		 if( pMe->m_pUrlBase )
		 {
			FREE( pMe->m_pUrlBase );
			pMe->m_pUrlBase=NULL;
		 }
		 if(pMe->m_pActualiza)
		 {
			FREE( pMe->m_pActualiza );
			pMe->m_pActualiza=NULL;
		 }
		if(pMe->m_pUrlComp)
		{
			FREE( pMe->m_pUrlComp );
			pMe->m_pUrlComp=NULL;
		}
		if(pMe->m_pTelefono)
		{
			FREE(pMe->m_pTelefono );
			pMe->m_pTelefono=NULL;
		}	
		if(pMe->m_pNTono )
		{
			FREE( pMe->m_pNTono );
			pMe->m_pNTono =NULL;
		}
		if(pMe->m_pID_Tono)	
		{
			FREE( pMe->m_pID_Tono );
			pMe->m_pID_Tono=NULL;
		}	
			
		if(pMe->m_pIArchivoTono)
		{
			FREE( pMe->m_pIArchivoTono );
			pMe->m_pIArchivoTono=NULL;
		}
		 EliminaArchivos( pMe, "tmp" );
		 if(pMe->m_pFileInfo)
		 {
			FREE( pMe->m_pFileInfo );
			pMe->m_pFileInfo=NULL;
		 }
		 LibMem(pMe);
		 pMe->cont = NULL;
		 pMe->bandera = NULL;
		 pMe->m_ePantalla=NULL;  
		 if(pMe->ArchivoCat)
						
		 {	
			FREE(pMe->ArchivoCat);
			pMe->ArchivoCat = NULL;
		 }

         return TRUE;

  	  case EVT_APP_SUSPEND:

		  if (pMe->m_ePantalla!=P_INTRO)  LibMem(pMe);

		   //c�digo conexi�nweb
	      if(pMe->m_bDispEnProgreso)
		  {
			DetenerAnimDescarga(pMe);
		  }
		  //c�digo conexi�nweb

         return TRUE;
      case EVT_APP_RESUME:

		  /* //c�digo conexi�nweb
		  if(!pMe->m_bDispEnProgreso)
		  {
			IniciaAnimDescarga(pMe);
		  }
		  //c�digo conexi�nweb*/
		  LibMem(pMe);
		  pMe->m_eEntorno=E_MENU;
		  pMe->m_ePantalla=P_MENUINICIO;
		  creaInicio(pMe);

         return TRUE;
      default:
         break;
   }
   return FALSE;
}


