#ifndef MENUGRAL_H
#define MENUGRAL_H

#include "notiPantalla2.h"

extern void LiberaMenuGral(Cringtonesapp *pMe);

extern boolean creaInicio(Cringtonesapp *pMe);

extern boolean creaSK(Cringtonesapp *pMe);

extern boolean creaMenuMov(Cringtonesapp * pMe, const char * pszFile);

extern boolean regresaMenuMov(Cringtonesapp * pMe);

extern boolean creaEntorno(Cringtonesapp * pMe);

extern boolean creaCategorias(Cringtonesapp * pMe);

extern boolean menuSort(Cringtonesapp * pMe);

extern boolean PonMarco(Cringtonesapp *pMe);

extern void Flechas(Cringtonesapp * pMe);

#endif