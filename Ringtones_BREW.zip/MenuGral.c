#include "MenuGral.h"
#include "notiPantalla2.h"
#include "Utilerias.h"
#include "ConexionWeb.h"

void LiberaMenuGral(Cringtonesapp *pMe)
{
	if (pMe->m_pIMenuActivo)  //Verifica si el menu de inicio est� activo
	{
		uint16 i = 0;
		char* data;
		if(pMe->m_ePantalla!=P_INTRO && pMe->m_ePantalla!=P_MENUINICIO)
		{
			while (IMENUCTL_GetItemData(pMe->m_pIMenuActivo, i++, (uint32*)&data))
			{
				if (data)   
				FREE(data);
			}  //mientras haya elementos en el menu de inico, se libera la memoria
		}
			IMENUCTL_Release(pMe->m_pIMenuActivo); 
			pMe->m_pIMenuActivo = NULL; //Liberaci�n del menu de inicio
	}

	if (pMe->m_pISKMenu)  //Verifica si el menu de inicio est� activo
	{
			uint16 i = 0;
			char* data;

			while (IMENUCTL_GetItemData(pMe->m_pISKMenu, i++, (uint32*)&data))
			{
				if (data)   
				FREE(data);
			}  //mientras haya elementos en el menu de inico, se libera la memoria

			IMENUCTL_Release(pMe->m_pISKMenu); 
			pMe->m_pISKMenu = NULL; //Liberaci�n del menu de inicio
	}


}


boolean creaInicio(Cringtonesapp *pMe)
{
	AEERect		rAreaAct;
	CtlAddItem A1;

	if (!pMe->m_pIMenuActivo){
	if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
		return FALSE;
	}
		
	creaEntorno(pMe);

	if (pMe->m_ProfColor>=8) SETAEERECT(&(rAreaAct), 5,42,pMe->m_cxPantalla-19,pMe->m_cyPantalla-65);	
	else SETAEERECT(&(rAreaAct), 0,46,pMe->m_cxPantalla-13,pMe->m_cyPantalla-75);	
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_TOP10);

	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pText = NULL;
	A1.pImage = pMe->m_pImagen1;
	A1.pszResImage = A1.pszResText = NULL;
	A1.wFont =0;
	A1.dwData = 0;
	A1.wText =NULL;
	A1.wImage = NULL;
	A1.wItemID =0;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);

	IIMAGE_Release(pMe->m_pImagen1);
	pMe->m_pImagen1=NULL;
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_CATEGORIAS);

	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pImage = pMe->m_pImagen1;
	A1.wItemID =1;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
	IIMAGE_Release(pMe->m_pImagen1);
	pMe->m_pImagen1=NULL;
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_ID);

	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pImage = pMe->m_pImagen1;
	A1.wItemID =2;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);

	IIMAGE_Release(pMe->m_pImagen1);
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_WISHLST);
	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pImage = pMe->m_pImagen1;
	A1.wItemID =3;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);

	IIMAGE_Release(pMe->m_pImagen1);
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_NTONOS);

	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pImage = pMe->m_pImagen1;
	A1.wItemID =4;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);

	IIMAGE_Release(pMe->m_pImagen1);
	pMe->m_pImagen1=NULL;
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_MTONOS);

	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pImage = pMe->m_pImagen1;
	A1.wItemID =5;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);

	IIMAGE_Release(pMe->m_pImagen1);
	pMe->m_pImagen1=NULL;
		
	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_AYUDA);
	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	A1.pImage = pMe->m_pImagen1;
	A1.wItemID =6;
	IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
	
	IIMAGE_Release(pMe->m_pImagen1);
	pMe->m_pImagen1=NULL;

	IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
	IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
	IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
	IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_BI_STATE_IMAGE);
	IMENUCTL_Redraw(pMe->m_pIMenuActivo);
	IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
	Flechas(pMe);
	return TRUE;
}

boolean creaSK(Cringtonesapp *pMe)
{
	AEERect		rAreaAct;

	if(!pMe->m_pISKMenu)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_SOFTKEYCTL, (void **)&pMe->m_pISKMenu) != SUCCESS)
			return FALSE;
	}

	pMe->m_AEEMenCol.wMask=(MC_BACK | MC_SEL_BACK | MC_TEXT | MC_SEL_TEXT);
	
	pMe->m_AEEMenCol.cBack=MAKE_RGB(194,224,156);
	pMe->m_AEEMenCol.cSelBack=MAKE_RGB(0,0,0);
	pMe->m_AEEMenCol.cSelText=MAKE_RGB(255,255,255);
	pMe->m_AEEMenCol.cText=MAKE_RGB(0,0,0);

	pMe->pActive.ft=AEE_FT_NONE;
	pMe->pActive.xOffset=1;
	pMe->pActive.yOffset=1;
	pMe->pActive.roImage=AEE_RO_TRANSPARENT;
	pMe->pNormal.ft=AEE_FT_NONE;
	pMe->pNormal.xOffset=1;
	pMe->pNormal.yOffset=1;
	pMe->pNormal.roImage=AEE_RO_TRANSPARENT;

	SETAEERECT(&(rAreaAct), 0,pMe->m_cyPantalla-15,pMe->m_cxPantalla,15); 

	
	if(pMe->m_ePantalla==P_IDINFO)
	{
		if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		{
			IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BPLAY, 0, NULL, NULL);
			IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BBUY, 1, NULL, NULL);
		}
	}

	if(pMe->m_ePantalla==P_IDTONOCOMPRADO)
	{
		if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO)
		{
			IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BPLAY, 0, NULL, NULL);
			IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BMENU, 1, NULL, NULL);
		}
	}
			
	if( pMe->m_ePantalla != P_BUY && pMe->m_ePantalla != P_SAVE )
		if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
			IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BPLAY, 0, NULL, NULL);

	if(pMe->m_ePantalla==P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_ACEPTAR, IDS_ACEPTAR, NULL, NULL);

	if (pMe->m_ePantalla!=P_MTONOS && pMe->m_ePantalla != P_BUY && pMe->m_ePantalla != P_SAVE ) 
			
	if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)	
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BBUY, 1, NULL, NULL);

	if (pMe->m_ePantalla==P_TOP10 || pMe->m_ePantalla==P_CATEGORIAX || pMe->m_ePantalla==P_NTONOS || pMe->m_ePantalla==P_ARTISTAX) 
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BSAVE, 2, NULL, NULL);

	else
	{
		if (pMe->m_ePantalla==P_WISHLST)
			IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BDEL, 2, NULL, NULL);
	}

	if (pMe->m_ePantalla==P_TOP10 || pMe->m_ePantalla==P_NTONOS || pMe->m_ePantalla==P_CATEGORIAX || pMe->m_ePantalla==P_ARTISTAX || pMe->m_ePantalla==P_CAT)
			
	if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BSAVE, 2, NULL, NULL);

	if (pMe->m_ePantalla==P_TOP10 || pMe->m_ePantalla==P_NTONOS || pMe->m_ePantalla==P_CATEGORIAX || pMe->m_ePantalla==P_ARTISTAX || pMe->m_ePantalla==P_CAT)
			
	if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BART, 3, NULL, NULL);

	if (pMe->m_ePantalla==P_TOP10 || pMe->m_ePantalla==P_NTONOS)
			
	if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BCAT, 4, NULL, NULL);

	if (pMe->m_ePantalla==P_WISHLST || pMe->m_ePantalla==P_MTONOS || pMe->m_ePantalla==P_CATEGORIAX)
			
	if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BSORT, 5, NULL, NULL);

	if (pMe->m_ePantalla==P_WISHLST || pMe->m_ePantalla==P_MTONOS || pMe->m_ePantalla==P_CATEGORIAX || pMe->m_ePantalla == P_TOP10 || pMe->m_ePantalla == P_NTONOS )
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BSORT, 5, NULL, NULL);

	if (pMe->m_ePantalla==P_WISHLST || pMe->m_ePantalla==P_MTONOS)
			
	if(pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_BDEL, 6, NULL, NULL);

	if (pMe->m_ePantalla==P_BUY && pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
	{
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_ACEPTAR, IDS_ACEPTAR, NULL, NULL);
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_CANCELAR, IDS_CANCELAR, NULL, NULL);
	}

	if (pMe->m_ePantalla==P_SAVE && pMe->m_ePantalla!=P_ID && pMe->m_ePantalla!=P_IDINFO && pMe->m_ePantalla!=P_IDTONOCOMPRADO)
		IMENUCTL_AddItem(pMe->m_pISKMenu, RINGTONES_RES_FILE, IDS_ACEPTAR, IDS_ACEPTAR, NULL, NULL);
		
	IMENUCTL_SetRect(pMe->m_pISKMenu,&rAreaAct);
	IMENUCTL_SetColors(pMe->m_pISKMenu,&pMe->m_AEEMenCol);
	IMENUCTL_SetStyle(pMe->m_pISKMenu,&pMe->pNormal,&pMe->pActive);
	IMENUCTL_SetSel(pMe->m_pISKMenu,  (uint16)pMe->m_eOpcion);
	IMENUCTL_Redraw(pMe->m_pISKMenu);
	IMENUCTL_SetActive(pMe->m_pISKMenu,TRUE);

	return TRUE;
}

boolean creaMenuMov(Cringtonesapp * pMe, const char * pszFile){
	// Construcci�n del menu

	AEERect		rAreaAct;
	CtlAddItem  A1;
	char *pFileBuf='\0';
	char *FileBuf='\0';
	AECHAR iAENom[50];
	uint16 contador;
	char *End;
	char *i, *t, *a, *c, *n;//*ia, *ic;
	AECHAR Artist[50];
	int N;
	
	FileInfo pFInfo;
	char *itemData;
	boolean SIGUE_CICLO=TRUE;
	uint32 i32Tmp;
	
	if (pMe->m_ProfColor>=8) IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
	else IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);
	
	IGRAPHICS_ClearViewport(pMe->m_pIGraphics);

	if(pMe->m_pIFileMgr)
	{
		IFILEMGR_Release( pMe->m_pIFileMgr );
		pMe->m_pIFileMgr = NULL;
		
	}

	if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}	

	if(!pMe->m_pIMenuActivo)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
			return FALSE;
	}

	
	SETAEERECT(&(rAreaAct), 5,40,pMe->m_cxPantalla-19,pMe->m_cyPantalla-62);	

	

	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	if(IFILEMGR_Test(pMe->m_pIFileMgr, pszFile)==SUCCESS)
	{
		if(!pMe->m_pIFile)
			pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pszFile, _OFM_READ);
	}
	else
	{
		return FALSE;
	}
	
	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
		return FALSE;
	 
	
	if (pMe->m_pIFile )
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		i32Tmp = IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]='\0';
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
	if(pMe->m_pIFile)
	{
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}

	if (pMe->m_pIFileMgr)
	{
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}
	//Lectura del pMe->ArchivoCat que tiene info de catx.dat para O_CAT
	
	
	if(STRBEGINS("cat",pszFile)==TRUE  || STRCMP(pszFile,"tonostmp.dat")==0  )
	{
		if (TagContents(&FileBuf,"n",&n,&End))
		{
			N=ATOI(n);
			pMe->NTONOS_TMP=N;
			if(N==0)
			{
				
				SPRINTF(pMe->m_pIPagArt," "); //la cadena es pMe->m_pIPagArt
				SPRINTF(pMe->m_pIPagArt,"%u",pMe->ipagArt);
				pMe->ipagArt--;

				if(pMe->ipagArt>=0)
				{
					IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
					IDISPLAY_Update(pMe->a.m_pIDisplay);
				}
				else
				{
						FREEIF(pFileBuf);
						pFileBuf=NULL;
						return TRUE; ////////////////
				}
			}
		}
	}
	
	creaEntorno(pMe);
	
	contador=0;
	
	
	if(pMe->m_ePantalla!=P_ARTISTAX) // EN EL CASO DE QUE LA PANTALLA SEA DIFERENTE DEL ARTISTA X, SI ES IGUAL ENTONCES NO BUSCA ETIQUETAS QUE NO EXISTAN Y EL METODO CAMBIA
	{

		if(pMe->m_eSort==FALSE)
		{
			
			if (pMe->m_ePantalla!=P_NTONOS) pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_BULLET);
			else pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_BULLETNTONOS);
			IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
			
			while(SIGUE_CICLO)
			{

				if (!TagContents(&FileBuf,"i>",&i,&End))
				break;

				TagContents(&FileBuf,"t",&t,&End);
				TagContents(&FileBuf,"a",&a,&End);
				TagContents(&FileBuf,"c",&c,&End);
				STRTOWSTR(t, iAENom, 2 * (STRLEN(t)+1) );

				itemData = NULL;
				ConcatenaSegmento(&itemData, i, 1);
				ConcatenaSegmento(&itemData, "ARTISTA:", 2);
				ConcatenaSegmento(&itemData, a, 3);
				ConcatenaSegmento(&itemData, "CATEGOR�A", 4);
				ConcatenaSegmento(&itemData, c, 5);

				A1.pText = iAENom;
				A1.pImage = pMe->m_pImagen1;
				A1.pszResImage = A1.pszResText = NULL;
				A1.wFont =0;
				A1.dwData = (uint32)itemData;
				A1.wText =NULL;
				A1.wImage = NULL;
				A1.wItemID =contador;
				IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
				contador++;

			}

			FREEIF(pFileBuf);
			pFileBuf=NULL;

			//IIMAGE_Release(pMe->m_pImagen1);
			RELEASEIF(pMe->m_pImagen1);
			itemData=NULL;
			
			IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
			IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
			IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
			IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_BI_STATE_IMAGE);
			IMENUCTL_SetSel(pMe->m_pIMenuActivo, pMe->m_eOpcion2);
			IMENUCTL_Redraw(pMe->m_pIMenuActivo);
			IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
		}

		else //en caso de que exista un SORT
		{
			FREEIF(pFileBuf);
			pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_BULLET);
			IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
			OrdenaTonos(pMe);
		}
	}
	else //cuando la pantalla es igual al ARTISTA_X
	{
 		STRTOWSTR(pMe->Artista, Artist, sizeof(Artist));
		pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_BULLET);
		IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);

		

		while(SIGUE_CICLO)
		{
				
			itemData=NULL;
			if (!TagContents(&FileBuf,"i>",&i,&End))
				break;
			TagContents(&FileBuf,"t",&t,&End);
			TagContents(&FileBuf,"c",&c,&End);

			STRTOWSTR(t, iAENom, 2 * (STRLEN(t)+1) );
			
			//FREEIF(pFileBuf);
			//pFileBuf=NULL;
			//return;

			ConcatenaSegmento(&itemData, i, 1);	
			ConcatenaSegmento(&itemData, "ARTISTA:", 2);
			ConcatenaSegmento(&itemData,pMe->Artista, 3);
			ConcatenaSegmento(&itemData, "CATEGOR�A", 4);
			ConcatenaSegmento(&itemData, c, 5);
						
			A1.pText = iAENom;
			A1.pImage = pMe->m_pImagen1;
			A1.pszResImage = A1.pszResText = NULL;
			A1.wFont =0;
			A1.dwData = (uint32)itemData;
			A1.wText =NULL;
			A1.wImage = NULL;
			A1.wItemID =contador;
			IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
			contador++;
		}

		FREEIF(pFileBuf);
		pFileBuf=NULL;
        

		IIMAGE_Release(pMe->m_pImagen1);
		pMe->m_pImagen1=NULL;
		itemData=NULL;

		//return;
		IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
		IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
		IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
		IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_BI_STATE_IMAGE);
		IMENUCTL_SetSel(pMe->m_pIMenuActivo, pMe->m_eOpcion2);
		IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
		IMENUCTL_Redraw(pMe->m_pIMenuActivo);
	}

	
	Flechas(pMe); 
	return TRUE;
} 

boolean regresaMenuMov(Cringtonesapp * pMe){
		
	if(pMe->m_regresoArtista==FALSE)
	{
		pMe->m_ePantalla=pMe->m_ePantallaProc;
	}
	
	LibMem(pMe);
	
	//c�digo menu con datos en movimiento
	pMe->cont = 0;
	//La bandera se establece en 2 porque el primer segmento del itemData corresponde al
	// identificador del tono
	pMe->bandera = 2;

	switch(pMe->m_ePantalla){
		case P_TOP10:
			pMe->m_eEntorno=E_TOP10;
			creaMenuMov(pMe, "topten.dat");
		break;
		case P_WISHLST:
			pMe->m_eEntorno=E_WISHLST;
			if(creaMenuMov(pMe, "wish.dat")==FALSE)
			{
				EliminaArchivos( pMe, "tmp/");
				LibMem(pMe);
				pMe->m_eEntorno=E_MENU;
				pMe->m_ePantalla=P_MENUINICIO;
				creaInicio(pMe);
				return TRUE;
			}
		break;
		case P_NTONOS:
			pMe->m_eEntorno=E_NTONOS;
			creaMenuMov(pMe, "new.dat");
		break;
		case P_MTONOS:
			pMe->m_eEntorno=E_MTONOS;
			creaMenuMov(pMe, "buy.dat");
		break;
		case P_CATEGORIAX:
			pMe->m_eEntorno=E_CATEGORIAX;
			creaMenuMov(pMe, pMe->ArchivoCat);
		break;
		case P_ARTISTAX:
			pMe->m_eEntorno=E_ARTISTAX;
			creaMenuMov(pMe, "tonosTMP.dat");
		break;
		case P_IDINFO:
			CuadroTextoInfo(pMe);
		break;
		case P_IDTONOCOMPRADO:
			CuadroTonoComprado(pMe);
		break;
		
	}

	DespliegaTexto(pMe);
	creaSK(pMe);
	return TRUE;
}

boolean creaEntorno(Cringtonesapp * pMe){
	
	AEELine		rLinea;

	pMe->m_AEEMenCol.wMask=(MC_BACK | MC_SEL_BACK | MC_TEXT | MC_SEL_TEXT);

	if (pMe->m_ProfColor>=8) 
	{
		pMe->m_AEEMenCol.cBack=COLORBACK;
		pMe->m_AEEMenCol.cSelBack=COLORSELBACK;
		pMe->m_AEEMenCol.cSelText=COLORTEXTSEL;
		pMe->m_AEEMenCol.cText=COLORTEXT;
	}
	else
	{
		pMe->m_AEEMenCol.cBack=MAKE_RGB(255,255,255);
		pMe->m_AEEMenCol.cSelBack=MAKE_RGB(0,0,0);
		pMe->m_AEEMenCol.cSelText=MAKE_RGB(255,255,255);
		pMe->m_AEEMenCol.cText=MAKE_RGB(0,0,0);
	}

	pMe->pActive.ft=AEE_FT_NONE;
	pMe->pActive.xOffset=1;
	pMe->pActive.yOffset=1;
	pMe->pActive.roImage=AEE_RO_TRANSPARENT;
	pMe->pNormal.ft=AEE_FT_NONE;
	pMe->pNormal.xOffset=1;
	pMe->pNormal.yOffset=1;
	pMe->pNormal.roImage=AEE_RO_TRANSPARENT;


	switch (pMe->m_eEntorno){

		case E_MTONOS:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_MTONOSBAN);
				
			}
		break;
	
	    case E_MENU:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
				if (pMe->m_ProfColor>=8) IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
				else IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);
				IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
				pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_MENU);
			}
		break;

		case E_TOP10:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_TOP10BAN);
			}
		break;

		case E_WISHLST:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_WLSTBAN);
			}
		break;
		
		case E_NTONOS:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_NTONOSBAN);
			}
		break;

		case E_ARTISTAX:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_ARTBAN);
			}
		break;

		case E_AYUDA:
			
		break;

		case E_CATEGORIAX:
		case E_SORT_ARTISTA:
		case E_SORT_TITULO:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
				IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, RGB_BLACK );
				if (pMe->m_ProfColor>=8)
				{
					if( pMe->m_ePantalla == P_CATEGORIAX || pMe->m_ePantalla == P_CATEGORIAS) // || pMe->m_ePantalla == P_CAT )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_CATICO);
					}
					if( pMe->m_ePantalla == P_TOP10 )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_TOP10BAN);
					}
					if( pMe->m_ePantalla == P_NTONOS )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_NTONOSBAN);
					}
					if( pMe->m_ePantalla == P_WISHLST )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_WLSTBAN);
					}
					if( pMe->m_ePantalla == P_MTONOS )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_MTONOSBAN);
					}
				}
				else 
				{
					if( pMe->m_ePantalla == P_CATEGORIAX || pMe->m_ePantalla == P_CATEGORIAS )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, RGB_WHITE );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_CATICO2);
					}
					if( pMe->m_ePantalla == P_TOP10 )
					{
						IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
						pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_TOP10);
					}
				}

				
				if(pMe->m_ePantalla==P_CAT){
						Fondo_ID(pMe);
						IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_NORMAL, pMe->BufferCat, -1, 0, 0, NULL, 0);

				}
				else
				{
					IIMAGE_Draw(pMe->m_pIImgBanner,2,5);
					IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 15, 5, 0, 0); //despliega el nombre de la categor�a en la esquina superior izquierda
				}
								
			}
		break;

		case E_CATEGORIAS:
			if(pMe->m_ePantalla!=P_PLAYER)
			{
					pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_CATBAN);
			}
		break;

		default:
			break;
	}
	
	if(pMe->m_pIImgBanner!=NULL)//&& pMe->m_eEntorno!=E_CATEGORIAX
	{
	  IIMAGE_Draw(pMe->m_pIImgBanner,5,7);
	  RELEASEIF(pMe->m_pIImgBanner);
	}

	if (pMe->m_ProfColor>=8) pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGO);
	else pMe->m_pIImgBanner=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGO2);
	IIMAGE_Draw(pMe->m_pIImgBanner,pMe->m_cxPantalla-26,2);
	RELEASEIF(pMe->m_pIImgBanner);
	
	rLinea.sx=30;
	rLinea.sy=21;
	rLinea.ex=(uint16)(pMe->m_cxPantalla-5);
	rLinea.ey=21;
	IGRAPHICS_DrawLine(pMe->m_pIGraphics, &rLinea);
	
	PonMarco(pMe);
	
	IDISPLAY_Update ( pMe->a.m_pIDisplay );

	return TRUE;
}


boolean creaCategorias(Cringtonesapp * pMe){

	AEERect		rAreaAct;
	CtlAddItem  A1;
	AECHAR iAENom[50];
	char *End;
	char *pFileBuf;
	char *FileBuf;
	FileInfo pFInfo;
	uint16 contador;
	char *c,  *pTemp; 
	char *ic=NULL;
	boolean SIGUE_CICLO=TRUE;


	if (!pMe->m_pIMenuActivo)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
			return FALSE;
	}


	if (pMe->m_ProfColor>=8) IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
	else IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);
	IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
	SETAEERECT(&(rAreaAct), 9,48,pMe->m_cxPantalla-23,pMe->m_cyPantalla-72);	

	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	if(!pMe->m_pIFile)
		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "categorias.dat", _OFM_READ);

	
	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
		return FALSE;
	

	if (pMe->m_pIFile )
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
	if(pMe->m_pIFile)
	{
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr)
	{
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}

	creaEntorno(pMe);

	pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_BULLETCAT);
	IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,2,0);
	contador=0;

	while(SIGUE_CICLO)
	{

		if (!TagContents(&FileBuf,"ic",&ic,&End))
			break;

		if (!TagContents(&FileBuf,"c",&c,&End))
			break;

		pTemp = ( char * )MALLOC( STRLEN(ic) + 1 );
		if( !pTemp ) break;

		STRTOWSTR(c, iAENom, 2 * (STRLEN(c)+1) );
		
		A1.pText = iAENom;
		A1.pImage = pMe->m_pImagen1;
		A1.pszResImage = A1.pszResText = NULL;
		A1.wFont =0;
		A1.dwData = NULL;
		A1.wText =NULL;
		A1.wImage = NULL;
		A1.wItemID =contador;
		IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
		contador++;

		FREEIF(pTemp);
		
	}

	FREEIF(pFileBuf);
	pFileBuf=NULL;
	IIMAGE_Release(pMe->m_pImagen1);
	IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
	IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
	IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
	IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_BI_STATE_IMAGE);
	IMENUCTL_Redraw(pMe->m_pIMenuActivo);
	IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
	Flechas(pMe);

	return TRUE;
}

boolean menuSort(Cringtonesapp * pMe){

	AEERect		rAreaAct;
	AECHAR Buffer[14];
	
	if (!pMe->m_pIMenuActivo)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
			return FALSE;
	}

	pMe->m_AEEMenCol.wMask=(MC_BACK | MC_SEL_BACK | MC_TEXT | MC_SEL_TEXT);
	pMe->m_AEEMenCol.cBack=MAKE_RGB(255,255,255);
	pMe->m_AEEMenCol.cSelBack=MAKE_RGB(0,0,0);
	pMe->m_AEEMenCol.cSelText=MAKE_RGB(255,255,255);
	pMe->m_AEEMenCol.cText=MAKE_RGB(0,0,0);
	pMe->pActive.ft=AEE_FT_NONE;
	pMe->pActive.xOffset=1;
	pMe->pActive.yOffset=1;
	pMe->pActive.roImage=AEE_RO_TRANSPARENT;
	pMe->pNormal.ft=AEE_FT_NONE;
	pMe->pNormal.xOffset=1;
	pMe->pNormal.yOffset=1;
	pMe->pNormal.roImage=AEE_RO_TRANSPARENT;

	SETAEERECT(&(rAreaAct), (pMe->m_cxPantalla/2)-40,(pMe->m_cyPantalla/2)-38,80,68);
	IDISPLAY_DrawFrame(pMe->a.m_pIDisplay,&rAreaAct,AEE_FT_BOX,MAKE_RGB(255,255,255));
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_ORDENAR,Buffer,sizeof(Buffer));
	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, RGB_BLACK );
	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(255,255,255) );
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, (pMe->m_cxPantalla/2)-36, (pMe->m_cyPantalla/2)-33,
	0, 0);
	SETAEERECT(&(rAreaAct), (pMe->m_cxPantalla/2)-36,(pMe->m_cyPantalla/2)-15,72,40);
	
	IMENUCTL_AddItem(pMe->m_pIMenuActivo,RINGTONES_RES_FILE,IDS_ARTSORT,0, NULL, 0);
	IMENUCTL_AddItem(pMe->m_pIMenuActivo,RINGTONES_RES_FILE,IDS_TITSORT,1, NULL, 0);
	IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
	IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
	IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
	IMENUCTL_Redraw(pMe->m_pIMenuActivo);
	IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
	return TRUE;
}

boolean PonMarco(Cringtonesapp *pMe)
{
	int inix,iniy,finx,finy;
	int i;
	AEEPoint Punto;
	AEELine Linea;

	inix=2;
	finx=pMe->m_cxPantalla-3;
	iniy=39;
	finy=pMe->m_cyPantalla-23; 

	IGRAPHICS_SetPointSize(pMe->m_pIGraphics, 2);
	
	//linea de puntos arriba
	for (i=inix+5;i<=finx-4;i=i+4)
	{
		Punto.x=(uint16)i;
		Punto.y=(uint16)iniy;
		IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);
	}

	//linea de puntos verticales izq
	for (i=iniy+6;i<=finy-4;i=i+4)
	{
		Punto.x=(uint16)inix;
		Punto.y=(uint16)i;
		IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);
	}

	//linea horizontal abajo
	Linea.sx=(uint16)(inix+5);
	Linea.sy=(uint16)finy;
	Linea.ex=(uint16)(finx-5);
	Linea.ey=(uint16)finy;

	IGRAPHICS_DrawLine(pMe->m_pIGraphics,&Linea);
	Linea.sy++;
	Linea.ey++;
	IGRAPHICS_DrawLine(pMe->m_pIGraphics,&Linea);

	//linea vertical derecha
	Linea.sx=(uint16)finx;
	Linea.sy=(uint16)(iniy+5);
	Linea.ex=(uint16)finx;
	Linea.ey=(uint16)(finy-5);
	IGRAPHICS_DrawLine(pMe->m_pIGraphics,&Linea);

	Linea.sx++;
	Linea.ex++;
	IGRAPHICS_DrawLine(pMe->m_pIGraphics,&Linea);

	//punto esquina superior izq
	Punto.x=(uint16)(inix+2);
	Punto.y=(uint16)(iniy+2);
	IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);

	//punto esquina inferior izq
	Punto.x=(uint16)(inix+2);
	Punto.y=(uint16)(finy-2);
	IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);

	//punto esquina superior der
	Punto.x=(uint16)(finx-2);
	Punto.y=(uint16)(iniy+2);
	IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);

	//puntos esquina inferior der
	Punto.x=(uint16)(finx-2);
	Punto.y=(uint16)(finy-2);
	IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);

	Punto.x=(uint16)(finx-4);
	Punto.y=(uint16)(finy-1);
	IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);

	Punto.x=(uint16)(finx-1);
	Punto.y=(uint16)(finy-4);
	IGRAPHICS_DrawPoint(pMe->m_pIGraphics, &Punto);

	IGRAPHICS_Update(pMe->m_pIGraphics);

	return TRUE;
}

void Flechas(Cringtonesapp * pMe)
{
	if(pMe->m_ePantalla!=P_SORT){
		if (pMe->m_pIMenuActivo){
			if (pMe->m_ProfColor>=8) pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_FLECHAS);
			else pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_FLECHAS2);
			IIMAGE_SetParm(pMe->m_pImagen1,IPARM_NFRAMES,3,0);
			pMe->m_pItem = IMENUCTL_GetSel (pMe->m_pIMenuActivo);
			if (pMe->m_pItem==0){
				IIMAGE_DrawFrame(pMe->m_pImagen1, 2, pMe->m_cxPantalla-12, 44);
				IIMAGE_DrawFrame(pMe->m_pImagen1, 1, pMe->m_cxPantalla-12, 48+(pMe->m_cyPantalla-84));
			}
			else{
				if(pMe->m_pItem==(IMENUCTL_GetItemCount(pMe->m_pIMenuActivo)-1)){
					IIMAGE_DrawFrame(pMe->m_pImagen1, 0, pMe->m_cxPantalla-12, 44);
					IIMAGE_DrawFrame(pMe->m_pImagen1, 2, pMe->m_cxPantalla-12, 48+(pMe->m_cyPantalla-84));
				}
				else{
					IIMAGE_DrawFrame(pMe->m_pImagen1, 0, pMe->m_cxPantalla-12, 44);
					IIMAGE_DrawFrame(pMe->m_pImagen1, 1, pMe->m_cxPantalla-12, 48+(pMe->m_cyPantalla-84));
				}
			}
			IDISPLAY_Update ( pMe->a.m_pIDisplay );
			LimpiarIm(pMe);
		}
	}
}
