#ifndef CONEXIONWEB_H
#define CONEXIONWEB_H

#include "notiPantalla2.h"

extern boolean ConexionWeb(Cringtonesapp * pMe, char * pUrl, char * pNom);

extern void LeerDatosWebCB(void* pCxt);

extern void LiberaWeb(Cringtonesapp * pMe);

extern void LiberaUtil(Cringtonesapp * pMe);

extern void DetenerAnimDescarga(Cringtonesapp * pMe);

extern void IniciaAnimDescarga(Cringtonesapp * pMe);

extern void InicializaDatosWeb(Cringtonesapp * pMe);

extern void EstadoConexion(Cringtonesapp * pMe, int aLinea, int16 iResID);

extern void NotificacionEstadoWeb(void* pDatosNotificacion, WebStatus ws);



#endif