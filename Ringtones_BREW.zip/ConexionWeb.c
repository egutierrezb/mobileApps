#include "ConexionWeb.h"
#include "Utilerias.h"
#include "MenuGral.h"




//=========================================================================
//=========================================================================

boolean ConexionWeb(Cringtonesapp * pMe, char * pUrl, char * pNom)
{
	char *pTemp;
	
// Se crea una instancia IWeb y guarda la direcci�n en pMe->m_pIWeb. Tambi�n se crea una instancia IHeap para verificar la memoria disponible. Si falla alguna de las dos,  regresa FALSE

if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_WEB, (void**)(&pMe->m_pIWeb)) != SUCCESS)
	{

		LiberaWeb(pMe);
		LiberaUtil(pMe);

		// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n que maneje las 
// situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().

		DespliegaError(pMe, "Memoria insuficiente");
		return FALSE;
	}

	// Nos aseguramos que los miembros de la estructura que se van a utilizar estan correctamente inicializados

	pMe->m_pContenidoBufer = NULL;
	pMe->m_iTamanioBufer = 0;
	pMe->m_iMemAsigBuf = 0;

	// Se utiliza la funci�n definida en AEEStdLib CALLBACK_Init para establecer LeerDatosWebCB como la funci�n de llamada de regreso. La estructura AEECallback que se requiere   
              //inicializar es pMe->m_Callback, y el apuntador que va a ser pasado a LeerDatosWebCB es pMe.
	
	CALLBACK_Init(&pMe->m_Callback, LeerDatosWebCB, pMe);

	// Se especifica el destino de los datos que se descargan de la p�gina Web

	switch(pMe->m_eDestInfo)
	{
		case ARCHIVO:  // El nombre se extrae a partir del url
					
if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void**)(&pMe->m_pIFileMgr)) != SUCCESS))
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n // que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n 
//DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return FALSE;
			}

			pTemp = pUrl + STRLEN(pUrl);

			while(*pTemp != '/')
				pTemp--;

			pTemp++;
			pMe->m_pNomArchivo = (char *)MALLOC(STRLEN(pTemp) + 1);
			
			if(pMe->m_pNomArchivo)
			{
				STRCPY(pMe->m_pNomArchivo, pTemp);


				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->m_pNomArchivo, _OFM_CREATE);

				if(!pMe->m_pIFile)
				{
					LiberaWeb(pMe);
					LiberaUtil(pMe);
					

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra // funci�n que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la 
// funci�n DespliegaError().

DespliegaError(pMe, "Memoria insuficiente");
					return FALSE;
				}
			}
			else
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
				

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return FALSE;
			}

			break;

		case BUFER:   // Los datos se almacenan en pMe->m_pContenidoBufer

			if(ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_HEAP, (void**)(&pMe->m_pIHeap)) != SUCCESS)
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
				

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return FALSE;
			}

			break;

		case NOMBARCHIVO:   // El nombre del archivo lo especifica el programador
			
			if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR,  (void**)(&pMe->m_pIFileMgr)) != SUCCESS))
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
				

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return FALSE;
			}
		
			pMe->m_pNomArchivo = (char *)MALLOC(STRLEN(pNom) + 1);
			
			if(pMe->m_pNomArchivo)
			{
				STRCPY(pMe->m_pNomArchivo, pNom);

				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->m_pNomArchivo, _OFM_CREATE);

				if(!pMe->m_pIFile)
				{
					LiberaWeb(pMe);
					LiberaUtil(pMe);
					

					// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra 
// funci�n que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la //	// funci�n DespliegaError().

					DespliegaError(pMe, "Memoria insuficiente");
					return FALSE;
				}
			}
			else
			{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
				

// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n // que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n 
// DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return FALSE;
			}
			
			break;
	}

	// A continuaci�n se llama a la funci�n IWEB_GetResponse(), que establece la conexi�n con la p�gina Web.
	return TRUE;
	pMe->m_bBand = TRUE;

	if ((pMe->m_pIImgDescarga[PROG_TELEFONO] = ISHELL_LoadResImage(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDB_TELEFONO))==NULL ||
	     (pMe->m_pIImgDescarga[PROG_COMPUTADORA]  = ISHELL_LoadResImage(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDB_COMPUTADORA))==NULL ||
	    (pMe->m_pIImgDescarga[PROG_ANIM]  = ISHELL_LoadResImage(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDB_ANIM))==NULL)
	{
		IWEB_GetResponse(pMe->m_pIWeb, (pMe->m_pIWeb, &pMe->m_pIWebResp, &pMe->m_Callback, pUrl, 
					WEBOPT_END));
	}
	else
	{
		IWEB_GetResponse(pMe->m_pIWeb, (pMe->m_pIWeb, &pMe->m_pIWebResp, &pMe->m_Callback, pUrl, 
		            WEBOPT_HANDLERDATA, pMe, 
		            WEBOPT_STATUSHANDLER, NotificacionEstadoWeb,
		            WEBOPT_END));
	}
	
	return TRUE;
}

//=========================================================================
//=========================================================================

void LeerDatosWebCB(void* pCxt)
{
	int iContBytes;
	char pBuf[128];
	WebRespInfo* pWebRespInfo;	        // Nos dice el estado de nuestra conexi�n Web.
	ISource* pISource;		        // Obtenemos los datos a trav�s de esta interfaz.
	
	// Regresa cuando llamamos CALLABACK_Init, A continuaci�n se hace el cast
	// para utilizar los datos miembros de la estructura de la aplicaci�n.

	Cringtonesapp * pMe = (Cringtonesapp *)pCxt;

	// Se inicializa pWebRespInfo mediante la funci�n IWEBRESP_GetInfo. Se llama a LiberaWeb()
	// y regresa  la funci�n si falla la siguiente instrucci�n.

	pWebRespInfo = IWEBRESP_GetInfo(pMe->m_pIWebResp);

	
	if (!pWebRespInfo || !WEB_ERROR_SUCCEEDED(pWebRespInfo->nCode))  // Se cumple la condici�n cuando no hay conexi�n disponible
	{	
		LiberaWeb(pMe);
		LiberaUtil(pMe);
			
		// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n que maneje las 
// situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().
														
DespliegaError(pMe, "No hay conexi�n disponible");
		
return;
	}

	if(pMe->m_bBand)
	{
		
		switch(pMe->m_eDestInfo){

		case ARCHIVO:
		case NOMBARCHIVO:
			{
			if(IFILEMGR_GetFreeSpace(pMe->m_pIFileMgr, NULL) < (uint32)(pWebRespInfo->lContentLength + 1000))
				{
				LiberaWeb(pMe);
				LiberaUtil(pMe);
			// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n //que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n //DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return;
				}
			}
			break;

		case BUFER:

			if(!IHEAP_CheckAvail(pMe->m_pIHeap, (pWebRespInfo->lContentLength) + 1000))
			{
				LiberaWeb(pMe);	
				LiberaUtil(pMe);
					
// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n // que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n 
//  DespliegaError().

				DespliegaError(pMe, "Memoria insuficiente");
				return;
			}

			IHEAP_Release(pMe->m_pIHeap);
			pMe->m_pIHeap = NULL;
			
			break;
		}
		
		pMe->m_bBand = FALSE;

	}

	// Se establece la direcci�n del apuntador a la fuente de datos de la cual vamos a leer el 
	// contenido de la p�gina Web.

	pISource = pWebRespInfo->pisMessage;
	
	// Leemos el contenido de la p�gina Web y lo almacenamos en pBuf[].

	iContBytes = ISOURCE_Read(pISource, (char*)pBuf, sizeof(pBuf));

	// ISOURCE_Read() regresa valores que caen dentro de las siguioentes cuatro categor�as:
	//
	//   1. ISOURCE_WAIT:  Significa que los datos todav�a no est�n disponibles.
	//   2. ISOURCE_ERROR: Ocurri� un error
	//   3. ISOURCE_END:   No hay m�s datos que leer
	//   4. >0 : El n�mero de bytes que fu� le�do

	switch (iContBytes)
	{
		case ISOURCE_WAIT:

			// Se llama ISOURCE_Readable() para esperar la siguiente llamada de regreso.			
			ISOURCE_Readable(pISource, &pMe->m_Callback);

			return;

		case ISOURCE_ERROR:                      // No encuentra m�s datos

			if(pMe-> m_eDestInfo != BUFER )
IFILEMGR_Remove(pMe->m_pIFileMgr, pMe->m_pNomArchivo);

			LiberaWeb(pMe);
			LiberaUtil(pMe);			
			
// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  mandar llamar a otra funci�n que //maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().

			DespliegaError(pMe, "Se perdi� la conexi�n");

			return;

		case ISOURCE_END:

			// No hay m�s datos, por lo que se inserta un null al final del bufer y se manda llamar la funci�n que manipula el contenido descargado de la p�gina Web.

			switch(pMe->m_eDestInfo)
			{
			case ARCHIVO:
			case NOMBARCHIVO:
			
				LiberaWeb(pMe);		

				break;
				
			case BUFER:
	
				if (pMe->m_iTamanioBufer < pMe->m_iMemAsigBuf)
					pMe->m_pContenidoBufer[pMe->m_iTamanioBufer] = 0;
				
				else
					pMe->m_pContenidoBufer[pMe->m_iMemAsigBuf - 1] = 0;

					CALLBACK_Cancel(&pMe->m_Callback);

					if (pMe->m_pIWebResp)
					{
						IWEBRESP_Release(pMe->m_pIWebResp);
						pMe->m_pIWebResp = NULL;
					}

					if (pMe->m_pIWeb) 
					{
						IWEB_Release(pMe->m_pIWeb);
						pMe->m_pIWeb = NULL;
					}

				break;
			}

			LiberaUtil(pMe);	
			CreaArchivos( pMe, FALSE );
			FREEIF( pMe->m_pContenidoBufer );
			
			// Aqu� se inserta el c�digo para llamar la funci�n que manipula los datos descargados de la p�gina Web, o bien se puede lanzar un evento mediante 
// ISHELL_SendEvent. La funci�n que manipula el contenido de la p�gina Web debe recibir como argumento un apuntador a la estructura de la aplicaci�n, para que 
// tenga acceso a los datos miembro m_pContenidoBufer y m_iMemAsigBuf, en caso de que los datos est�n en el Bufer o apuntadores a las instancias IFile en el caso //de que los datos est�n almacenados en un archivo.

			IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
			IDISPLAY_Update(pMe->a.m_pIDisplay);
			switch( pMe->m_ePantalla )
			{
			case P_INTRO:
				pMe->m_ePantalla=P_MENUINICIO;	//Quitar
				creaInicio(pMe);				//Quitar
				break;
			
			case P_TOP10: //En caso de que se encuentre en una de estas
			case P_WISHLST:	//pantallas, el manejador de las acciones
			case P_MTONOS:	//del menu se comportar� de acuerdo al c�digo
			case P_NTONOS:	//de abajo
			case P_CATEGORIAX:
			case P_ARTISTAX:
			case P_BUY:
			case P_SAVE:
				
				switch( pMe->m_eOpcion )
				{
				case O_PLAY:
					{
						AECHAR Buffer[50] = {0};
						
						creaEntorno(pMe);
						pMe->m_ePantalla=P_PLAYER;
						STRTOWSTR(pMe->m_pNTono, Buffer, 2 * (STRLEN(pMe->m_pNTono)+1) );
						IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 3, 0,
						0, NULL); //Aqu� se despliega el t�tulo previamente obtenido para saber qu� ringtone se reproduce
						pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_PLAYER_AN);
						IIMAGE_Start(pMe->m_pImagen1,8,45); //Animaci�n de reproducci�n del ringtone
						IDISPLAY_Update ( pMe->a.m_pIDisplay );
						//Funci�n que reproduce un tono (usa el apuntador pMe->m_pIArchivoTono para saber
						//la ubicaci�n y el nombre del tono a reproducir
						ReproducirTono(pMe);
						FREEIF( pMe->m_pNTono );
						FREEIF( pMe->m_pID_Tono );
						FREEIF( pMe->m_pIArchivoTono );
						break;
					}					
				case O_BUY:
					{
						switch( pMe->m_u16Opcion2 )
						{
						// Se mueve el archivo pMe->m_pIArchivoTono a dir_Tonos_Sel
						case 1:
							FREEIF( pMe->m_pNTono );
							FREEIF( pMe->m_pIArchivoTono );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							regresaMenuMov(pMe);
							return;
						case 2:
							// Se mueve el archivo de tono que se acaba de
							// descargar a dir_Tonos_Sel
							FREEIF( pMe->m_pNTono );
							FREEIF( pMe->m_pIArchivoTono );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							regresaMenuMov(pMe);
							return;
						case 3:
							// Se mueve el archivo de tono que se acaba de
							// descargar a dir_Tonos_Sel
							FREEIF( pMe->m_pNTono );
							FREEIF( pMe->m_pIArchivoTono );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							regresaMenuMov(pMe);
							/*pMe->cont = 0;
							pMe->m_u16Opcion1 = 2;
							DespliegaMensaje( pMe );*/
							return;
						case 4:
							// Se mueve el tono de temp a dir_Tonos_Sel
							FREEIF( pMe->m_pNTono );
							FREEIF( pMe->m_pIArchivoTono );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							regresaMenuMov(pMe);
						}
					}
					break;
				case O_SAVE:
					switch( pMe->m_u16Opcion2 )
					{
						case 5:
							// Se crea el archivo dir_tonos_cel
							// CreaTono( pMe );
							FREEIF( pMe->m_pNTono );
							FREEIF( pMe->m_pIArchivoTono );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							regresaMenuMov(pMe);
							return;
						case 6:
							// Se mueve el tono de tmp/id_tono a
							// tonos tonos/id_tono
							FREEIF( pMe->m_pNTono );
							FREEIF( pMe->m_pIArchivoTono );
							IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
							IDISPLAY_Update ( pMe->a.m_pIDisplay );
							regresaMenuMov(pMe);
							return;
					}
				}
				break;
			}
				
			return;

		default:

			if(pMe->m_bDispEnProgreso)
			{
				EstadoConexion(pMe, 0, IDS_WEBS_CONNECTED);
				EstadoConexion(pMe, 1, IDS_WEBS_DESCARGANDO);
			}
			// Se almacena en el buffer o en el archivo los datos disponibles en ISource.
			if (iContBytes)
			{
				switch(pMe->m_eDestInfo)
				{
					case ARCHIVO:
					case NOMBARCHIVO:

						if(!IFILE_Write(pMe->m_pIFile, (void *)(pBuf), iContBytes))
						{
							IFILEMGR_Remove(pMe->m_pIFileMgr, pMe->m_pNomArchivo);
							LiberaWeb(pMe);
							LiberaUtil(pMe);
							
							// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) o si prefiere  //mandar llamar a otra funci�n que maneje las situaciones de error. Es responsabilidad del programador crear la funci�n alternativa //en caso de que no desee utilizar la funci�n DespliegaError().

							DespliegaError(pMe, "Memoria insuficiente");
							return;
						}

						break;

					case BUFER:

							if (pMe->m_iTamanioBufer + iContBytes >
 pMe->m_iMemAsigBuf)
							{
							         const int iNuevoTamanio = pMe->m_iMemAsigBuf + 512;
							         char* pNuevoBuf = (char*)REALLOC(
                                           pMe->m_pContenidoBufer,
                                        iNuevoTamanio);

								if (pNuevoBuf)
								{
									pMe->m_pContenidoBufer = pNuevoBuf;
									pMe->m_iMemAsigBuf = iNuevoTamanio;
								}
								else
								{	
									LiberaWeb(pMe);
									LiberaUtil(pMe);
									
// En caso de que el programador lo considere necesario puede desplegar un mensaje de error (opci�n por default) //o si prefiere  mandar llamar a otra funci�n que maneje las situaciones de error. Es responsabilidad del //programador crear la funci�n alternativa en caso de que no desee utilizar la funci�n DespliegaError().

									DespliegaError(pMe, "Memoria insuficiente");
									return;
								}
							}
							if (pMe->m_iTamanioBufer + iContBytes <= pMe->m_iMemAsigBuf)
							{
								MEMCPY(pMe->m_pContenidoBufer + pMe->m_iTamanioBufer, pBuf, iContBytes);
								pMe->m_iTamanioBufer += iContBytes;
							}					

						break;
				}

			}

			// Esperamos por la siguiente llamada de regreso (como en el caso de ISOURCE_WAIT).

			ISOURCE_Readable(pISource, &pMe->m_Callback);
			return;
	}

}

//=========================================================================
//=========================================================================

void LiberaWeb(Cringtonesapp * pMe)
{
	if (pMe->m_pIWebResp)
	{
		IWEBRESP_Release(pMe->m_pIWebResp);
		pMe->m_pIWebResp = NULL;
	}

	if (pMe->m_pIWeb) 
	{
		IWEB_Release(pMe->m_pIWeb);
		pMe->m_pIWeb = NULL;
	}

	if (pMe->m_pContenidoBufer)
	{
		FREE(pMe->m_pContenidoBufer);
		pMe->m_pContenidoBufer = NULL;
	}

	CALLBACK_Cancel(&pMe->m_Callback);
	pMe->m_iTamanioBufer = 0;
	pMe->m_iMemAsigBuf = 0;

}

//=========================================================================
//=========================================================================

void LiberaUtil(Cringtonesapp * pMe)
{
			if(pMe->m_pIFile)
			{
				IFILE_Release(pMe->m_pIFile);
				pMe->m_pIFile = NULL;
			}

			if(pMe->m_pIFileMgr)
			{
				IFILEMGR_Release(pMe->m_pIFileMgr);
				pMe->m_pIFileMgr = NULL;
			}

			if(pMe->m_pIHeap)
			{
				IHEAP_Release(pMe->m_pIHeap);
				pMe->m_pIHeap = NULL;
			}

			if(pMe->m_pIImgDescarga[0])
			{
				IIMAGE_Release(pMe->m_pIImgDescarga[0]);
				pMe->m_pIImgDescarga[0] = NULL;
			}

			if(pMe->m_pIImgDescarga[1])
			{
				IIMAGE_Release(pMe->m_pIImgDescarga[1]);
				pMe->m_pIImgDescarga[1] = NULL;
			}

			if(pMe->m_pIImgDescarga[2])
			{
				IIMAGE_Release(pMe->m_pIImgDescarga[2]);
				pMe->m_pIImgDescarga[2] = NULL;
			}

			pMe->m_bDispEnProgreso = FALSE;
}

//=========================================================================
//=========================================================================

void DespliegaError(Cringtonesapp * pMe, char *pMsg)
{
	AECHAR pBuf [25];
	
	STR_TO_WSTR( pMsg, pBuf, sizeof(pBuf) );
	IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
	IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, pBuf, -1, 0, 0, 0, IDF_ALIGN_TOP | IDF_ALIGN_LEFT );
	IDISPLAY_Update( pMe->a.m_pIDisplay );
}

//=========================================================================
//=========================================================================

void IniciaAnimDescarga(Cringtonesapp * pMe)
{
	AEERect r;

	if(!pMe->m_bDispEnProgreso)
	{
		pMe->m_bDispEnProgreso = TRUE;

		SETAEERECT(&r, (pMe->m_cxPantalla - CX_PROG_DESPLEGAR)/2, (pMe->m_cyPantalla - CY_PROG_DESPLEGAR)/2, 
															CX_PROG_DESPLEGAR, CY_PROG_DESPLEGAR);
		IDISPLAY_EraseRect(pMe->a.m_pIDisplay, &r);
		IDISPLAY_FrameRect(pMe->a.m_pIDisplay, &r);

		IIMAGE_Draw(pMe->m_pIImgDescarga[PROG_TELEFONO], r.x + 10, r.y + 32);
		IIMAGE_Draw(pMe->m_pIImgDescarga[PROG_COMPUTADORA],  r.x + 52, r.y + 44);
		IIMAGE_SetParm(pMe->m_pIImgDescarga[PROG_ANIM], IPARM_NFRAMES, 4, 0);
		IIMAGE_Start(pMe->m_pIImgDescarga[PROG_ANIM], r.x + 28, r.y + 48);
	}
}

//=========================================================================
//=========================================================================

void EstadoConexion(Cringtonesapp * pMe, int iLinea, int16 iResID)
{
	AECHAR TextBuf[32];

	if (ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, iResID,
			TextBuf, TAMANIOARREGLO(TextBuf)))
	{
		int iMaxLineas;
		AEERect rc;

		iMaxLineas = (pMe->m_cyPantalla / ALTOLINEA) - 2;
		if (iMaxLineas < 1)
			iMaxLineas = 1;
   
		// 0 always first; lines 1...n cycle
		// 0 clears all other lines

		rc.x = (int16)((pMe->m_cxPantalla - CX_PROG_DESPLEGAR)/2 + MARGEN);
		rc.dx = CX_PROG_DESPLEGAR - 2 * MARGEN;

		if (iLinea > 0)
			iLinea = (iLinea - 1) % iMaxLineas + 1;

		rc.y = (int16)((pMe->m_cyPantalla - CY_PROG_DESPLEGAR)/2 + 1 + (iLinea * ALTOLINEA));
		rc.dy = ALTOLINEA;
		if (iLinea == 0)
			rc.dy = CY_PROG_DESPLEGAR - MARGEN - 40;

		IDISPLAY_DrawText(pMe->a.m_pIDisplay,
					(AEEFont)(iLinea == 0 ? AEE_FONT_BOLD : AEE_FONT_NORMAL),
					TextBuf, -1, rc.x, rc.y, &rc, IDF_RECT_FILL);
		IDISPLAY_Update(pMe->a.m_pIDisplay);
	}
}

//=========================================================================
//=========================================================================

void NotificacionEstadoWeb(void* pDatosNotificacion, WebStatus ws)
{
	Cringtonesapp * pMe = (Cringtonesapp*)pDatosNotificacion;
	int iLineaEstado = 1;
	int16 iResID = 0;

	// Make sure the progress box is up
	if (!pMe->m_bDispEnProgreso)
		IniciaAnimDescarga(pMe);

	switch (ws)
	{
	case WEBS_CANCELLED:
		iResID = IDS_WEBS_CANCELLED;
		break;
	case WEBS_GETHOSTBYNAME:
		iResID = IDS_WEBS_GETHOSTBYNAME;
		iLineaEstado = 0;
		break;		  
	case WEBS_CONNECT:
		iResID = IDS_WEBS_CONNECT;
		iLineaEstado = 0;
		break;
	case WEBS_SENDREQUEST:
		EstadoConexion(pMe, 0, IDS_WEBS_CONNECTED);
		iResID = IDS_WEBS_SENDREQUEST;
		break;
	case WEBS_READRESPONSE:
		iResID = IDS_WEBS_READRESPONSE;
		break;
	case WEBS_GOTREDIRECT:
		iResID = IDS_WEBS_REDIRECT;
		break;
	case WEBS_CACHEHIT:
		iResID = IDS_WEBS_CACHEHIT;
		break;
	}

	if (iResID)
		EstadoConexion(pMe, iLineaEstado, iResID);
}

//=========================================================================
//=========================================================================

void DetenerAnimDescarga(Cringtonesapp * pMe)
{
	if (pMe->m_bDispEnProgreso)
	{
		pMe->m_bDispEnProgreso = FALSE;
		IIMAGE_Stop(pMe->m_pIImgDescarga[PROG_ANIM]);
	}
}

//=========================================================================
//=========================================================================

void InicializaDatosWeb(Cringtonesapp * pMe)
{

			AEEDeviceInfo devinf;

			pMe->m_pIWeb = NULL;
			pMe->m_pIWebResp = NULL;
			pMe->m_pContenidoBufer = NULL;
			pMe->m_pNomArchivo = NULL;
			pMe->m_pIFileMgr = NULL;
			pMe->m_pIFile = NULL;
			pMe->m_pIHeap = NULL;

			pMe->m_pIImgDescarga[0] = NULL;
			pMe->m_pIImgDescarga[1] = NULL;
			pMe->m_pIImgDescarga[2] = NULL;

			pMe->m_bDispEnProgreso = FALSE;

			ISHELL_GetDeviceInfo(pMe->a.m_pIShell, &devinf);
			pMe->m_cxPantalla = devinf.cxScreen;
			pMe->m_cyPantalla = devinf.cyScreen;
			pMe->m_ProfColor = devinf.nColorDepth;
}



