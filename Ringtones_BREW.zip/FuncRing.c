/*===========================================================================

FILE: FuncRing.c
===========================================================================*/


/*===============================================================================
INCLUDES AND VARIABLE DEFINITIONS
=============================================================================== */
#include "AEEModGen.h"          // Module interface definitions
#include "AEEAppGen.h"          // Applet interface definitions
#include "AEEShell.h"           // Shell interface definitions
#include "funcring.bid"
#include "AEEStdLib.h"
#include "AEEFile.h"
#include "AEETapi.h"

typedef struct _CRingApp
{
	AEEApplet		a;
	IFileMgr	*	m_pIFileMgr;
	IFile		*	m_pIFile;
	// bufers utilizados para las conexiones
	char	* m_pUrlBase;
	char	* m_pUrlComp;
	char	* m_pActualiza;
	char    * m_pTelefono;
	ITAPI*		m_pITapi;
	// Aqui se almacena el ID del tono que se quiera descargar
	char    * m_pID_Tono;
	// Por el momento
	char	* m_pIC;
	char    * m_pPagCat;

	char    * m_pIA;
	char	* m_pIPagArt;

	AEEFileInfo		* m_pFileInfo;
} CRingApp;
/*-------------------------------------------------------------------
Function Prototypes
-------------------------------------------------------------------*/
static boolean FuncRing_HandleEvent(IApplet * pi, AEEEvent eCode, 
                                      uint16 wParam, uint32 dwParam);

static void FormarUrl(CRingApp *pMe, int iConexion);

static boolean LLenaCadena( char ** pCadena, const char * pTexto );

extern boolean LeeArchivo(CRingApp * pMe, const char * pNoArch, char **pCoArch);

static boolean UINTASTR( uint16 u16Fte, char ** pDestino );

/*===============================================================================
FUNCTION DEFINITIONS
=============================================================================== */

/*===========================================================================

FUNCTION: AEEClsCreateInstance

DESCRIPTION
	This function is invoked while the app is being loaded. All Modules must provide this 
	function. Ensure to retain the same name and parameters for this function.
	In here, the module must verify the ClassID and then invoke the AEEApplet_New() function
	that has been provided in AEEAppGen.c. 

   After invoking AEEApplet_New(), this function can do app specific initialization. In this
   example, a generic structure is provided so that app developers need not change app specific
   initialization section every time except for a call to IDisplay_InitAppData(). 
   This is done as follows: InitAppData() is called to initialize AppletData 
   instance. It is app developers responsibility to fill-in app data initialization 
   code of InitAppData(). App developer is also responsible to release memory 
   allocated for data contained in AppletData -- this can be done in 
   IDisplay_FreeAppData().

PROTOTYPE:
   int AEEClsCreateInstance(AEECLSID ClsId,IShell * pIShell,IModule * po,void ** ppObj)

PARAMETERS:
	clsID: [in]: Specifies the ClassID of the applet which is being loaded

	pIShell: [in]: Contains pointer to the IShell object. 

	pIModule: pin]: Contains pointer to the IModule object to the current module to which
	this app belongs

	ppObj: [out]: On return, *ppObj must point to a valid IApplet structure. Allocation
	of memory for this structure and initializing the base data members is done by AEEApplet_New().

DEPENDENCIES
  none

RETURN VALUE
  AEE_SUCCESS: If the app needs to be loaded and if AEEApplet_New() invocation was
     successful
  EFAILED: If the app does not need to be loaded or if errors occurred in 
     AEEApplet_New(). If this function returns FALSE, the app will not be loaded.

SIDE EFFECTS
  none
===========================================================================*/
int AEEClsCreateInstance(AEECLSID ClsId,IShell * pIShell,IModule * po,void ** ppObj)
{
   *ppObj = NULL;
		
   if(ClsId == AEECLSID_FUNCRING){
      if(AEEApplet_New(sizeof(CRingApp), ClsId, pIShell,po,(IApplet**)ppObj,
         (AEEHANDLER)FuncRing_HandleEvent,NULL)
         == TRUE)
      {
		 // Add your code here .....

         return (AEE_SUCCESS);
      }
   }
	return (EFAILED);
}

/*===========================================================================

FUNCTION FuncRing_HandleEvent

DESCRIPTION
	This is the EventHandler for this app. All events to this app are handled in this
	function. All APPs must supply an Event Handler.

PROTOTYPE:
	boolean FuncRing_HandleEvent(IApplet * pi, AEEEvent eCode, uint16 wParam, uint32 dwParam)

PARAMETERS:
	pi: Pointer to the AEEApplet structure. This structure contains information specific
	to this applet. It was initialized during the AEEClsCreateInstance() function.

	ecode: Specifies the Event sent to this applet

   wParam, dwParam: Event specific data.

DEPENDENCIES
  none

RETURN VALUE
  TRUE: If the app has processed the event
  FALSE: If the app did not process the event

SIDE EFFECTS
  none
===========================================================================*/
static boolean FuncRing_HandleEvent(IApplet * pi, AEEEvent eCode, uint16 wParam, uint32 dwParam)
{  
	CRingApp * pMe = ( CRingApp* )pi;

   switch (eCode) 
	{
      case EVT_APP_START:                        

		    pMe->m_pFileInfo = ( AEEFileInfo * )MALLOC( sizeof( AEEFileInfo ));
			LeeArchivo( pMe, "config/urlbase.config", &pMe->m_pUrlBase );

			FormarUrl( pMe, 1 );	
			FormarUrl( pMe, 2 );	
			FormarUrl( pMe, 3 );	
			FormarUrl( pMe, 4 );	
			FormarUrl( pMe, 5 );	
			FormarUrl( pMe, 6 );
			FormarUrl( pMe, 7 );
			FormarUrl( pMe, 8 );
			FormarUrl( pMe, 9 );

      		return(TRUE);
      case EVT_APP_STOP:

		    // Add your code here .....

         return TRUE;
      default:
         break;
   }
   return FALSE;
}

/*================================================================================================
FUNCION:
	FormarUrl()
================================================================================================*/
void FormarUrl(CRingApp *pMe, int iConexion)
{
	int iInf = 0;

	if(pMe->m_pUrlComp)
	{
		FREE(pMe->m_pUrlComp);
		pMe->m_pUrlComp = NULL;
	}

	iInf += STRLEN( pMe->m_pUrlBase );

	if( iConexion != 6 && iConexion != 9 ) 
		iInf += ( pMe->m_pTelefono ? STRLEN( pMe->m_pTelefono ) : 0 );
	if( iConexion != 1 && iConexion != 6 && iConexion != 9 ) 
		iInf += ( pMe->m_pID_Tono ? STRLEN( pMe->m_pID_Tono ) : 0 );

	switch(iConexion)
	{
		// Para el proceso de actualizaci�n en la pantalla 1( INTRO )
		case 1:
		{
			
			iInf += ( pMe->m_pActualiza ? STRLEN( pMe->m_pActualiza ) : 0 );
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "actualiza.php?f=");
			if( pMe->m_pActualiza ) STRCAT(pMe->m_pUrlComp, pMe->m_pActualiza );
			STRCAT(pMe->m_pUrlComp, "&t=" );
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp,"5557306307");//Para pruebas.....
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "PLAY" )
		case 2:
		{
			iInf += 14;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "5557306307");
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (a) )
		case 3:
		{
			iInf += 24;
			
			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&w=1&d=1&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "5557306307");
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (b) )
		case 4:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&w=1&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "5557306307");
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (c) )
		case 5:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&d=1&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "5557306307");
		}
		break;
		// Descarga del archivo tonosTMP.dat para la pantalla 5 CategoriaX
		case 6:
		{
			iInf += ( pMe->m_pIC ? STRLEN( pMe->m_pIC ) : 0 );
			iInf += ( pMe->m_pPagCat ? STRLEN( pMe->m_pPagCat ) : 0 );
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "categrorias.php?i=");
			if( pMe->m_pIC ) STRCAT(pMe->m_pUrlComp, pMe->m_pIC);
			STRCAT(pMe->m_pUrlComp, "&p=");
			if( pMe->m_pPagCat ) STRCAT(pMe->m_pUrlComp, pMe->m_pPagCat);
		}
		break;
		// Actualizaci�n el archivo wish.dat en la pantalla 6 ( Wish List )
		case 7:
		{
			iInf += 18;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "wish.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&d=1&t=");
			if( pMe->m_pTelefono ) STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Actualizacion del archivo buy.dat de la pantalla MisTonos
		case 8:
		{
			iInf += 17;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "buy.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&d=1&t=");
			if( pMe->m_pTelefono ) STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Pantalla 9 ( Artista X )
		case 9:
		{
			iInf += ( pMe->m_pIA ? STRLEN(pMe->m_pIA) : 0 );
			iInf += ( pMe->m_pIPagArt ? STRLEN(pMe->m_pIPagArt) : 0 );
			iInf += 18;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "artista.php?i=" );
			if( pMe->m_pIA ) STRCAT(pMe->m_pUrlComp, pMe->m_pIA);
			STRCAT(pMe->m_pUrlComp, "&p=1");
			if( pMe->m_pIPagArt ) STRCAT(pMe->m_pUrlComp, pMe->m_pIPagArt);
		}
		break;
	}
}

/*======================================================================================
  FUNCION
	LlenaCadena()
  DESCRIPCION
	Esta es una funci�n de prueba
======================================================================================*/
static boolean LlenaCadena( char ** pCadena, const char * pTexto )
{
	// Se libera la memoria asignada en *pCadena si la hay
	FREEIF( *pCadena );
	// Se reserva espacio en memoria 
	*pCadena = ( char * )MALLOC( STRLEN(pTexto) + 1 );
	if( *pCadena )
	{
		STRCPY( *pCadena, pTexto );
		return TRUE;
	}
	return FALSE;
}
/*================================================================================================
  FUNCION:
	LeeArchivo()

  DESCRIPCION:
	La siguiente funci�n almacena el contenido del archivo cuyo nombre es pNoArch en el bufer 
	pCoArch. Si el bufer *pCoArch tiene un valor diferente de NULL, la funci�n libera el contenido
	del bufer. En dado caso que no se pueda leer el archivo o bien que no se pueda crear alguna 
	de las instancias IFileMgr o IFile, la funci�n regresa FALSE.
	
  PARAMETROS
	pMe: Apuntador a la estructura del applet
	pNoArch: Cadena que contiene el nombre del archivo
	pCoArch: Apuntador albufer donde se almacenar� la informaci�n contenida en el archivo.
================================================================================================*/
extern boolean LeeArchivo(CRingApp * pMe, const char * pNoArch, char **pCoArch)
{
	if(*pCoArch)
		FREEIF(*pCoArch);

	if(!pMe->m_pIFileMgr)
	{
		if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR,(void **)(&(pMe->m_pIFileMgr))))!=SUCCESS)
			return FALSE;
	}

	if(pMe->m_pIFileMgr)
	{
	   if(IFILEMGR_Test(pMe->m_pIFileMgr, pNoArch) == SUCCESS)
	   {
			pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pNoArch, _OFM_READ);
			
			if(pMe->m_pIFile)
			{
				pMe->m_pFileInfo->dwSize = 0;

				if ( IFILE_GetInfo(pMe->m_pIFile, pMe->m_pFileInfo) == SUCCESS )
				{
					*pCoArch = (char *)MALLOC(pMe->m_pFileInfo->dwSize + 1);
					if(*pCoArch)
					{
						IFILE_Read(pMe->m_pIFile, *pCoArch, pMe->m_pFileInfo->dwSize);
						(*pCoArch)[pMe->m_pFileInfo->dwSize + 1] = NULL;										
					}
					
				}
			}
		}
	}

	if(pMe->m_pIFileMgr)
	{
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr = NULL;
	}

	if(pMe->m_pIFile)
	{
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile = NULL;
	}

	if(*pCoArch)
		return TRUE;

	return FALSE;
}

/*====================================================================================================
FUNCION:
	UINTASTR();
DESCRIPCION
	Esta funcion convierte un entero no signado en una cadena
====================================================================================================*/
static boolean UINTASTR( uint16 u16Fte, char ** pDestino )
{
	int i = 1;
	// Se obtiene la longitud de la cadena 
	while( u16Fte / 10 ) 
		i++;
	// Se reserva espacio en memoria
	*pDestino = ( char * )MALLOC( i+1 );
	// Se almacena el contenido de la cadena 
	if( *pDestino )
	{
		SPRINTF( *pDestino, "%u", u16Fte);
		return TRUE;
	}
	return FALSE;
}