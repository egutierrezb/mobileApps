#ifndef NOTIPANTALLA2_H
#define NOTIPANTALLA2_H

#include "C://program files//BREW v11//inc//AEEModGen.h"          // Module interface definitions
#include "C://program files//BREW v11//inc//AEEAppGen.h"          // Applet interface definitions
#include "C://program files//BREW v11//inc//AEEShell.h"           // Shell interface definitions
#include "C://program files//BREW v11//inc//AEEFile.h"			// File interface definitions
#include "C://program files//BREW v11//inc//AEEMenu.h"
#include "C://program files//BREW v11//inc//AEEStdLib.h"
#include "C://program files//BREW v11//inc//AEESound.h"			// Sound Interface definitions
#include "C://program files//BREW v11//inc//AEEGraphics.h" 
#include "C://program files//BREW v11//inc//AEEWeb.h"
#include "C://program files//BREW v11//inc//AEEHeap.h"
#include "funcring.bid"
#include "ringtones_res.h"
#include "C://program files//BREW v11//inc//AEETAPI.h"
#include "C://program files//BREW v11//inc//AEERinger.h"

//c�digo de conexi�nweb
#define		CX_PROG_DESPLEGAR	75
#define		CY_PROG_DESPLEGAR	67
#define		PROG_ANIM			0
#define		PROG_TELEFONO		1
#define		PROG_COMPUTADORA	2
#define		ALTOLINEA			14
#define		TOPELINEA			0
#define		MARGEN			3
#define		TAMANIOARREGLO(a)		(sizeof(a)/sizeof ( (a)[0]) )

#define RELEASEIF(pi)      { if (pi) { IBASE_Release((IBase*)(pi)); (pi)=0; }}

typedef enum 
{
	ARCHIVO,
	BUFER,
	NOMBARCHIVO
} eDestInfo;
//C�digo de conexi�nweb


//M�dulo de men�
#define COLORBACK	MAKE_RGB(255,255,255)
#define COLORSELBACK MAKE_RGB(255,255,255)
#define COLORTEXTSEL	MAKE_RGB(0,0,0)
#define COLORTEXT	MAKE_RGB(0,0,0)


#define ANIMACION_INICIO    3600

typedef enum
{
	P_INTRO,
	P_MENUINICIO,
	P_TOP10,
	P_CATEGORIAS,
	P_CATEGORIAX, //cuando se est� dentro de una categor�a espec�fica
	P_ARTISTAX,
	P_WISHLST,
	P_NTONOS,
	P_MTONOS,
	P_PLAYER,
	P_BUY,
	P_SAVE,
	P_CAT,
	P_SORT,
	P_DEL,
	P_AYUDA
} ePantallasApp;

typedef enum
{
	O_PLAY,
	O_BUY,
	O_SAVE,
	O_ART,
	O_CAT,
	O_SORT,
	O_DEL,
} eOpcionesApp;

typedef enum
{
	E_MENU,
	E_TOP10,
	E_CATEGORIAS,
	E_CATEGORIAX,
	E_ARTISTAX,
	E_WISHLST,
	E_NTONOS,
	E_MTONOS,
	E_AYUDA,
} eEntornoApp;



#define RELEASEIF(pi)      { if (pi) { IBASE_Release((IBase*)(pi)); (pi)=0; }}


typedef struct _Cringtonesapp
{
	AEEApplet a;
	IImage*     m_pImagen1;     // Apuntador a un elemento imagen

	//c�digo de conexi�nweb
	eDestInfo   	m_eDestInfo;          	// Antes de mandar llamar conexionWeb se debe establecer el valor de la enumeraci�n
	IWeb*      		m_pIWeb;
	IWebResp*   	m_pIWebResp;
	char*      		m_pContenidoBufer;
	char*			m_pNomArchivo;
	int        		m_iTamanioBufer;
	int        		m_iMemAsigBuf;
	
	
	AEECallback     m_Callback;
	IFileMgr*   	m_pIFileMgr;
	IFile*      	m_pIFile;
	IHeap*			m_pIHeap;
	boolean			m_bBand;
	uint16			m_cxPantalla, m_cyPantalla, m_ProfColor;
	boolean			m_bDispEnProgreso;
	IImage*			m_pIImgDescarga[3];
	//c�digo de conexi�nweb

	//c�digo de menugral
	IMenuCtl	*m_pIMenuActivo;
	IMenuCtl	*m_pISKMenu;
	IImage		*m_pIImgBanner;
	AEEDeviceInfo di;
	//c�digo de menugral

	ePantallasApp	m_ePantalla;
	ePantallasApp	m_ePantallaProc; //Pantalla de procedencia
	eOpcionesApp	m_eOpcion;
	eEntornoApp     m_eEntorno;
	uint16			m_eOpcion2; //ID del menu de tonos

	ISoundPlayer*		m_pISoundPlayer;
	AEESoundPlayerInfo	pSoundPlayerInfo;
	AEESoundPlayerInput pSoundPlayerInput;
	AEESoundPlayerFile  m_SoundPlayerFile;
	char*				m_pIArchivoTono;
	
	AEEItemStyle    pActive;
	AEEItemStyle    pNormal;
	AEEMenuColors	m_AEEMenCol;
	IGraphics*      m_pIGraphics;

	//c�digo menu con datos en movimiento
	int cont;
	int bandera;
	int ipagCat;
	boolean INDICA_LETRERO;
	char * ArchivoCat;
	AECHAR BufferCat[15];
		
	//c�digo menu con datos en movimiento

	//AEEImageInfo m_pIImageInfo;

	// bufers utilizados para las conexiones
	char	* m_pUrlBase;
	char	* m_pUrlComp;
	char	* m_pActualiza;
	char    * m_pTelefono;
	ITAPI*		m_pITapi;
	// Aqui se almacena el ID del tono que se quiera descargar
	char    * m_pID_Tono;
	// Por el momento
	char	* m_pIC;
	char    * m_pPagCat;

	char    * m_pIA;
	char	* m_pIPagArt;

	boolean m_bCiclo;

	AEEFileInfo		* m_pFileInfo;

	char	* m_pNTono;

	// Se utiliza para seleccionar el mensaje que se despliega con DespliegaMensaje()
	uint16	m_u16Opcion1;
	// 
	uint16	m_u16Opcion2;

	// La siguiente interfaz se utiliza para crear un nuevo ringtone
	IMemAStream * m_pIMemStream;
	IRingerMgr * m_pIRingerMgr;

}Cringtonesapp;


#endif