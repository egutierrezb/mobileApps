#ifndef NOTIPANTALLA2_H
#define NOTIPANTALLA2_H

#include "AEEModGen.h"          // Module interface definitions
#include "AEEAppGen.h"          // Applet interface definitions
#include "AEEShell.h"           // Shell interface definitions
#include "AEEFile.h"			// File interface definitions
#include "AEEMenu.h"
#include "AEEStdLib.h"
#include "AEESound.h"			// Sound Interface definitions
#include "AEEGraphics.h" 
#include "AEEWeb.h"
#include "AEEHeap.h"
#include "funcring.bid"
#include "ringtones_res.h"
#include "AEETAPI.h"
#include "AEERinger.h"
#include "AEEText.h"
#include "AEEHtmlViewer.h"   
//c�digo de conexi�nweb
#define		CX_PROG_DESPLEGAR	75
#define		CY_PROG_DESPLEGAR	67
#define		PROG_ANIM			0
#define		PROG_TELEFONO		1
#define		PROG_COMPUTADORA	2
#define		ALTOLINEA			14
#define		TOPELINEA			0
#define		MARGEN			3
#define		TAMANIOARREGLO(a)		(sizeof(a)/sizeof ( (a)[0]) )
#define ARCHIVO_AYUDA       "ayuda.txt"

#define RELEASEIF(pi)      { if (pi) { IBASE_Release((IBase*)(pi)); (pi)=0; }}

typedef enum 
{
	ARCHIVO,
	BUFER,
	NOMBARCHIVO
} eDestInfo;
//C�digo de conexi�nweb


//M�dulo de men�
#define COLORBACK		MAKE_RGB(194,224,156)
#define COLORSELBACK	MAKE_RGB(0,0,0)
#define COLORTEXTSEL	MAKE_RGB(255,255,255)
#define COLORTEXT		MAKE_RGB(0,0,0)
#define HTML_LINK       MAKE_RGB(255,0,0)


#define ANIMACION_INICIO    1000

typedef enum
{
	P_INTRO,
	P_MENUINICIO,
	P_TOP10,
	P_ID,
	P_CATEGORIAS,
	P_CATEGORIAX, //cuando se est� dentro de una categor�a espec�fica
	P_ARTISTAX,
	P_WISHLST,
	P_NTONOS,
	P_MTONOS,
	P_PLAYER,
	P_BUY,
	P_SAVE,
	P_CAT,
	P_SORT,
	P_DEL,
	P_AYUDA,
	P_IDINFO,
	P_IDTONOCOMPRADO,
} ePantallasApp;


typedef enum
{
	O_PLAY,
	O_BUY,
	O_SAVE,
	O_ART,
	O_CAT,
	O_SORT,
	O_DEL,
} eOpcionesApp;

typedef enum
{
	E_MENU,
	E_TOP10,
	E_CATEGORIAS,
	E_CATEGORIAX,
	E_ARTISTAX,
	E_WISHLST,
	E_NTONOS,
	E_MTONOS,
	E_AYUDA,
	E_SORT_ARTISTA,
	E_SORT_TITULO,
	E_ID,
	E_IDINFO,
} eEntornoApp;



#define RELEASEIF(pi)      { if (pi) { IBASE_Release((IBase*)(pi)); (pi)=0; }}


typedef struct _Cringtonesapp
{
	AEEApplet a;
	IImage*     m_pImagen1;     // Apuntador a un elemento imagen

	//c�digo de conexi�nweb
	eDestInfo   	m_eDestInfo;          	// Antes de mandar llamar conexionWeb se debe establecer el valor de la enumeraci�n
	IWeb*      		m_pIWeb;
	IWebResp*   	m_pIWebResp;
	char*      		m_pContenidoBufer;
	char*			m_pNomArchivo;
	int        		m_iTamanioBufer;
	int        		m_iMemAsigBuf;
	int				m_eliminaArch;
	uint16			m_ItemSeleccionado;
	uint16			WP;
	boolean			m_eSort;
	boolean			m_BanderaConexion;
	
	
	AEECallback     m_Callback;
	IFileMgr*   	m_pIFileMgr;
	IFile*      	m_pIFile;
	IHeap*			m_pIHeap;
	boolean			m_bBand;
	boolean			m_regresoArtista;
	uint16			m_cxPantalla, m_cyPantalla, m_ProfColor;
	boolean			m_bDispEnProgreso;
	IImage*			m_pIImgDescarga[3];
	ITextCtl*		m_pITextCtl;
	//c�digo de conexi�nweb

	//c�digo de menugral
	IMenuCtl	*m_pIMenuActivo;
	IMenuCtl	*m_pISKMenu;
	IImage		*m_pIImgBanner;
	AEEDeviceInfo di;
	//c�digo de menugral

	ePantallasApp	m_ePantalla;
	ePantallasApp	m_ePantallaProc; //Pantalla de procedencia
	eOpcionesApp	m_eOpcion;
	eEntornoApp     m_eEntorno;
	uint16			m_eOpcion2; //ID del menu de tonos

	ISoundPlayer*		m_pISoundPlayer;
	AEESoundPlayerInfo	pSoundPlayerInfo;
	AEESoundPlayerInput pSoundPlayerInput;
	AEESoundPlayerFile  m_SoundPlayerFile;
	AECHAR				Digitos_ID[20];
	char*				m_pIArchivoTono;
	
	AEEItemStyle    pActive;
	AEEItemStyle    pNormal;
	AEEMenuColors	m_AEEMenCol;
	IGraphics*      m_pIGraphics;

	//c�digo menu con datos en movimiento
	int cont;
	int bandera;
	int ipagCat;
	int ipagArt;
	int NTONOS_TMP; //NUMERO DE TONOS PARA EL TONOSTMP.DAT
	char * ArchivoCat;
	boolean INDICA_LETRERO;
	boolean ID;
	boolean TONOS_IDTONO; //Booleano que se sabe si el tono se encuentra en tonos/id_tono
	boolean sinnombretono;
	boolean conexion_snombre;

	AECHAR BufferCat[50];
		
	//c�digo menu con datos en movimiento

	//AEEImageInfo m_pIImageInfo;

	// bufers utilizados para las conexiones
	char	* m_pUrlBase;
	char	* m_pUrlComp;
	char	* m_pActualiza;
	char    * m_pTelefono;
	ITAPI*		m_pITapi;
	// Aqui se almacena el ID del tono que se quiera descargar
	char    * m_pID_Tono;
	// Por el momento
	char	* m_pIC;
	char    * m_pPagCat;
	char	m_pIpagCat[2];
	char	m_pIPagArt[2];

	char    * m_pIA;
	char	* Formato_Tono;

	boolean m_bCiclo;

	AEEFileInfo		* m_pFileInfo;

	char	* m_pNTono;
	char	*Artista;

	// Se utiliza para seleccionar el mensaje que se despliega con DespliegaMensaje()
	uint16	m_u16Opcion1;
	// 
	uint16	m_u16Opcion2;

	// La siguiente interfaz se utiliza para crear un nuevo ringtone
	IMemAStream * m_pIMemStream;
	IRingerMgr * m_pIRingerMgr;
	AEERingerID  m_AEERingerID;

	// Miembros adicionales para desplegar el grado deavance de la descarga
	long	m_iTamanioArchivo;
	long    m_iBytesDescargados;

	// Para almacenar el letrero de descargando
	AECHAR	* m_pTemporal;
	AECHAR  * m_pTituloTemp;
	AECHAR  * m_pArtistaTemp;
	uint16			m_pItem;

	//Ayuda
	IHtmlViewer     *m_pIHtmlViewer;

	//Bandera para los estados
	int     edo_pantalla;

}Cringtonesapp;


#endif