#include "Utilerias.h"
#include "notiPantalla2.h"
#include "ConexionWeb.h"
#include "MenuGral.h"


boolean TagContents(char** Html, const char* Tag, char** Start,char** End)
{
	int TagLen = 5;
	
	boolean bFound = FALSE;
	char* h = *Html;
	TagLen=STRLEN(Tag);

   h = STRCHR(h, '<');
	while (h)
	{
		h++;
		if (STRNCMP(h, Tag, TagLen) == 0)
			break;
      h = STRCHR(h, '<');
	}

   if(h)
   {
      h = STRCHR(h, '>');
	   if (h)
	   {
		   h++;
		   *Start = h;
         h = STRCHR(h, '<');

		   while (h)
		   {
			   h++;
			   if (*h == '/' && STRNCMP(h + 1, Tag, TagLen) == 0)
			   {
				   *End = h - 2;
				   bFound = TRUE;
				   break;
			   }
			   h = STRCHR(h, '>');
			   if (!h)
				   break;
            h = STRCHR(h, '<');
		   }
      }
	}

	*Html = h;
	if(bFound==TRUE)
		*(*End+1)=0;
	return bFound;
}

boolean buscaDatoID(Cringtonesapp * pMe, const int ID, char** DatoTMP, const char* Tag){
   FileInfo pFInfo;
   char *pFileBuf=NULL;
   char *FileBuf=NULL;
   char *End;
   char *t=NULL;
   int i;
	
   
   	if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr){
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}

	
	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	if(!pMe->m_pIFile){
		switch(pMe->m_ePantalla){
			case P_TOP10:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "topten.dat", _OFM_READ);
			break;
			case P_WISHLST:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "wish.dat", _OFM_READ);
			break;
			case P_NTONOS:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "new.dat", _OFM_READ);
			break;
			case P_MTONOS:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "buy.dat", _OFM_READ);
			break;
			case P_CATEGORIAX:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->ArchivoCat, _OFM_READ);
			break;
			case P_CATEGORIAS:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "categorias.dat", _OFM_READ);
			break;
			case P_ARTISTAX:

				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "tonosTMP.dat", _OFM_READ);
				
			break;
			case P_CAT:
				if( pMe->m_ePantallaProc == P_TOP10 )
					pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "topten.dat", _OFM_READ );
				if( pMe->m_ePantallaProc == P_MTONOS )
					pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "buy.dat", _OFM_READ );
				if( pMe->m_ePantallaProc == P_NTONOS )
					pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "new.dat", _OFM_READ );
				break;
		}
	}

	
	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
		return FALSE;
	

	if (pMe->m_pIFile )
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
	if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr){
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}


	if (pMe->m_ePantallaProc!=P_CATEGORIAS){
		for (i=0;i<=ID;i++){ //hace un recorrido dentro del archivo para la <i> lo almacena en t
						
			TagContents(&FileBuf,"i>",&t,&End);
		}
	}
	else{
		for (i=0;i<ID;i++){
						
			TagContents(&FileBuf,"c>",&t,&End);
		}
	}
		
	if (STRCMP(Tag,"t")==0)	TagContents(&FileBuf,"t",&t,&End);
	if (STRCMP(Tag,"a")==0)	TagContents(&FileBuf,"a",&t,&End);
	if (STRCMP(Tag,"c")==0)	TagContents(&FileBuf,"c",&t,&End);
	if (STRCMP(Tag,"ia")==0)	TagContents(&FileBuf,"ia",&t,&End);
	if (STRCMP(Tag,"ic")==0)	TagContents(&FileBuf,"ic",&t,&End);
	
	*DatoTMP=(char *)MALLOC(STRLEN(t)+1);
	
	STRCPY(*DatoTMP,t);
	
	FREEIF(pFileBuf);
	pFileBuf=NULL;
	return TRUE;
}

boolean buscaDatoID1(Cringtonesapp * pMe, const int ID, char** DatoTMP, const char* Tag){
   FileInfo pFInfo;
   char *pFileBuf=NULL;
   char *FileBuf=NULL;
   char *End;
   char *t=NULL;
   int i;
	
   
   	if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr){
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}

	
	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	if(!pMe->m_pIFile){
		switch(pMe->m_ePantallaProc){
			case P_TOP10:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "topten.dat", _OFM_READ);
			break;
			case P_WISHLST:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "wish.dat", _OFM_READ);
			break;
			case P_NTONOS:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "new.dat", _OFM_READ);
			break;
			case P_MTONOS:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "buy.dat", _OFM_READ);
			break;
			case P_CATEGORIAX:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->ArchivoCat, _OFM_READ);
			break;
			case P_CATEGORIAS:
				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "categorias.dat", _OFM_READ);
			break;
			case P_ARTISTAX:

				pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "tonosTMP.dat", _OFM_READ);
				
			break;
		}
	}

	
	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
		return FALSE;
	

	if (pMe->m_pIFile )
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
	if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr){
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}

	if (pMe->m_ePantallaProc!=P_CATEGORIAS){
		for (i=0;i<=ID;i++){ //hace un recorrido dentro del archivo para la <i> lo almacena en t
						
			TagContents(&FileBuf,"i>",&t,&End);
		}
	}
	else{
		for (i=0;i<ID;i++){
						
			TagContents(&FileBuf,"c>",&t,&End);
		}
	}
		
	if (STRCMP(Tag,"t")==0)	TagContents(&FileBuf,"t",&t,&End);
	if (STRCMP(Tag,"a")==0)	TagContents(&FileBuf,"a",&t,&End);
	if (STRCMP(Tag,"c")==0)	TagContents(&FileBuf,"c",&t,&End);
	if (STRCMP(Tag,"ia")==0)	TagContents(&FileBuf,"ia",&t,&End);
	if (STRCMP(Tag,"ic")==0)	TagContents(&FileBuf,"ic",&t,&End);
	
	*DatoTMP=(char *)MALLOC(STRLEN(t)+1);
	
	STRCPY(*DatoTMP,t);
	
	FREEIF(pFileBuf);
	pFileBuf=NULL;
	return TRUE;
}

boolean ConcatenaSegmento(char **pInicio,  char * pSegmento, int iNoSgto)
{
	int i;
	char * pBuf = *pInicio;
	char * pTemp1 = *pInicio;
	int longitud = 0;
	// Se obtiene la cantidad de memoria asignada hasta el momento a *pInicio
	// Si iNoSgto = 1, no hay memoria asignada

	
	if(iNoSgto > 1)
		for(i=1; i<iNoSgto; i++)
		{
			longitud += (STRLEN(pTemp1) + 1);
			pTemp1 += (STRLEN(pTemp1) + 1);
		}
	// Se almacena la cantidad de memoria asignada hasta el momento a *pInicio
	i = longitud;
	// Se obtiene y se asigna  la cantidad de memoria total para almacenar *pInicio 
	// y pSegmento
	longitud += (STRLEN(pSegmento) + 1);
	//FREEIF(pBuf);
	pBuf = (char *)MALLOC(longitud);
		
	if(pBuf)	
	{
		// Se copia el contenido actual de *pInicio en pBuf
		MEMCPY((void *)pBuf, (void *)*pInicio, i);
		// Se concatena pSegmento
		FREEIF(*pInicio);
		MEMCPY((void *)(pBuf + i), (void *)pSegmento, (longitud - i));
		// Se libera el contenido anterior de *pInicio y se le asigna el contenido
		// de pBuf
		
		*pInicio = pBuf;
		pBuf = NULL;
		return TRUE;
	}
	return FALSE;
}



void DespliegaTexto(Cringtonesapp * pMe)
{
	AEERect rRect;
	AECHAR *wTemp;
	uint16 item, anchoCadena;
	int longitud;
	char *temp;

	if( !pMe->m_pIMenuActivo ) return;
	SETAEERECT(&rRect, 7, 23, pMe->m_cxPantalla - 13, 15);
	IDISPLAY_EraseRect(pMe->a.m_pIDisplay, &rRect);
	IDISPLAY_DrawFrame(pMe->a.m_pIDisplay, &rRect, AEE_FT_BOX, MAKE_RGB(0,0,0));
	item = IMENUCTL_GetSel(pMe->m_pIMenuActivo);
	IMENUCTL_GetItemData(pMe->m_pIMenuActivo, item, (uint32 *)&temp);

	// Se posiciona el apuntador en el primer segmento de datos

	if(pMe->bandera == 1)
	{
		temp += pMe->cont;
	}

	// Se posiciona el apuntador en el segundo segmento de datos

	if(pMe->bandera == 2)						// Si los datos del item constan de N segmentos, 
	{											// entonces la bandera manejar� N estados, y en 
		longitud = STRLEN(temp);				// este segmento de c�digo se realizar�n N
		temp += (longitud + pMe->cont + 1);		// comparaciones con el fin de posicionar el 
	}											// apuntador temp al inicio del segmento adecuado

	// Se posiciona el apuntador en el tercer segmento de datos

	if(pMe->bandera == 3)
	{
		longitud = STRLEN(temp);
		temp += (longitud + 1);
		longitud = STRLEN(temp);
		temp += (longitud + pMe->cont + 1);
	}

	if(pMe->bandera == 4)
	{
		longitud = STRLEN(temp);
		temp += (longitud + 1);
		longitud = STRLEN(temp);
		temp += (longitud + 1);
		longitud = STRLEN(temp);
		temp += (longitud + pMe->cont + 1);
	}

	if(pMe->bandera == 5)
	{
		longitud = STRLEN(temp);
		temp += (longitud + 1);
		longitud = STRLEN(temp);
		temp += (longitud + 1);
		longitud = STRLEN(temp);
		temp += (longitud + 1);
		longitud = STRLEN(temp);
		temp += (longitud + pMe->cont + 1);
	}
	
	wTemp = (AECHAR *)MALLOC(2*(STRLEN(temp) + 1));
	STRTOWSTR(temp, wTemp, 2*(STRLEN(temp) + 1));
	(uint16)anchoCadena = (uint16)IDISPLAY_MeasureText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);

	if(anchoCadena < (pMe->m_cxPantalla - 16))
	{
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(0,0,0) );
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, RGB_WHITE );
		IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, &rRect, IDF_ALIGN_MIDDLE|IDF_ALIGN_CENTER);
		IDISPLAY_Update(pMe->a.m_pIDisplay);
		FREEIF(wTemp);
		pMe->cont = 0;

		if(pMe->bandera == 2)				// En el caso de que la longitud de la cadena sea menor
			pMe->bandera = 3;				// que el ancho de la pantalla, la pr�xima vez que se 
		else if(pMe->bandera == 3)			// llame a s� misma esta funci�n se mostrar� la siguiente 
			pMe->bandera = 4;                // cadena
		else if(pMe->bandera == 4)
			pMe->bandera = 5;
		else if(pMe->bandera == 5)
			pMe->bandera = 2;

		ISHELL_SetTimer(pMe->a.m_pIShell, 1000, (PFNNOTIFY)DespliegaTexto, (void *)pMe);

		return;
	}
	
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, &rRect, IDF_ALIGN_LEFT | IDF_ALIGN_MIDDLE);	// Si la longitud de la cadena es mayor que el ancho de la pantalla,
	IDISPLAY_Update(pMe->a.m_pIDisplay);																// la pr�xima vez que se llame a s� misma esta funci�n trabajar� con 
	FREEIF(wTemp);																						// la misma cadena pero con el apuntador de inicio recorrido una 
    ISHELL_SetTimer(pMe->a.m_pIShell, 300, (PFNNOTIFY)DespliegaTexto, (void *)pMe);                     // posici�n hacia delante
	pMe->cont++;																						 							
}


boolean ReproducirTono(Cringtonesapp * pMe){

	if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_SOUNDPLAYER,(void **)&pMe->m_pISoundPlayer)!=SUCCESS)
		return FALSE;
	pMe->pSoundPlayerInput=SDT_FILE;
	pMe->pSoundPlayerInfo.eInput = pMe->pSoundPlayerInput;
	pMe->pSoundPlayerInfo.pData = pMe->m_pIArchivoTono;
	pMe->pSoundPlayerInfo.dwSize = NULL;
	ISOUNDPLAYER_SetInfo(pMe->m_pISoundPlayer,&pMe->pSoundPlayerInfo);
	ISOUNDPLAYER_Play(pMe->m_pISoundPlayer);
	pMe->m_pIArchivoTono=NULL;

	return TRUE;
}

void LibMem(Cringtonesapp* pMe) // Funci�n general para liberar la memoria
{
		if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe)){
			ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaTexto, (void *)pMe);
		}
		if (ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)EsperaAnimacionInicio, (uint32*) pMe)!=0){
			ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY) EsperaAnimacionInicio, (uint32*) pMe);
		}
		if (ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)creaInicio, (uint32*) pMe)!=0){
			ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY) creaInicio, (uint32*) pMe);
		}

		if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)Conexion_TMP, (void *)pMe)){
			ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)Conexion_TMP, (void *)pMe);
		}

		FREEIF( pMe->m_pUrlComp );
		
		//c�digo conexi�nweb
		if(pMe->m_pNomArchivo)
		{
			FREE(pMe->m_pNomArchivo);
			pMe->m_pNomArchivo = NULL;
		}
        //c�digo conexi�nweb
		
     	LiberaWeb(pMe);
		LiberaUtil(pMe);
		
  	    
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, RGB_WHITE );
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, RGB_BLACK );

		// Se libera el nombre del tono dado que es memoria asignada en el Heap
		FREEIF(pMe->pSoundPlayerInfo.pData);
		LimpiarIm(pMe);

		if (pMe->m_pIMenuActivo) IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
		if (pMe->m_pISKMenu) IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
		if (pMe->m_pISoundPlayer) ISOUNDPLAYER_Release(pMe->m_pISoundPlayer);

		if(pMe->m_pIFile) {
			IFILE_Release(pMe->m_pIFile);
			pMe->m_pIFile=NULL;
		}
		if (pMe->m_pIFileMgr){
			IFILEMGR_Release(pMe->m_pIFileMgr);
			pMe->m_pIFileMgr=NULL;
		}
		
		if (pMe->m_ePantallaProc!=P_CATEGORIAX){
		/*if(pMe->ArchivoCat)
						
		{	
			FREE(pMe->ArchivoCat);
			pMe->ArchivoCat = NULL;
		}*/
		}

		LiberaMenuGral(pMe);
}

void LimpiarIm(Cringtonesapp *pMe) //C�digo de la funci�n para limpiar un elemento de imagen de la memoria
{
	if(pMe->m_pImagen1 != NULL)             //Libera la memoria si el apuntador a la imagen no est� a Null
		IIMAGE_Release(pMe->m_pImagen1);
		 pMe->m_pImagen1=NULL;
}


void MostrarInicio1(Cringtonesapp *pMe)
{
  
  if (pMe->m_ProfColor>=8) 
  {
	  IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);  
	  IGRAPHICS_ClearViewport( pMe->m_pIGraphics );
	  pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGOINTRO);
	  //IIMAGE_Draw(pMe->m_pImagen1,(pMe->m_cxPantalla-118)/2,(pMe->m_cyPantalla-144)/2);
	  IIMAGE_Draw(pMe->m_pImagen1,(pMe->m_cxPantalla-92)/2,(pMe->m_cyPantalla-100)/2);
	  IDISPLAY_Update( pMe->a.m_pIDisplay );
  }
  else 
  {
	  IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);  
	  IGRAPHICS_ClearViewport( pMe->m_pIGraphics );
	  pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGOINTROBAN);
	  IIMAGE_Draw(pMe->m_pImagen1,(pMe->m_cxPantalla-118)/2,(pMe->m_cyPantalla-144)/2);
	  IDISPLAY_Update( pMe->a.m_pIDisplay );
  }

  

}

void MostrarInicio2(Cringtonesapp *pMe)
{
  
  LimpiarIm(pMe);
  
  if (pMe->m_ProfColor>=8) 
  {
	  IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);  
	  IGRAPHICS_ClearViewport( pMe->m_pIGraphics );
	  pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGOINTRO2);
	  //IIMAGE_Draw(pMe->m_pImagen1,(pMe->m_cxPantalla-118)/2,(pMe->m_cyPantalla-144)/2);
	  IIMAGE_Draw(pMe->m_pImagen1,(pMe->m_cxPantalla-75)/2,(pMe->m_cyPantalla-42)/2);
	  IDISPLAY_Update( pMe->a.m_pIDisplay );
  }
  else 
  {
	  IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);  
	  IGRAPHICS_ClearViewport( pMe->m_pIGraphics );
	  pMe->m_pImagen1=ISHELL_LoadResImage(pMe->a.m_pIShell,RINGTONES_RES_FILE,IDB_LOGOINTRO2BAN);
	  IIMAGE_Draw(pMe->m_pImagen1,(pMe->m_cxPantalla-75)/2,(pMe->m_cyPantalla-42)/2);
	  IDISPLAY_Update( pMe->a.m_pIDisplay );
  }

  ISHELL_SetTimer(pMe->a.m_pIShell,ANIMACION_INICIO,(PFNNOTIFY)EsperaAnimacionInicio,(void*)pMe);	
}

void EsperaAnimacionInicio(Cringtonesapp * pMe)
{
	IIMAGE_Stop(pMe->m_pImagen1);
	LimpiarIm(pMe);
	//pMe->m_ePantalla=P_MENUINICIO;
	ISHELL_SetTimer(pMe->a.m_pIShell,500,(PFNNOTIFY)ConexionInicio,(void*)pMe);
}

void ConexionInicio( Cringtonesapp * pMe )
{
	LlenaCadena( &pMe->m_pTelefono, "5557306307");
	LeeArchivoEx( pMe, "config/urlbase.config", &pMe->m_pUrlBase );
	FormarUrl( pMe, 1 );
	FREEIF( pMe->m_pActualiza );
	pMe->m_eDestInfo = BUFER;
	ConexionWeb( pMe, pMe->m_pUrlComp, NULL );
}

/*================================================================================================
  FUNCION:
	LeeArchivo()

  DESCRIPCION:
	La siguiente funci�n almacena el contenido del archivo cuyo nombre es pNoArch en el bufer 
	pCoArch. Si el bufer *pCoArch tiene un valor diferente de NULL, la funci�n libera el contenido
	del bufer. En dado caso que no se pueda leer el archivo o bien que no se pueda crear alguna 
	de las instancias IFileMgr o IFile, la funci�n regresa FALSE.
	
  PARAMETROS
	pMe: Apuntador a la estructura del applet
	pNoArch: Cadena que contiene el nombre del archivo
	pCoArch: Apuntador albufer donde se almacenar� la informaci�n contenida en el archivo.
================================================================================================*/
extern boolean LeeArchivo(Cringtonesapp * pMe, const char * pNoArch, char **pCoArch)
{
	if(*pCoArch)
		FREEIF(*pCoArch);

	if(!pMe->m_pIFileMgr) return FALSE;

	/*if(!pMe->m_pIFileMgr)
	{
		if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR,(void **)(&(pMe->m_pIFileMgr))))!=SUCCESS)
			return FALSE;
	}*/

	if(!pMe->m_pFileInfo)
	{
		pMe->m_pFileInfo = (AEEFileInfo *)MALLOC(sizeof(AEEFileInfo));
		if(!pMe->m_pFileInfo) return FALSE;
	}

	if(IFILEMGR_Test(pMe->m_pIFileMgr, pNoArch) == SUCCESS)
	{
		if(pMe->m_pIFile)
		{
			IFILE_Release(pMe->m_pIFile);
			pMe->m_pIFile = NULL;
		}

		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pNoArch, _OFM_READ);
			
		if(pMe->m_pIFile)
		{
			pMe->m_pFileInfo->dwSize = 0;

			if ( IFILE_GetInfo(pMe->m_pIFile, pMe->m_pFileInfo) == SUCCESS )
			{
				*pCoArch = (char *)MALLOC(pMe->m_pFileInfo->dwSize + 2);
				if(*pCoArch)
				{
					IFILE_Read(pMe->m_pIFile, *pCoArch, pMe->m_pFileInfo->dwSize);
					(*pCoArch)[pMe->m_pFileInfo->dwSize + 2] = NULL;										
				}
				
			}
		}
	}
	

	if(pMe->m_pIFile)
	{
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile = NULL;
	}

	if(*pCoArch)
		return TRUE;

	return FALSE;
}
/*================================================================================================
  FUNCION:
	LeeArchivoEx(). 

	La diferencia con LeeArchivo es que en esta funci�on se crea y se libera la instancia 
	IFileMgr

  DESCRIPCION:
	La siguiente funci�n almacena el contenido del archivo cuyo nombre es pNoArch en el bufer 
	pCoArch. Si el bufer *pCoArch tiene un valor diferente de NULL, la funci�n libera el contenido
	del bufer. En dado caso que no se pueda leer el archivo o bien que no se pueda crear alguna 
	de las instancias IFileMgr o IFile, la funci�n regresa FALSE.
	
  PARAMETROS
	pMe: Apuntador a la estructura del applet
	pNoArch: Cadena que contiene el nombre del archivo
	pCoArch: Apuntador albufer donde se almacenar� la informaci�n contenida en el archivo.
================================================================================================*/
extern boolean LeeArchivoEx(Cringtonesapp * pMe, const char * pNoArch, char **pCoArch)
{
	if(*pCoArch)
		FREEIF(*pCoArch);

	if(!pMe->m_pIFileMgr)
	{
		if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR,(void **)(&(pMe->m_pIFileMgr))))!=SUCCESS)
			return FALSE;
	}

	if(!pMe->m_pFileInfo)
	{
		pMe->m_pFileInfo = (AEEFileInfo *)MALLOC(sizeof(AEEFileInfo));
		if(!pMe->m_pFileInfo) return FALSE;
	}

	if(IFILEMGR_Test(pMe->m_pIFileMgr, pNoArch) == SUCCESS)
	{
		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pNoArch, _OFM_READ);
			
		if(pMe->m_pIFile)
		{
			pMe->m_pFileInfo->dwSize = 0;

			if ( IFILE_GetInfo(pMe->m_pIFile, pMe->m_pFileInfo) == SUCCESS )
			{
				*pCoArch = (char *)MALLOC(pMe->m_pFileInfo->dwSize + 1);
				if(*pCoArch)
				{
					IFILE_Read(pMe->m_pIFile, *pCoArch, pMe->m_pFileInfo->dwSize);
					(*pCoArch)[pMe->m_pFileInfo->dwSize + 1] = NULL;										
				}
				
			}
		}
	}
	

	if( pMe->m_pIFileMgr )
	{
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr = NULL;
	}

	if(pMe->m_pIFile)
	{
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile = NULL;
	}

	if(*pCoArch)
		return TRUE;

	return FALSE;
}
/*================================================================================================
  FUNCION
	ObtenNumTel()
  DESCRIPCION
    Esta funci�n obtiene el n�mero telef�nico del handset
  PARAMETROS
================================================================================================*/
boolean ObtenNumTel(Cringtonesapp * pMe)
{
	TAPIStatus * pTapiStatus = NULL;

	pTapiStatus = ( TAPIStatus * )MALLOC( sizeof( TAPIStatus ) );
	if( !pTapiStatus )
		return FALSE;
	// Se crea la instancia ITAPI	
	if(!pMe->m_pITapi)
		if( ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_TAPI,(void **)(&(pMe->m_pITapi))) != SUCCESS )
		{
			FREEIF( pTapiStatus );
			return FALSE;
		}
	// Se reserva espacio para el telefono y se copia su contenido
	pMe->m_pTelefono = ( char * )MALLOC( STRLEN(pTapiStatus->szMobileID) + 1 );
	// Se obtiene el estado actual del dispositivo 
	if ( ITAPI_GetStatus( pMe->m_pITapi, pTapiStatus ) == EBADPARM || !pMe->m_pTelefono )
	{
		ITAPI_Release( pMe->m_pITapi );
		pMe->m_pITapi = NULL;
		FREEIF( pTapiStatus );
		return FALSE;
	}
	STRCPY( pMe->m_pTelefono, pTapiStatus->szMobileID);
	// Se liberan los recursos asignados en esta func��n
	ITAPI_Release( pMe->m_pITapi );
	pMe->m_pITapi = NULL;
	FREEIF( pTapiStatus );
	return TRUE;
}
/*================================================================================================
FUNCION:
	()
================================================================================================*/
void FormarUrl(Cringtonesapp *pMe, int iConexion)
{
	int iInf = 0;

	if(pMe->m_pUrlComp)
	{
		FREE(pMe->m_pUrlComp);
		pMe->m_pUrlComp = NULL;
	}

	iInf += STRLEN( pMe->m_pUrlBase );

	if( iConexion != 6 && iConexion != 9 ) 
		iInf += ( pMe->m_pTelefono ? STRLEN( pMe->m_pTelefono ) : 0 );
	if( iConexion != 1 && iConexion != 6 && iConexion != 9 ) 
		iInf += ( pMe->m_pID_Tono ? STRLEN( pMe->m_pID_Tono ) : 0 );

	switch(iConexion)
	{
		// Para el proceso de actualizaci�n en la pantalla 1( INTRO )
		case 1:
		{
			
			iInf += ( pMe->m_pActualiza ? STRLEN( pMe->m_pActualiza ) : 0 );
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "actualiza.php?f=");
			if( pMe->m_pActualiza ) STRCAT(pMe->m_pUrlComp, pMe->m_pActualiza );
			STRCAT(pMe->m_pUrlComp, "&t=" );
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			//STRCAT(pMe->m_pUrlComp,"5557306307");//Para pruebas.....
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "PLAY" )
		case 2:
		{
			iInf += 16;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&t=");
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (a) )
		case 3:
		{
			iInf += 24;
			
			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&b=1&d=1&t=");
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (b) )
		case 4:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&b=1&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (c) )
		case 5:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&d=1&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Descarga del archivo tonosTMP.dat para la pantalla 5 CategoriaX
		case 6:
		{
			SPRINTF(pMe->m_pIpagCat," ");
			SPRINTF(pMe->m_pIpagCat,"%u",pMe->ipagCat);
			iInf += ( pMe->m_pIC ? STRLEN( pMe->m_pIC ) : 0 );
			iInf += ( pMe->m_pIpagCat ? STRLEN( pMe->m_pIpagCat ) : 0 );
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "categoria.php?i=");
			if( pMe->m_pIC ) STRCAT(pMe->m_pUrlComp, pMe->m_pIC);
			STRCAT(pMe->m_pUrlComp, "&p=");
			if( pMe->m_pIpagCat ) STRCAT(pMe->m_pUrlComp, pMe->m_pIpagCat);
		}
		break;
		// Actualizaci�n el archivo wish.dat en la pantalla 6 ( Wish List )
		case 7:
		{
			iInf += 18;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "wish.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&d=1&t=");
			if( pMe->m_pTelefono ) STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Actualizacion del archivo buy.dat de la pantalla MisTonos
		case 8:
		{
			iInf += 17;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "buy.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&d=1&t=");
			if( pMe->m_pTelefono ) STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;
		// Pantalla 9 ( Artista X )
		case 9:
		{
			iInf += ( pMe->m_pIA ? STRLEN(pMe->m_pIA) : 0 );
			iInf += ( pMe->m_pIPagArt ? STRLEN(pMe->m_pIPagArt) : 0 );
			iInf += 18;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "artista.php?i=" );
			if( pMe->m_pIA ) STRCAT(pMe->m_pUrlComp, pMe->m_pIA);
			STRCAT(pMe->m_pUrlComp, "&p=");
			if( pMe->m_pIPagArt ) STRCAT(pMe->m_pUrlComp, pMe->m_pIPagArt);
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (a) )
		case 10:
		{
			iInf += 24;
			
			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&w=1&d=1&t=");
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			
		}
		break;
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (b) )
		case 11:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&w=1&t=");
			//STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
		}
		break;

			case 12:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&t=");
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "&id=1");
			
		}
		break;


			case 13:
		{
			iInf += 24;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&t=");
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "&id=1");
			STRCAT(pMe->m_pUrlComp, "&d=1");
		}
		break;

		case 14:
		{
			iInf += 20;

			pMe->m_pUrlComp = (char *)MALLOC(iInf);
			STRCPY(pMe->m_pUrlComp, pMe->m_pUrlBase);
			STRCAT(pMe->m_pUrlComp, "tonos.php?i=");
			if( pMe->m_pID_Tono ) STRCAT(pMe->m_pUrlComp, pMe->m_pID_Tono);
			STRCAT(pMe->m_pUrlComp, "&t=");
			STRCAT(pMe->m_pUrlComp, pMe->m_pTelefono);
			STRCAT(pMe->m_pUrlComp, "&e=w");
		}
		break;
	
		// Descarga de tonos en la pantalla 3 TOP_10 ( caso "BUY" - "SAVE" (c) )
	}
}

/*======================================================================================================
======================================================================================================*/
void CreaArchivos(Cringtonesapp* pMe) 
{

char * pBuf = pMe->m_pContenidoBufer;
char * pTipoDoc = NULL;
char * pNombDoc = NULL;
char * pTamaDoc = NULL;
char * pPath = NULL;
char * pInicio = NULL;
char * pFinal = NULL;

uint32 iTamanio;


iTamanio = 0;

   TagContents(&pBuf, "act", &pInicio, &pFinal);					
   if(*pInicio == '1')
   {
		if(!pMe->m_pIFileMgr)
		{
			if((ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR,(void **)(&(pMe->m_pIFileMgr))))!=SUCCESS)
				return;
		}

		if(pMe->m_pIFileMgr)
		{
			pMe->m_bCiclo = TRUE;
			while(pMe->m_bCiclo)
			{

				if(TagContents(&pBuf, "tDoc", &pInicio, &pFinal))
				{
					*(pFinal + 1) = 0;
					pTipoDoc = pInicio;

					// En esta aplicaci�n no se descargan logos, por lo que se descarta el
					// el siguiente c�digo
					/*if(bActualiza)
					{
						if(!STRCMP(pTipoDoc, "logos"))
						{
							bActualiza = FALSE;
							
						    if (IFILEMGR_EnumInit(pMe->m_pIFileMgr, "logos", FALSE) != SUCCESS)
							{
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr = NULL;
								return;
							}
							
							while (IFILEMGR_EnumNext(pMe->m_pIFileMgr, pMe->m_pFileInfo) == TRUE)
							{
								IFILEMGR_Remove(pMe->m_pIFileMgr, pMe->m_pFileInfo->szName);
							}

						}
					}*/
					
					TagContents(&pBuf, "nDoc", &pInicio, &pFinal);
					*(pFinal + 1) = 0;
					pNombDoc = pInicio;
					
					pPath = (char *)MALLOC(STRLEN(pTipoDoc) + STRLEN(pNombDoc) + 2);

					if(pPath)
					{
						if( *pTipoDoc )
						{
							STRCPY(pPath, pTipoDoc);
							STRCAT(pPath, "/");		
						}
						STRCAT(pPath, pNombDoc);
					}
					else
					{
						DespliegaError(pMe, "No hay memoria");
						IFILEMGR_Release(pMe->m_pIFileMgr);
						pMe->m_pIFileMgr = NULL;
						break;
					}
					
					TagContents(&pBuf, "sDoc", &pInicio, &pFinal);
					*(pFinal + 1) = 0;
					pTamaDoc = pInicio;
					iTamanio = ATOI(pTamaDoc);

					TagContents(&pBuf, "cDoc", &pInicio, &pFinal);
					*(pFinal + 1) = 0;

					// 
					//if(!STRCMP(pTipoDoc, "tmp") || !STRCMP(pTipoDoc, "tonos") || !STRCMP(pTipoDoc, "dir_tonos_cel") )
						pBuf = pInicio + iTamanio + 6;
				}
				else
				{
					pMe->m_bCiclo = FALSE;		
				}
				if(pMe->m_bCiclo)
				{
					if(IFILEMGR_GetFreeSpace(pMe->m_pIFileMgr, NULL) > iTamanio)
					{
						if(IFILEMGR_Test(pMe->m_pIFileMgr, pPath) == SUCCESS)
						{
							if(IFILEMGR_Remove(pMe->m_pIFileMgr, pPath) == SUCCESS)	
							{
								pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pPath, _OFM_CREATE);
								if(pMe->m_pIFile)
								{
									IFILE_Write(pMe->m_pIFile, (void *)pInicio, iTamanio);
								}
							}
						}
						else
						{
							pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pPath, _OFM_CREATE);
							if(pMe->m_pIFile)
							{
								IFILE_Write(pMe->m_pIFile, (void *)pInicio, iTamanio);
							}
						}
					}
					if(pMe->m_pIFile)
					{
						IFILE_Release(pMe->m_pIFile);
						pMe->m_pIFile = NULL;
					}
					FREE(pPath);
				}
			}

			LibMem(pMe);(pMe);
		}
		else
		{
			LiberaUtil(pMe);
			DespliegaError(pMe, "Memoria insuficiente");
		}
	}
	else
	{
		DespliegaError(pMe, "No se pudo realizar la acci�n");
	}

}
/*====================================================================================================
====================================================================================================*/
void DespliegaError(Cringtonesapp * pMe, char *pMsg)
{
	AECHAR pBuf [25];
	
	STR_TO_WSTR( pMsg, pBuf, sizeof(pBuf) );
	IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
	IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, pBuf, -1, 0, 0, 0, IDF_ALIGN_TOP | IDF_ALIGN_LEFT );
	IDISPLAY_Update( pMe->a.m_pIDisplay );
	if(pMe->m_ePantalla==P_ARTISTAX && pMe->ipagArt==0)// Agregue el 7 de mayo del 2004 && pMe->m_ePantallaProc!=P_NTONOS
	{
	  if(pMe->m_ePantallaProc==P_NTONOS) // Agregue el 7 de mayo del 2004 pMe->ipagArt==0
	  pMe->edo_pantalla=6;
	  else
	  pMe->edo_pantalla=1;
	}
	//if(pMe->m_ePantalla==P_CATEGORIAX && pMe->ipagCat==0)
	
}
/*======================================================================================
  FUNCION
	LlenaCadena()
  DESCRIPCION
	Esta es una funci�n de prueba
======================================================================================*/
boolean LlenaCadena( char ** pCadena, const char * pTexto )
{
	// Se libera la memoria asignada en *pCadena si la hay
	FREEIF( *pCadena );
	// Se reserva espacio en memoria 
	*pCadena = ( char * )MALLOC( STRLEN(pTexto) + 1 );
	if( *pCadena )
	{
		STRCPY( *pCadena, pTexto );
		return TRUE;
	}
	return FALSE;
}
/*========================================================================================================
FUNCION:
	EVEtiqueta()
DESCRIPCION:
	Esta funci�n verifica si dentro de un archivo existe una etiqueta con un valor especifico.
ARGUMENTOS:
	
========================================================================================================*/
boolean EVEtiqueta( Cringtonesapp * pMe, const char * pNomArch, const char * pEt, const char * pVal)
{
	char * pBuf1 = NULL;
	char * pBuf2 = NULL;
	char * pInicio = NULL;
	char * pFinal = NULL;

	if( !LeeArchivo( pMe, pNomArch, &pBuf1 ) ) return FALSE;
	
	pBuf2 = pBuf1;

	while( TagContents(&pBuf2, pEt, &pInicio, &pFinal) )
	{
		if( !STRCMP( pInicio, pVal ) )
		{
			pBuf2 = NULL;
			FREEIF( pBuf1 );
			return TRUE;
		}
	}

	pBuf2 = NULL;
	FREEIF( pBuf1 );
	return FALSE;

}
/*========================================================================================================
FUNCION:
	OVEtiqueta()
DESCRIPCION:
	Esta funci�n obtiene el valor de una etiqueta dentro de un archivo dado el identificador del tono
ARGUMENTOS:
========================================================================================================*/
boolean OVEtiqueta( Cringtonesapp * pMe, const char * pNomArch, const char * pEt, char ** pVal)
{
	char * pBuf1 = NULL;
	char * pBuf2 = NULL;
	char * pInicio = NULL;
	char * pFinal = NULL;

	if( !LeeArchivo( pMe, pNomArch, &pBuf1 ) ) return FALSE;
	
	pBuf2 = pBuf1;

	while( TagContents(&pBuf2, "i", &pInicio, &pFinal) )
	{
		if( !STRCMP( pInicio, pMe->m_pID_Tono ) )
		{
			TagContents( &pBuf2, pEt, &pInicio, &pFinal);
			*pVal = ( char * )MALLOC( STRLEN(pInicio) + 1 );
			if( *pVal )
			{
				STRCPY( *pVal, pInicio );
				pBuf2 = NULL;
				FREEIF( pBuf1 );
				return TRUE;
			}
		}
	}

	pBuf2 = NULL;
	FREEIF( pBuf1 );
	return FALSE;

}
/*========================================================================================================
FUNCION:
	FNTono()
DESCRIPCION:
=========================================================================================================*/
boolean FNTono( Cringtonesapp * pMe, const char * pNArch, const char * pIDTono, uint16 u16Opcion )
{
	char * pBuf1 = NULL;
	char * pBuf2 = NULL;
	char * pInicio = NULL;
	char * pFinal = NULL;
	char * pTemp = NULL;

	FREEIF( pMe->m_pNTono );
	FREEIF( pMe->m_pIArchivoTono);
	if( !LeeArchivo( pMe, pNArch, &pBuf1 ) ) return FALSE;
	
	pBuf2 = pBuf1;

	while( TagContents(&pBuf2, "i", &pInicio, &pFinal) )
	{
		if( !STRCMP( pInicio, pIDTono ) )
		{
			pTemp = pInicio;
			TagContents( &pBuf2, "f", &pInicio, &pFinal );
			switch( u16Opcion )
			{
				case 1:
					pMe->m_pIArchivoTono = ( char * )MALLOC( STRLEN("tonos/") + STRLEN(pTemp) + STRLEN(pInicio) + 2 );
					STRCPY( pMe->m_pIArchivoTono, "tonos/");
					break;
				case 2:
					pMe->m_pIArchivoTono = ( char * )MALLOC( STRLEN(pTemp) + STRLEN(pInicio) + 2 );
				
					
					break;
				case 3:
					pMe->m_pIArchivoTono = ( char * )MALLOC( STRLEN("temp/") + STRLEN(pTemp) + STRLEN(pInicio) + 2 );
					STRCPY( pMe->m_pIArchivoTono, "tmp/");
					break;

				case 4:
					pTemp = pInicio;
					TagContents( &pBuf2, "t", &pInicio, &pFinal );
					pMe->m_pIArchivoTono = ( char * )MALLOC( STRLEN(pTemp) + STRLEN(pInicio) + 2 );
					STRCPY( pMe->m_pIArchivoTono, pInicio );
					STRCAT( pMe->m_pIArchivoTono, ".");
					STRCAT( pMe->m_pIArchivoTono, pTemp );
					break;
			}
			if( u16Opcion == 4 )
				break;
			if( pMe->m_pIArchivoTono )
			{
				if( u16Opcion == 2 )
				{
					if(STRCMP("buy.dat",pNArch)==0)
					{
						STRCPY(pMe->m_pIArchivoTono,"tmp/");
					}

					STRCAT( pMe->m_pIArchivoTono, pTemp );
				}
				else if( u16Opcion == 1 || u16Opcion == 3 ) 
					STRCAT( pMe->m_pIArchivoTono, pTemp );
				
				STRCAT( pMe->m_pIArchivoTono, "." );
				STRCAT( pMe->m_pIArchivoTono, pInicio );

				if( !STRCMP( pInicio, "mp3" ) ) pMe->m_SoundPlayerFile = AEE_SOUNDPLAYER_FILE_MP3;
				else if( !STRCMP( pInicio, "midi" ) ) pMe->m_SoundPlayerFile = AEE_SOUNDPLAYER_FILE_MIDI;
			}
			break;
		}
	}

	pBuf2 = NULL;
	FREEIF( pBuf1 );

	if( pMe->m_pIArchivoTono ) return TRUE;

	return FALSE;
}
/*=========================================================================================================
FUNCION:
	LiberaCadenas()
DESCRIPCION:
	Esta funci�n libera algunas cadenas que se emplean frecuentemente durante la aplicaci�n
=========================================================================================================*/
void LiberaCadenas(Cringtonesapp * pMe)
{
	FREEIF( pMe->m_pUrlBase );
	FREEIF( pMe->m_pTelefono );
	FREEIF( pMe->m_pActualiza );

}
/*====================================================================================================
FUNCION:
	DespliegaMensaje()0. 
====================================================================================================*/
boolean DespliegaMensaje(Cringtonesapp * pMe )
{

	AECHAR *wTemp = NULL;
	uint16 anchoCadena;
	AEERect * pRect;
	AECHAR wTemp2[] = {'?','\0'};

	AECHAR *pBuf1 = NULL;
	AECHAR *pBuf2 = NULL;
	int iTam=0;

	DetenerAnimDescarga(pMe);


	pRect = ( AEERect * )MALLOC( sizeof(AEERect) );
	if( !pRect ) return TRUE;
	switch(pMe->m_u16Opcion1)
	{
		case 1:
			// Cadena de recurso: �Desea comprar?
			iTam = 2*STRLEN( pMe->m_pNTono ) + 2;
			pBuf2 = (AECHAR*)MALLOC( iTam );
			if( !pBuf2 )
			{
				FREEIF( pRect );
				return TRUE;
			}
			iTam += 32;
			pBuf1 = (AECHAR*)MALLOC( iTam );
			if( !pBuf1 )
			{
				FREEIF( pRect );
				FREEIF( pBuf1 );
				return TRUE;
			}
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_COMPRAR, pBuf1, iTam );
			STRTOWSTR( pMe->m_pNTono, pBuf2, 2*STRLEN(pMe->m_pNTono) + 2 );
			WSTRCAT( pBuf1, pBuf2 );
			WSTRCAT( pBuf1, wTemp2);
			FREEIF( pBuf2 );
		break;

		case 2:
			// Cadena de recurso: ya ha sido comprado
			iTam = 2*STRLEN( pMe->m_pNTono ) + 2;
			pBuf2 = (AECHAR*)MALLOC( iTam );
			if( !pBuf2 )
			{
				FREEIF( pRect );
				return TRUE;
			}
			iTam += 32;
			pBuf1 = (AECHAR*)MALLOC( iTam );
			if( !pBuf1 )
			{
				FREEIF( pRect );
				FREEIF( pBuf1 );
				return TRUE;
			}
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_COMPRADO, pBuf1, iTam );
			STRTOWSTR( pMe->m_pNTono, pBuf2, 2*STRLEN(pMe->m_pNTono) + 2 );
			WSTRCAT( pBuf1, pBuf2 );
			FREEIF( pBuf2 );
		break;
	
		case 4:
			pBuf1 = ( AECHAR * )MALLOC( 98 );
			if( !pBuf1 )
			{
				FREEIF( pRect );
				return TRUE;
			}
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_NOHAYTONOS, pBuf1, 98 );
			IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(255,153,0) );
			SETAEERECT(pRect, 1, 4 + pMe->m_cyPantalla/2 - 10 - 8, pMe->m_cxPantalla - 1, 27);
			IDISPLAY_DrawFrame(pMe->a.m_pIDisplay, pRect, AEE_FT_NONE, MAKE_RGB(255,153,0));
			SETAEERECT(pRect, 5, 4 + pMe->m_cyPantalla/2 - 6 - 8, pMe->m_cxPantalla - 9, 19);
			IDISPLAY_DrawFrame(pMe->a.m_pIDisplay, pRect, AEE_FT_NONE, MAKE_RGB(255,255,255));
			SETAEERECT(pRect, 7, 4 + pMe->m_cyPantalla/2 - 4 - 8, pMe->m_cxPantalla - 13, 15);

			wTemp = pBuf1;
			wTemp += pMe->cont;

			// Se obtienen el ancho en pixeles del segmento
			anchoCadena = (uint16)IDISPLAY_MeasureText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, pRect, IDF_ALIGN_LEFT | IDF_ALIGN_MIDDLE);
			IDISPLAY_Update(pMe->a.m_pIDisplay);
			FREEIF(pRect);
			FREEIF(pBuf1);

			pMe->cont++;

			return TRUE;

		break;
		case 5:
				pBuf1 = ( AECHAR * )MALLOC( 98 );
				ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_NOEXISTE, pBuf1, 98 );
				IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
				IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, pRect, IDF_ALIGN_LEFT | IDF_ALIGN_MIDDLE);
				IDISPLAY_Update(pMe->a.m_pIDisplay);
			
		break;

		case 6:
				pBuf1 = ( AECHAR * )MALLOC( 100 );
				ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_COMPRADO, pBuf1, 98 );
				IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
				IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, NULL, IDF_ALIGN_LEFT | IDF_ALIGN_MIDDLE);
				IDISPLAY_Update(pMe->a.m_pIDisplay);
			
		break;
		case 7:
				pBuf1 = ( AECHAR * )MALLOC( 98 );
				ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_SINTONOS, pBuf1, 98 );
				IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
				IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pBuf1, -1, 0, 0, NULL, IDF_ALIGN_MIDDLE | IDF_ALIGN_CENTER);
				ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_SINTONOS2, pBuf1, 98 );
				IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pBuf1, -1, 0, (pMe->m_cyPantalla/2)+5, NULL, IDF_ALIGN_CENTER);
				IDISPLAY_Update(pMe->a.m_pIDisplay);
				FREEIF(pBuf1);
				FREEIF(pRect);
				return TRUE;////////////// Abril 15
			
		break;

	}

	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));


	wTemp = pBuf1;
	wTemp += pMe->cont;

	// Se obtienen el ancho en pixeles del segmento
	anchoCadena = (uint16)IDISPLAY_MeasureText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);

	// En el caso de que la longitud de la cadena sea menor que el ancho de la
	// pantalla, la pr�xima vez que se llame a s� misma esta funci�n se mostrar�
	// la siguiente cadena
	if(anchoCadena < (pMe->m_cxPantalla - 16))
	{
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
		IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, NULL, IDF_ALIGN_MIDDLE|IDF_ALIGN_CENTER);
		IDISPLAY_Update(pMe->a.m_pIDisplay);
		FREEIF(pRect);
		FREEIF(pBuf1);
		pBuf1 = NULL;
		wTemp = NULL;
		pMe->cont = 0;

		//MODIFICACION REALIZADA EL 13/05/04
		//ISHELL_SetTimer(pMe->a.m_pIShell, 800,(PFNNOTIFY)DespliegaMensaje, (void *)pMe);

		return TRUE;
	}
	// Si la longitud de la cadena es mayor que el ancho de la pantalla, la pr�xima
	// vez que se llame a s� misma esta funci�n trabajar� con la misma cadena pero
	// con el apuntador de inicio recorrido una posici�n hacia delante
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, 0, 0, pRect, IDF_ALIGN_LEFT | IDF_ALIGN_MIDDLE);
	IDISPLAY_Update(pMe->a.m_pIDisplay);
	FREEIF(pRect);
	FREEIF(pBuf1);
    ISHELL_SetTimer(pMe->a.m_pIShell, 300, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);
	pMe->cont++;

	return TRUE;
}

boolean DespliegaMensaje2( Cringtonesapp * pMe, uint16 opcion )
{
	int iAltura, iLongitud;
	AECHAR * wTemp = NULL;
	char * pBuf = NULL;
	int xPos = 0;
	int yPos = 0;

	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_TEXT, MAKE_RGB(0,0,0));
	IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
	IDISPLAY_ClearScreen( pMe->a.m_pIDisplay );
	IDISPLAY_Update ( pMe->a.m_pIDisplay );
	
	switch( opcion )
	{
		case 2:
			
			pBuf = ( char * )MALLOC(16);
			wTemp = ( AECHAR * )MALLOC(32);
			
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_COMPRADO, wTemp, 32);

			iAltura = IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, NULL, NULL );
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp);
			yPos = ( pMe->m_cyPantalla - (2*iAltura + 1) ) / 2;
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp, -1, xPos, yPos, NULL, 0 );
			FREEIF( wTemp );
			wTemp = ( AECHAR * )MALLOC( 2*STRLEN(pMe->m_pNTono) + 2 );
			STRTOWSTR( pMe->m_pNTono, wTemp, 2*STRLEN(pMe->m_pNTono) + 2 );
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );
			IDISPLAY_Update( pMe->a.m_pIDisplay );
			FREEIF( wTemp );
			FREEIF( pBuf );

			break;
		
		case 3:

			wTemp = ( AECHAR * )MALLOC( 2*STRLEN(pMe->m_pNTono) + 2 );
			STRTOWSTR( pMe->m_pNTono, wTemp, 2*STRLEN(pMe->m_pNTono) + 2 );
			iAltura = IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_BOLD, NULL, NULL );
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = ( pMe->m_cyPantalla - (3*iAltura + 2) ) / 2;
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );

			FREEIF(wTemp);

			wTemp = ( AECHAR * )MALLOC(32);
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_GUARDADO1, wTemp, 32);
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp, -1, xPos, yPos, NULL, 0 );

			FREEIF(wTemp);

			wTemp = ( AECHAR * )MALLOC(26);
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_GUARDADO2, wTemp, 26);
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp, -1, xPos, yPos, NULL, 0 );

			FREEIF(wTemp);

			IDISPLAY_Update( pMe->a.m_pIDisplay );

			break;

		case 4:

			/* MEMORIA INSUFICIENTE */

			wTemp = ( AECHAR * )MALLOC(28);
			
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_MEMORIA, wTemp, 16);

			iAltura = IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_BOLD, NULL, NULL );
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = ( pMe->m_cyPantalla - (2*iAltura + 1) ) / 2;
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );
		

			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_INSUFICIENTE, wTemp, 28);
			
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );
			IDISPLAY_Update( pMe->a.m_pIDisplay );
			FREEIF( wTemp );

			break;

		case 5:

			/* NO HAY CONEXION DISPONIBLE */

			wTemp = ( AECHAR * )MALLOC(32);
			
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_NOCONEX1, wTemp, 32);

			iAltura = IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_BOLD, NULL, NULL );
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = ( pMe->m_cyPantalla - (2*iAltura + 1) ) / 2;
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );
		

			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_NOCONEX2, wTemp, 28);
			
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );
			IDISPLAY_Update( pMe->a.m_pIDisplay );
			FREEIF( wTemp );

			break;


	case 6:
			
			/*NO EXISTEN MAS TONOS PARA EL ARTISTA SELECCIONADO*/
	
			wTemp = ( AECHAR * )MALLOC( 2*STRLEN(pMe->m_pIA) + 2 );
			STRTOWSTR( pMe->m_pNTono, wTemp, 2*STRLEN(pMe->m_pIA) + 2 );
			iAltura = IDISPLAY_GetFontMetrics( pMe->a.m_pIDisplay, AEE_FONT_BOLD, NULL, NULL );
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp);
			yPos = ( pMe->m_cyPantalla - (3*iAltura + 2) ) / 2;
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			//IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_BOLD, wTemp, -1, xPos, yPos, NULL, 0 );

			FREEIF(wTemp);

			wTemp = ( AECHAR * )MALLOC(42);
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_SINARTISTA1, wTemp, 42);
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp, -1, xPos, yPos, NULL, 0 );

			FREEIF(wTemp);

			wTemp = ( AECHAR * )MALLOC(36);
			ISHELL_LoadResString( pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_SINARTISTA2, wTemp, 36);
			iLongitud = IDISPLAY_MeasureText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp);
			yPos = yPos + iAltura + 1;	
			xPos = ( pMe->m_cxPantalla - iLongitud ) / 2;
			IDISPLAY_DrawText( pMe->a.m_pIDisplay, AEE_FONT_NORMAL, wTemp, -1, xPos, yPos, NULL, 0 );

			FREEIF(wTemp);

			IDISPLAY_Update( pMe->a.m_pIDisplay );

			break;

	}

	return TRUE;	
}



/*=================================================================================================
FUNCION:
	EliminaArchivos()
DESCRIPCION:
	Esta funci�n elimina los archivos almacenados en el directorio especificado
=================================================================================================*/
boolean EliminaArchivos( Cringtonesapp * pMe, const char * pNomDir )
{	
	if( !pMe->m_pIFileMgr )
	{
		if( ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr ) != SUCCESS )
			return FALSE;
	}
	// El tercer argumento indica que solo se enumeran los archivos
	if( IFILEMGR_EnumInit( pMe->m_pIFileMgr, pNomDir, FALSE ) == EFAILED )
	{
		IFILEMGR_Release( pMe->m_pIFileMgr );
		pMe->m_pIFileMgr = 0;
		return FALSE;
	}
	// Se eliminan los archivos del directorio
	while( IFILEMGR_EnumNext( pMe->m_pIFileMgr, pMe->m_pFileInfo ) )
	{
		IFILEMGR_Remove( pMe->m_pIFileMgr, pMe->m_pFileInfo->szName );
	}
	// Se elimina el directorio
	IFILEMGR_RmDir( pMe->m_pIFileMgr, pNomDir );
	// Se libera la instancia
	IFILEMGR_Release( pMe->m_pIFileMgr );
	pMe->m_pIFileMgr = 0;

	return TRUE;
}
/*=====================================================================================================
FUNCION:
	CreaRingTone()
DESCRIPCION:
	Esta funcion crea el ringtone de nombre pMe->m_pNTono a partir del archivo con nombre
	pMe->m_pIArchivoTono
=====================================================================================================*/
boolean CreaRingTone( Cringtonesapp * pMe )
{
	AECHAR * wTemp = 0;
	byte * pBuf;

	// Se reserva espacio para el nombre del tono
	wTemp = ( AECHAR * )MALLOC( 2*( STRLEN( pMe->m_pNTono ) + 1 ) );
	if( !wTemp ) return FALSE;
	// Se obtiene el nombre del tono en AECHAR
	STRTOWSTR( pMe->m_pNTono, wTemp, 2*(STRLEN( pMe->m_pNTono ) + 1 ) );
	
	if( !pMe->m_pIRingerMgr )
		ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_RINGERMGR, (void **)&pMe->m_pIRingerMgr); 
	
	if(pMe->m_pIRingerMgr == NULL)
	{
		FREEIF( wTemp );
		return FALSE;
	}

	if( !pMe->m_pIFileMgr )
		ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)(&pMe->m_pIFileMgr));
	
	if (NULL == pMe->m_pIFileMgr)
	{
		FREEIF( wTemp );
		RELEASEIF( pMe->m_pIRingerMgr );
		return FALSE;
	}
	if (NULL == (pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->m_pIArchivoTono, _OFM_READ ) ) )
	{
		RELEASEIF( pMe->m_pIFileMgr );
		RELEASEIF( pMe->m_pIRingerMgr );
		FREEIF( wTemp );
		return FALSE;
	} 

	IFILE_GetInfo( pMe->m_pIFile, pMe->m_pFileInfo );
	if (NULL == ( pBuf = (byte *) MALLOC(pMe->m_pFileInfo->dwSize)))
	{
		RELEASEIF( pMe->m_pIFileMgr );
		RELEASEIF( pMe->m_pIRingerMgr );
		FREEIF( wTemp );
		return FALSE;
	}

	// Read the contents of the ringer file into the
	// area allocated in memory for it
	if (IFILE_Read(pMe->m_pIFile, (void *)pBuf, pMe->m_pFileInfo->dwSize) == 0)
	{
		RELEASEIF( pMe->m_pIFileMgr );
		RELEASEIF( pMe->m_pIRingerMgr );
		FREEIF( wTemp );
		FREEIF( pBuf );
		return FALSE;
	}

	RELEASEIF( pMe->m_pIFile );
	
	if( !pMe->m_pIMemStream )
		ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MEMASTREAM, (void **)(&pMe->m_pIMemStream));

	if (NULL == pMe->m_pIMemStream)
	{
		RELEASEIF( pMe->m_pIFileMgr );
		RELEASEIF( pMe->m_pIRingerMgr );
		FREEIF( pBuf );
		FREEIF( wTemp );
		return FALSE;
	}

	IMEMASTREAM_Set(pMe->m_pIMemStream, pBuf, pMe->m_pFileInfo->dwSize, 0, 0);
    if(IRINGERMGR_Create(pMe->m_pIRingerMgr,(AECHAR*)wTemp, pMe->m_SoundPlayerFile, (IAStream*)pMe->m_pIMemStream)==EFAILED)
	{
		RELEASEIF( pMe->m_pIFileMgr );
		RELEASEIF( pMe->m_pIRingerMgr );
		RELEASEIF( pMe->m_pIMemStream );
		pMe->m_pIMemStream = NULL;
		return FALSE;
	}
	
	//BuscaTono(pMe);	
	IFILEMGR_Remove( pMe->m_pIFileMgr, pMe->m_pIArchivoTono );

	RELEASEIF( pMe->m_pIFileMgr );
	RELEASEIF( pMe->m_pIRingerMgr );
	RELEASEIF( pMe->m_pIMemStream );
	pMe->m_pIMemStream = NULL;
	// La responsabilidad de liberar el bufer pBuf corresponde a la interfaz IMemStream
	// Si se libera con el FREEIF marca error de liberaci�n de memoria
	// El buffer se libera cuando se libera la interfaz IMemStream
	//FREEIF( pBuf );
	FREEIF( wTemp );
	
	return TRUE;
}

/*===============================================================================================
FUNCION:
	BuscaTono
DESCRIPCION:
	Esta funci�n verifica si el ringtone con nombre pMe->m_pNTono + la extension correspondiente
	existe en el directorio de ringtones del tel�fono. La extensi�n que se utiliza depende del
	valor de pMe->m_SounPlayerFile ( MIDI o MP3 ).
===============================================================================================*/
boolean BuscaTono( Cringtonesapp * pMe )
{
	char * pTemp = NULL;

	if( pMe->m_SoundPlayerFile == AEE_SOUNDPLAYER_FILE_MP3 ) 
	{
		pTemp = ( char * )MALLOC( STRLEN( pMe->m_pNTono ) + 5 );
		if( pTemp )
		{
			STRCPY( pTemp, pMe->m_pNTono );
			STRCAT( pTemp, ".mp3");
		}
	}
	else if( pMe->m_SoundPlayerFile == AEE_SOUNDPLAYER_FILE_MIDI )
	{
		pTemp = ( char * )MALLOC( STRLEN( pMe->m_pNTono ) + 5 );
		if( pTemp )
		{
			STRCPY( pTemp, pMe->m_pNTono );
			STRCAT( pTemp, ".mid");
		}
	}

	if( !pTemp ) return FALSE;

	if( !pMe->m_pIRingerMgr )
		ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_RINGERMGR, (void **)&pMe->m_pIRingerMgr); 
	
	if(pMe->m_pIRingerMgr == NULL)
	{
		FREEIF( pTemp );
		return FALSE;
	}	

	pMe->m_AEERingerID = IRINGERMGR_GetRingerID( pMe->m_pIRingerMgr, pTemp );
	
	if( pMe->m_AEERingerID == AEE_RINGER_ID_NONE )
	{
		FREEIF( pTemp );
		RELEASEIF( pMe->m_pIRingerMgr );
		return FALSE;
	}

	FREEIF( pTemp );
	RELEASEIF( pMe->m_pIRingerMgr );
	return TRUE;		
}

/*==============================================================================================
	FUNCION:
		ReproduceTono()
	DESCRIPCION:
		La siguiente funci�n utiliza la interfaz IRinger para reproducir el tono especifica
==============================================================================================*/
boolean ReproduceTono( Cringtonesapp * pMe, uint16 band ) 
{
	if( !pMe->m_pIRingerMgr )
		ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_RINGERMGR, ( void ** )&( pMe->m_pIRingerMgr ) );
	
	if( !pMe->m_pIRingerMgr ) return FALSE;

	// band = 1; se especifica el ID del ringer
	if( band == 1 )	
	{
		if( IRINGERMGR_Play( pMe->m_pIRingerMgr, pMe->m_AEERingerID, 2 ) == EFAILED )
		{					
			RELEASEIF( pMe->m_AEERingerID );
			pMe->m_AEERingerID=NULL;
			return FALSE;
		}
		return TRUE;
	}
	// band = 2; se utiliza un archivo en el directorio de la aplicaci�n
	else if( band == 2 )
	{ 
		if( IRINGERMGR_PlayFile( pMe->m_pIRingerMgr, pMe->m_pIArchivoTono,2 ) == EFAILED )
		{
			RELEASEIF( pMe->m_AEERingerID );
			return FALSE;
		}
	//	IFILEMGR_Remove( pMe->m_pIFileMgr, pMe->m_pIArchivoTono );
		return TRUE;
	}

	RELEASEIF( pMe->m_pIRingerMgr );
	return FALSE;
}

boolean OrdenaTonos(Cringtonesapp * pMe)
{
	
   FileInfo pFInfo;
   char *pFileBuf =NULL;
   char *FileBuf=NULL;
   char *End=NULL;
   char *t=NULL;
   char *c=NULL;
   char *i=NULL;
   char *a=NULL;
   
   int cont;
   boolean SEGUIR_CICLO=TRUE;
   
   AECHAR Destino[50];
  
   CtlAddItem A1;
   char *itemData=NULL;
   AEERect rAreaAct;
   

   
	if(pMe->m_pIMenuActivo)
	{
		IMENUCTL_SetActive(pMe->m_pIMenuActivo,FALSE);
		IMENUCTL_Release(pMe->m_pIMenuActivo);
		pMe->m_pIMenuActivo=NULL;
	}
	if(pMe->m_pISKMenu)
	{
		IMENUCTL_Redraw(pMe->m_pISKMenu);
	}

if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr){
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}

	if (!pMe->m_pIMenuActivo){
	if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_MENUCTL, (void **)&pMe->m_pIMenuActivo) != SUCCESS)
		return FALSE;
	}


	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}
	if( pMe->m_ePantallaProc == P_CATEGORIAS )
		if(!pMe->m_pIFile) //dependiendo del valor de iPagArt abre el archivo correspondiente.
		{
				if(pMe->ipagCat==0)
					pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, pMe->ArchivoCat, _OFM_READ);
				else
					pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "tonosTMP.dat", _OFM_READ);
		}

	if( pMe->m_ePantalla == P_TOP10 )
		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "topten.dat", _OFM_READ);

	if( pMe->m_ePantalla == P_NTONOS )
		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "new.dat", _OFM_READ);

	if( pMe->m_ePantalla == P_WISHLST )
		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "wish.dat", _OFM_READ);

	if( pMe->m_ePantalla == P_MTONOS )
		pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "buy.dat", _OFM_READ);
	
	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
			return FALSE;
	

	if (pMe->m_pIFile )
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
	if(pMe->m_pIFile) {
		IFILE_Release(pMe->m_pIFile);
		pMe->m_pIFile=NULL;
	}
	if (pMe->m_pIFileMgr){
		IFILEMGR_Release(pMe->m_pIFileMgr);
		pMe->m_pIFileMgr=NULL;
	}


	SETAEERECT(&(rAreaAct), 5,40,pMe->m_cxPantalla-19,pMe->m_cyPantalla-62);


		cont=0;
		if(pMe->m_eEntorno==E_SORT_ARTISTA) //indica que es por artista
		{
		
			while(SEGUIR_CICLO)
			{
					
				if (!TagContents(&FileBuf,"i>",&i,&End))
					break;

				
				
			TagContents(&FileBuf,"t",&t,&End);
			TagContents(&FileBuf,"a",&a,&End);
			TagContents(&FileBuf,"c",&c,&End);
		

			STRTOWSTR(a, Destino, sizeof(Destino));


			itemData = NULL;
			ConcatenaSegmento(&itemData, i, 1);
			ConcatenaSegmento(&itemData, "ARTISTA:", 2);
			ConcatenaSegmento(&itemData, a, 3);
			ConcatenaSegmento(&itemData, "CATEGOR�A", 4);
			ConcatenaSegmento(&itemData, c, 5);



				A1.pText = Destino;
				A1.pImage = pMe->m_pImagen1;
				A1.pszResImage = A1.pszResText = NULL;
				A1.wFont =0;
				A1.dwData = (uint32)itemData;
				A1.wText =NULL;
				A1.wImage = NULL;
				A1.wItemID =(uint16)cont;
				IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
				IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_NO_REDRAW); //NO VA ACTUALIZAR INMEDIATAMENTE LA PANTALLA COMO REDRAW HASTA QUE SE LE INDIQUE
				IMENUCTL_Sort(pMe->m_pIMenuActivo, MCS_NAME_ASCENDING);
				cont++;
			}
			
		
			FREEIF(pFileBuf);
			pFileBuf=NULL;
			FREEIF(FileBuf);
			FileBuf=NULL;

			IIMAGE_Release(pMe->m_pImagen1);
			pMe->m_pImagen1=NULL;
			itemData=NULL;
		
			IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
			IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
			IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
			IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_BI_STATE_IMAGE);
			IMENUCTL_SetSel(pMe->m_pIMenuActivo, pMe->m_eOpcion2);
			IMENUCTL_Redraw(pMe->m_pIMenuActivo);
			IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
		
		}

	
		if(pMe->m_eEntorno==E_SORT_TITULO)
		{
			while(SEGUIR_CICLO)
			{
			
				if (!TagContents(&FileBuf,"i>",&i,&End))
					break;

				
				
			TagContents(&FileBuf,"t",&t,&End);
			TagContents(&FileBuf,"a",&a,&End);
			TagContents(&FileBuf,"c",&c,&End);
		

			STRTOWSTR(t, Destino, sizeof(Destino));


			itemData = NULL;
			ConcatenaSegmento(&itemData, i, 1);
			ConcatenaSegmento(&itemData, "ARTISTA:", 2);
			ConcatenaSegmento(&itemData, a, 3);
			ConcatenaSegmento(&itemData, "CATEGOR�A", 4);
			ConcatenaSegmento(&itemData, c, 5);



				A1.pText = Destino;
				A1.pImage = pMe->m_pImagen1;
				A1.pszResImage = A1.pszResText = NULL;
				A1.wFont =0;
				A1.dwData = (uint32)itemData;
				A1.wText =NULL;
				A1.wImage = NULL;
				A1.wItemID =(uint16)cont;
				IMENUCTL_AddItemEx(pMe->m_pIMenuActivo, &A1);
				IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_NO_REDRAW);
				IMENUCTL_Sort(pMe->m_pIMenuActivo, MCS_NAME_ASCENDING);
				cont++;
			}
					
			FREEIF(pFileBuf);
			pFileBuf=NULL;
			FREEIF(FileBuf);
			FileBuf=NULL;


			IIMAGE_Release(pMe->m_pImagen1);
			pMe->m_pImagen1=NULL;
			itemData=NULL;
		
			IMENUCTL_SetRect(pMe->m_pIMenuActivo,&rAreaAct);
			IMENUCTL_SetColors(pMe->m_pIMenuActivo,&pMe->m_AEEMenCol);
			IMENUCTL_SetStyle(pMe->m_pIMenuActivo,&pMe->pNormal,&pMe->pActive);
			IMENUCTL_SetProperties(pMe->m_pIMenuActivo,MP_BI_STATE_IMAGE);
			IMENUCTL_SetSel(pMe->m_pIMenuActivo, pMe->m_eOpcion2);
			IMENUCTL_Redraw(pMe->m_pIMenuActivo);
			IMENUCTL_SetActive(pMe->m_pIMenuActivo,TRUE);
			
		}

	return TRUE;	

}

void Funcion_Common(Cringtonesapp * pMe, uint16 wParam)
{
	 char *Dato='\0';
					
					if(pMe->m_ePantalla!=P_SORT)
					{
						if((pMe->m_ePantalla!=P_CAT &&pMe->m_ePantallaProc!=P_TOP10))
						{
							pMe->m_eSort=FALSE;
							pMe->m_ePantallaProc=pMe->m_ePantalla;
							pMe->m_ePantalla=P_CATEGORIAX;
							pMe->m_eEntorno=E_CATEGORIAX;
						}
						if( pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_TOP10 || 
							pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_NTONOS ||
							pMe->m_ePantalla==P_CAT && pMe->m_ePantallaProc==P_MTONOS )
						{
							pMe->m_eSort=FALSE;
							pMe->m_eEntorno=E_CATEGORIAX;
						}
					}
					else
					{
						pMe->m_eSort=TRUE;
						if( pMe->m_ePantallaProc == P_CATEGORIAS || pMe->m_ePantallaProc == P_CATEGORIAX )
						{
							pMe->m_ePantallaProc=P_CATEGORIAS;
							pMe->m_ePantalla=P_CATEGORIAX;
						}
						if( pMe->m_ePantallaProc == P_NTONOS )
						{
							pMe->m_ePantallaProc = P_MENUINICIO;
							pMe->m_ePantalla = P_NTONOS; 
						}
						if( pMe->m_ePantallaProc == P_TOP10 )
						{
							pMe->m_ePantallaProc = P_MENUINICIO;
							pMe->m_ePantalla = P_TOP10;
						}
						if( pMe->m_ePantallaProc == P_WISHLST )
						{
							pMe->m_ePantallaProc = P_MENUINICIO;
							pMe->m_ePantalla = P_WISHLST;
						}
						if( pMe->m_ePantallaProc == P_MTONOS )
						{
							pMe->m_ePantallaProc = P_MENUINICIO;
							pMe->m_ePantalla = P_MTONOS;
						}
					}
					
			
					
					if(pMe->m_pImagen1)
					{
						IIMAGE_Release(pMe->m_pImagen1);
						pMe->m_pImagen1=NULL;
					}
					LibMem(pMe);
				

					pMe->m_eOpcion=0;
					pMe->m_eOpcion2=0;
					
					//c�digo menu con datos en movimiento
					pMe->cont = 0;
					pMe->bandera = 2;

					
					if( pMe->m_ePantalla == P_CATEGORIAX || pMe->m_ePantalla == P_CAT )
					{
						if( pMe->m_ePantalla == P_CATEGORIAX )
							pMe->m_ePantalla = P_CATEGORIAS;
						
					
						buscaDatoID(pMe, wParam, &Dato, "c"); //CHECAR EN CUANTO AL SORT DE ALTERNATIVO
						STRTOWSTR(Dato, pMe->BufferCat, 2 * (STRLEN(Dato)+1) );
						FREEIF(Dato);
						Fondo_ID(pMe);

						//IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, pMe->BufferCat, -1, 0, 0, NULL,IDF_ALIGN_LEFT); //despliega el nombre de la categor�a en la esquina superior izquierda
						//IDISPLAY_Update(pMe->a.m_pIDisplay);
						
						buscaDatoID(pMe, wParam, &Dato, "ic"); //(wParam+1) por detalles de la funci�n
					
						FREEIF(pMe->ArchivoCat);
	

						if(!pMe->ArchivoCat)

							pMe->ArchivoCat = (char *)MALLOC(13 + STRLEN(Dato) + 5);

				
						if (pMe->ipagCat==0){
							
							STRCPY(pMe->ArchivoCat, "cat");
							STRCAT(pMe->ArchivoCat, Dato);
							STRCAT(pMe->ArchivoCat, ".dat");
							FREEIF(Dato);
							creaSK(pMe);
							LibMem(pMe);
							creaMenuMov(pMe, pMe->ArchivoCat); //Utiliza el archivo catX.dat, donde X es el valor de <ic>
							
							
						}
						else{ // caso de que pMe->ipagCat sea distinto de cero

							pMe->m_pIC=Dato;
							FormarUrl(pMe,6);
							pMe->m_eDestInfo = BUFER;
							FREEIF(Dato);
							IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
							IDISPLAY_Update(pMe->a.m_pIDisplay);
							ConexionWeb( pMe, pMe->m_pUrlComp, NULL);
					
							/*descargar el archivo de (URL_BASE/inalambrico/categoria.php?i=ic&p=ipagCat)
							en el archivo /tonosTMP.dat
							Checar el valor de la etiqueta <n>,
							Si es mayor que cero
								cargar el men� de �ste archivo
							si no 
								mostrar mensaje de que ya no existen m�s tonos para esa categoria
								Decrementar ipagCat;
								Pasar a la pantalla 5 con el valor de <ic>*/

						}
					}
					//LibMem(pMe);
					if( pMe->m_ePantalla == P_TOP10 )
					{
						creaMenuMov( pMe, "topten.dat" );
					}

					if( pMe->m_ePantalla == P_NTONOS)
					{
						creaMenuMov( pMe, "new.dat" );
					}

					if( pMe->m_ePantalla == P_WISHLST )
					{
						creaMenuMov( pMe, "wish.dat" );
					}
					if( pMe->m_ePantalla == P_MTONOS )
					{
						creaMenuMov( pMe, "buy.dat" );
					}
					
				DespliegaTexto(pMe); //CHECAR AQUI PARA SONIDOS
				if( pMe->m_ePantalla == P_CATEGORIAS )
					pMe->m_ePantalla = P_CATEGORIAX;
				creaSK(pMe);
									
				//c�digo menu con datos en movimiento
}


boolean Lectura_Temp2(Cringtonesapp * pMe)
{
	char *n; //para dar lectura del numero de tonos
	int N;
	
	FileInfo pFInfo;
	char *pFileBuf =NULL;
	char *FileBuf=NULL;
	char *End=NULL;


	
	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	if(!pMe->m_pIFile) //dependiendo del valor de iPagArt abre el archivo correspondiente.
	{
		
			pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "tonosTMP.dat", _OFM_READ);
	}


	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
			return FALSE;
	

	if (pMe->m_pIFile)
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
		
	if (TagContents(&FileBuf,"n",&n,&End))
	{
		N=ATOI(n);
		FREEIF(pFileBuf);
		if(N>0)
		{
			if(ISHELL_GetTimerExpiration(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe) != 0)
				ISHELL_CancelTimer(pMe->a.m_pIShell, (PFNNOTIFY)DespliegaMensaje, (void *)pMe);   
			
			
			creaMenuMov(pMe,"tonostmp.dat");
			
			DespliegaTexto(pMe);
			creaSK(pMe);
			
		}
	
		if(N<=0)
		{
			IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
			IDISPLAY_Update(pMe->a.m_pIDisplay);
			Fondo_ID(pMe);
			//pMe->m_u16Opcion1=5;
			DespliegaMensaje2(pMe,6);

			pMe->ipagArt--;
			if(pMe->ipagArt<0) // cuando ipagArt es menor que cero se tiene que regresar a las pantallas principales TOP10, CATEGORIAS, etc
			{
				//pMe->m_ePantalla=P_CATEGORIAS;
				switch (pMe->m_ePantallaProc)
				{
					case P_TOP10:
						pMe->m_ePantalla=P_TOP10;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_TOP10;
					break;
					case P_WISHLST:
						pMe->m_ePantalla=P_WISHLST;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_WISHLST;
					break;
					case P_NTONOS:
						pMe->m_ePantalla=P_NTONOS;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_NTONOS;
					break;
					case P_MTONOS:
						pMe->m_ePantalla=P_MTONOS;
						pMe->m_ePantallaProc=P_MENUINICIO;
						pMe->m_eEntorno=E_MTONOS;
					break;
					case P_CATEGORIAX:
						pMe->m_ePantalla=P_CATEGORIAX;
						pMe->m_ePantallaProc=P_CATEGORIAS;
						pMe->m_eEntorno=E_CATEGORIAX;
					break;

				}
			
				if (pMe->m_pIFileMgr){
					IFILEMGR_Release(pMe->m_pIFileMgr);
					pMe->m_pIFileMgr=NULL;
				}
				if(pMe->m_pIFile) {
					IFILE_Release(pMe->m_pIFile);
					pMe->m_pIFile=NULL;
				}
				pMe->m_regresoArtista=TRUE;				
				ISHELL_SetTimer(pMe->a.m_pIShell, 5000, (PFNNOTIFY)regresaMenuMov, (void *)pMe);
				
			}
			else // cuando ipagArt es mayor que cero se regresa a la pantalla de +ART correpondiente al ipagArt decrementado
			{
				if (pMe->m_pIFileMgr){
					IFILEMGR_Release(pMe->m_pIFileMgr);
					pMe->m_pIFileMgr=NULL;
				}
				if(pMe->m_pIFile) {
					IFILE_Release(pMe->m_pIFile);
					pMe->m_pIFile=NULL;
				}
						
				SPRINTF(pMe->m_pIPagArt," "); //la cadena es pMe->m_pIPagArt
				SPRINTF(pMe->m_pIPagArt,"%u",pMe->ipagArt);
				
				FormarUrl(pMe,9);
				pMe->m_eDestInfo = BUFER;
				ISHELL_SetTimer(pMe->a.m_pIShell, 5000, (PFNNOTIFY)Conexion_TMP, (void *)pMe);

			}
		
		}
	}	
	
	return TRUE;
}

void Regresa_PantallaArtista(Cringtonesapp * pMe)
{
	IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
	IDISPLAY_Update(pMe->a.m_pIDisplay);
	Funcion_Common(pMe, pMe->WP);
}

boolean Lectura_Temp(Cringtonesapp * pMe)
{
	char *n; //para dar lectura del numero de tonos
	int N;
	char *Dato;
	
	FileInfo pFInfo;
	char *pFileBuf =NULL;
	char *FileBuf=NULL;
	char *End=NULL;
	

	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	if(!pMe->m_pIFile) //dependiendo del valor de iPagArt abre el archivo correspondiente.
	{
		
			pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "tonosTMP.dat", _OFM_READ);
	}
	
	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
			return FALSE;
	

	if (pMe->m_pIFile)
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}   
	else
		return FALSE;
	
		
	if (TagContents(&FileBuf,"n",&n,&End))
	{
		N=ATOI(n);
		if(N>0)
		{
			creaMenuMov(pMe,"tonostmp.dat");
		}
		else
		{	//Aqui el valor de N<=0
			pMe->NTONOS_TMP=N; //c e ic el nombre de categoria por ejemplo ALTERNATIVO ROCK GRUNGE ETC
			pMe->m_u16Opcion1=4;
			pMe->ipagCat--; //hay que recargar el menu de nuevo con el nuevo valor de pMe->ipagCat
			DespliegaMensaje(pMe);
			if(TagContents(&FileBuf,"ic",&Dato,&End))
			{
				pMe->m_pIC=Dato;
			}
			if (pMe->m_pIFileMgr){
				IFILEMGR_Release(pMe->m_pIFileMgr);
				pMe->m_pIFileMgr=NULL;
			}
			if(pMe->m_pIFile) {
				IFILE_Release(pMe->m_pIFile);
				pMe->m_pIFile=NULL;
			}

			FREEIF(pFileBuf);
			pFileBuf=NULL;
			
			FormarUrl(pMe,6);
			pMe->m_eDestInfo=BUFER;
			pMe->m_BanderaConexion=TRUE;
			ISHELL_SetTimer(pMe->a.m_pIShell, 5000, (PFNNOTIFY)Conexion_TMP, (void *)pMe);
			
			
		}

			
	}
	return TRUE;
	
}

void Conexion_TMP(Cringtonesapp * pMe)
{
			IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
			IDISPLAY_Update(pMe->a.m_pIDisplay);
			ConexionWeb( pMe, pMe->m_pUrlComp, NULL);
}

/****************************************************************************************************/
// MODULO DE AYUDA
/****************************************************************************************************/

//FUNCION IniciarHtmlViewer

boolean IniciarHtmlViewer(Cringtonesapp *pMe)
{
  AEERect rAreaRect;
 if(!pMe->m_pIHtmlViewer)
	  if(ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_HTML, (void**)&pMe->m_pIHtmlViewer) != SUCCESS)
	  return FALSE;

  //IIMAGE_GetInfo(pMe->m_pIImgBanner, pMe->m_pImageInfo);
  SETAEERECT(&rAreaRect, 3, 21, pMe->m_cxPantalla - 6, pMe->m_cyPantalla - 21 - 4);
  IDISPLAY_FillRect( pMe->a.m_pIDisplay, &rAreaRect, MAKE_RGB(194,224,156));
  IHTMLVIEWER_SetRect(pMe->m_pIHtmlViewer,&rAreaRect);
  IHTMLVIEWER_SetProperties(pMe->m_pIHtmlViewer,HVP_SCROLLBAR);
  IHTMLVIEWER_SetNotifyFn(pMe->m_pIHtmlViewer,(PFNHVIEWNOTIFY)HtmlViewer_Noficaciones,pMe);
  IHTMLVIEWER_SetLinkColor(pMe->m_pIHtmlViewer,HTML_LINK);
  

  return TRUE;
}

// FUNCION HtmlViewer_Notificaciones

void HtmlViewer_Noficaciones(Cringtonesapp *pMe,HViewNotify *notificacion)
{
  switch(notificacion->code)
  {
    case HVN_JUMP:
    if (STRCMP(notificacion->u.jump.pszURL,"Salir"))
		AbrePaginaBuscaTag(pMe,ARCHIVO_AYUDA,notificacion->u.jump.pszURL);
    break;   
  }
}

// FUNCION AbrePaginaBuscaTag

boolean AbrePaginaBuscaTag(Cringtonesapp *pMe,const char *Archivo,const char *Tag)
{
	char *Html;
	char *End;
	char *pFileBuf;
	char *FileBuf;

	if(!pMe->m_pIFileMgr)
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )		
		{
		  pMe->m_pIFileMgr = NULL;
		  return FALSE;
		}
	pMe->m_pIFile=IFILEMGR_OpenFile(pMe->m_pIFileMgr,Archivo, _OFM_READ);	
	
	if ( IFILE_GetInfo(pMe->m_pIFile, pMe->m_pFileInfo)!=SUCCESS )
	return FALSE;
	
	if (pMe->m_pIFile)
	{
	  FileBuf=(char *)MALLOC(pMe->m_pFileInfo->dwSize+1);
	  IFILE_Read(pMe->m_pIFile, FileBuf,(uint32)(pMe->m_pFileInfo->dwSize));
	  FileBuf[pMe->m_pFileInfo->dwSize+1]='\0';
	  pFileBuf=FileBuf;
	  if( TagContents(&FileBuf,Tag,&Html, &End) ) 
	  {
		IHTMLVIEWER_ParseBuffer(pMe->m_pIHtmlViewer, Html);
		RELEASEIF(pMe->m_pIFile);
	  }
	  RELEASEIF(pMe->m_pIFileMgr);
		
	}   
	else
	return FALSE;
	
	FREE(pFileBuf);
	return TRUE;
}

void CuadroTextoInfo(Cringtonesapp *pMe)
{
	AECHAR *ARTISTA_TITULO;
	AECHAR *Titulo_Tono=NULL;
	AEERect COORDENADAS_ID;
	AECHAR Buffer[50]={'\0'};
	char *Artista_Titulo;
	char *End;
	char *FileBuf, *pFileBuf;
	char *Tono;
	char *Artista;

	FileInfo pFInfo;

	pMe->m_ePantalla=P_IDINFO;
	pMe->m_eEntorno=E_IDINFO;
	COORDENADAS_ID.x=(int16)(pMe->m_cxPantalla*2/10);
	COORDENADAS_ID.y=(int16)(pMe->m_cyPantalla*3/10);
	COORDENADAS_ID.dx=(int16)(pMe->m_cxPantalla*6/10);
	COORDENADAS_ID.dy=(int16)(pMe->m_cyPantalla/10);

	Fondo_ID(pMe);

	IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_CUADROTEXTO1,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*1)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_CUADROTEXTO2,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*2)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_CUADROTEXTO3,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*3)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);

	if(!pMe->m_pIFileMgr)
	{
		if(ISHELL_CreateInstance( pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&(pMe->m_pIFileMgr)) != SUCCESS )
			return ;
	}


					creaSK(pMe);

					if(pMe->TONOS_IDTONO==FALSE) //en caso de leer del archivo tono.info
					{
						if(IFILEMGR_Test(pMe->m_pIFileMgr,"/tmp/tono.info")==SUCCESS)
						{
							if(!pMe->m_pIFile) //dependiendo del valor de iPagArt abre el archivo correspondiente.
							{
								pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "/tmp/tono.info", _OFM_READ);
							}

							if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
								return;

							if (pMe->m_pIFile)
							{
								FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
								IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
								FileBuf[pFInfo.dwSize+1]=NULL;
								pFileBuf=FileBuf;
							}
							else
								return; 

							if (TagContents(&FileBuf,"t",&Tono,&End))
							{

								Titulo_Tono=(AECHAR *)MALLOC(2*STRLEN(Tono)+1);
								STRTOWSTR(Tono,Titulo_Tono,2*STRLEN(Tono)+1);

							}
							if(TagContents(&FileBuf,"a",&Artista,&End))
							{
								if( Artista!=NULL && !STRCMP( Artista, " " ) )
								{
									Artista_Titulo=(char *)MALLOC(STRLEN(Artista)+STRLEN(Tono)+5);
									ARTISTA_TITULO=(AECHAR *)MALLOC(2*(STRLEN(Artista)+STRLEN(Tono)+5)+2);
									STRCPY(Artista_Titulo,Artista);
									STRCAT(Artista_Titulo," - ");
									STRCAT(Artista_Titulo,Tono);
									STRTOWSTR(Artista_Titulo,ARTISTA_TITULO,2*STRLEN(Artista_Titulo)+2);
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, ARTISTA_TITULO, -1, 0, (pMe->m_cyPantalla*6)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
									FREEIF(Artista_Titulo);
									FREEIF(ARTISTA_TITULO);
								}
								else
								{
									IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Titulo_Tono, -1, 0, (pMe->m_cyPantalla*6)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
									FREEIF(Titulo_Tono);
								}
							}

							if (pMe->m_pIFileMgr){
								IFILEMGR_Release(pMe->m_pIFileMgr);
								pMe->m_pIFileMgr=NULL;
							}
							if(pMe->m_pIFile) {
								IFILE_Release(pMe->m_pIFile);
								pMe->m_pIFile=NULL;
							}

							FREEIF(pFileBuf);
							pFileBuf=NULL;

						}
					
							
					}
					if(pMe->TONOS_IDTONO==TRUE) //en caso de leer del archivo id_tono
					{
						// el valor de artista esta en pMe->Artista y el valor de tono en pMe->m_pNTono tras haber leido el wish list antes de realizar la descarga, o en caso contrario cuando si encontro el id_tono
						if(!pMe->m_pNTono)
						{
								OVEtiqueta( pMe, "wish.dat", "t", &pMe->m_pNTono ); //LEER TITULO Y ARTISTA CORRESPONDIENTES AL ID_TONO

						}
						if(!pMe->Artista)
						{
								OVEtiqueta( pMe, "wish.dat", "a", &pMe->Artista);

						}
						STRTOWSTR(pMe->m_pNTono, Buffer, sizeof(Buffer));
						IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*5)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);

						STRTOWSTR(pMe->Artista, Buffer, sizeof(Buffer));
						IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*6)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);

					}

		FREEIF(pMe->m_pNTono);
		FREEIF(pMe->Artista);
		if(pMe->m_pISKMenu)
		{
			IMENUCTL_SetActive(pMe->m_pISKMenu, TRUE);
		}
		return;
}

void InterfazID(Cringtonesapp *pMe)
{
	AECHAR Buffer[50];
	AEERect COORDENADAS_ID;
	pMe->m_ePantalla=P_ID;
	pMe->m_eEntorno=E_ID;
	COORDENADAS_ID.x=(int16)(pMe->m_cxPantalla*2/10);
	COORDENADAS_ID.y=(int16)(pMe->m_cyPantalla*3/10);
	COORDENADAS_ID.dx=(int16)(pMe->m_cxPantalla*6/10);
	COORDENADAS_ID.dy=(int16)(pMe->m_cyPantalla/10);


	EliminaArchivos( pMe, "tmp/");
	if(pMe->sinnombretono==TRUE)
		pMe->sinnombretono=FALSE;

	if(pMe->m_pIMenuActivo)
	{
			IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
	}
	
	LibMem(pMe);

	Fondo_ID(pMe);

	if(pMe->m_pITextCtl)
	{
		ITEXTCTL_Release(pMe->m_pITextCtl);
		pMe->m_pITextCtl=NULL;
	}

	if(ISHELL_CreateInstance(pMe->a.m_pIShell,AEECLSID_TEXTCTL,&pMe->m_pITextCtl)==SUCCESS)
	{
	
		ITEXTCTL_SetProperties(pMe->m_pITextCtl, TP_FRAME);
		ITEXTCTL_SetInputMode(pMe->m_pITextCtl,AEE_TM_NUMBERS); //PARA INGRESAR NUMEROS EN EL ITEXTCTL
		ITEXTCTL_SetRect(pMe->m_pITextCtl,&COORDENADAS_ID);
		ITEXTCTL_SetActive(pMe->m_pITextCtl,TRUE);
		ITEXTCTL_Redraw(pMe->m_pITextCtl);
		IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(255,255,255) );
		ITEXTCTL_Redraw(pMe->m_pITextCtl);

		ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_INSERTAR_NUM_ID,Buffer,sizeof(Buffer));
		ITEXTCTL_SetText(pMe->m_pITextCtl,Buffer, -1);
		ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_TITULOINGRESA,Buffer,sizeof(Buffer));
		IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*1)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
		ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_INGRESARID,Buffer,sizeof(Buffer));
		IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*5)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
		ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_INGRESARID2,Buffer,sizeof(Buffer));
		IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*6)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
		ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_INGRESARID3,Buffer,sizeof(Buffer));
		IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*7)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
		IDISPLAY_Update(pMe->a.m_pIDisplay);
		creaSK(pMe);
		if(pMe->m_pISKMenu)
		{
			IMENUCTL_SetActive(pMe->m_pISKMenu, FALSE);
			
		}

	}
}

void CuadroTonoComprado(Cringtonesapp *pMe)
{
	AECHAR Buffer[50];

	if(pMe->m_pIMenuActivo)
	{
			IMENUCTL_SetActive(pMe->m_pIMenuActivo, FALSE);
	}
	LibMem(pMe);

	if (pMe->m_ProfColor>=8)
		IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
	else
		IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);
	
	IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_TONOCOMPRADO_1,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*3)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_TONOCOMPRADO_2,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*4)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_TONOCOMPRADO_3,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*5)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
	ISHELL_LoadResString(pMe->a.m_pIShell, RINGTONES_RES_FILE, IDS_TONOCOMPRADO_4,Buffer,sizeof(Buffer));
	IDISPLAY_DrawText(pMe->a.m_pIDisplay, AEE_FONT_BOLD, Buffer, -1, 0, (pMe->m_cyPantalla*6)/10,0, IDF_ALIGN_CENTER|IDF_TEXT_TRANSPARENT);
	creaSK(pMe);
}

boolean BuscaTono_TonoInfo(Cringtonesapp *pMe)
{
	FileInfo pFInfo;
	char *pFileBuf =NULL;
	char *FileBuf=NULL;
	char *End=NULL;
 	char *extension;
    char *Valor_ID;
   	char *Ruta_extension;

	Valor_ID=(char *)MALLOC(WSTRLEN(pMe->Digitos_ID)); //WSTRLEN PORQUE ES AECHAR
	WSTRTOSTR(pMe->Digitos_ID, Valor_ID, WSTRLEN(pMe->Digitos_ID)); // TAMA�O EN BYTES DE VALOR_ID
	Ruta_extension=(char *)MALLOC(STRLEN(Valor_ID)+6);
	
	if(!pMe->m_pID_Tono)
	{
		pMe->m_pID_Tono=(char *)MALLOC(STRLEN(Valor_ID)+1);
		STRCPY(pMe->m_pID_Tono,Valor_ID);
	}
	
	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}
	

	if(IFILEMGR_Test(pMe->m_pIFileMgr,"/tmp/tono.info")!=SUCCESS)
	{
			pMe->m_u16Opcion1=5;
			IDISPLAY_ClearScreen(pMe->a.m_pIDisplay);
			IDISPLAY_Update(pMe->a.m_pIDisplay);
			if(pMe->m_pITextCtl!=NULL)
			{
				ITEXTCTL_Release(pMe->m_pITextCtl);
				pMe->m_pITextCtl=NULL;
			}
			Fondo_ID(pMe);
			DespliegaMensaje(pMe); //Despliega el mensaje de que el tono no existe
			//MODIFICACION REALIZADA PARA FIJACION DE TIMER 13/05/04
			ISHELL_SetTimer(pMe->a.m_pIShell, 1000, (PFNNOTIFY)InterfazID, (void *)pMe);
			pMe->ID=FALSE;
		
		
	}
	else
	{
	if(!pMe->m_pIFile) //dependiendo del valor de iPagArt abre el archivo correspondiente.
	{

			pMe->m_pIFile = IFILEMGR_OpenFile(pMe->m_pIFileMgr, "/tmp/tono.info", _OFM_READ);
	}

	if (IFILE_GetInfo(pMe->m_pIFile, &pFInfo)!=SUCCESS)
			return FALSE;


	if (pMe->m_pIFile)
	{
		FileBuf=(char *)MALLOC(pFInfo.dwSize+1);
		IFILE_Read(pMe->m_pIFile, FileBuf, pFInfo.dwSize);
		FileBuf[pFInfo.dwSize+1]=NULL;
		pFileBuf=FileBuf;
	}
	else
		return FALSE;


	if (TagContents(&FileBuf,"f",&extension,&End)) //busca el formato del archivo
	{
			STRCPY(Ruta_extension, "/tmp/");
			STRCAT(Ruta_extension, pMe->m_pID_Tono);
			STRCAT(Ruta_extension, ".");
			STRCAT(Ruta_extension, extension);
	}

		if(IFILEMGR_Test(pMe->m_pIFileMgr,Ruta_extension)==SUCCESS) //Existe el tono en el directorio de tonos?
		{  //si existe el tono
			LibMem( pMe );
			CuadroTextoInfo(pMe); // se despliegan datos del tono.info sobre artista y titulo
		}
	}		

	if(!pMe->m_pIFileMgr)
	{
		if (ISHELL_CreateInstance(pMe->a.m_pIShell, AEECLSID_FILEMGR, (void **)&pMe->m_pIFileMgr) != SUCCESS )
		{
			pMe->m_pIFileMgr = NULL;
			return FALSE;
		}
	}

	FREEIF(Valor_ID);
	FREEIF(pFileBuf);
	FREEIF(Ruta_extension);
	return TRUE;

}


void Fondo_ID(Cringtonesapp *pMe)
{

	if (pMe->m_pIGraphics)
	{
		if ( pMe->m_ProfColor>=8)
			IGRAPHICS_SetBackground(pMe->m_pIGraphics,194,224,156);
		else
			IGRAPHICS_SetBackground(pMe->m_pIGraphics,255,255,255);
		IGRAPHICS_ClearViewport(pMe->m_pIGraphics);
	}
		IDISPLAY_SetColor(pMe->a.m_pIDisplay,CLR_USER_BACKGROUND, MAKE_RGB(194,224,156) );
		IDISPLAY_Update(pMe->a.m_pIDisplay);

}

boolean buscaTemp( Cringtonesapp * pMe )
{

	if( !pMe->m_pIArchivoTono )
		FREEIF(pMe->m_pIArchivoTono);

	if( pMe->m_pIFileMgr ) 
	{
		pMe->m_pIArchivoTono = (char *)MALLOC( STRLEN("tmp/") + STRLEN(pMe->m_pID_Tono) + STRLEN(".mp3") + 1 );
		if( pMe->m_pIArchivoTono )
		{
			STRCPY( pMe->m_pIArchivoTono, "tmp/" );
			STRCAT( pMe->m_pIArchivoTono, pMe->m_pID_Tono );
			STRCAT( pMe->m_pIArchivoTono, ".mp3" );
			if( IFILEMGR_Test( pMe->m_pIFileMgr, pMe->m_pIArchivoTono ) == SUCCESS )
			{
				return TRUE;
			}
		}
	}

	FREEIF( pMe->m_pIArchivoTono );	

	return FALSE;
}
